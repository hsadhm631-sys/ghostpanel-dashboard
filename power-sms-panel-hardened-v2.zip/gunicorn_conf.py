import os

# Load .env for manual runs (systemd already loads it via EnvironmentFile).
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env'))
except ImportError:
    pass

port = os.environ.get('PORT') or os.environ.get('SERVER_PORT') or '5000'
domain = os.environ.get('DOMAIN', '').strip()
bind = f"{os.environ.get('BIND_HOST', '0.0.0.0')}:{port}"

# One worker process with many threads, on purpose. The panel runs background
# pollers, and SMPP keeps one bound link per provider. Several worker processes
# would each start their own pollers and bind their own SMPP sessions, and most
# SMSCs allow only one bind per account. Threads give the concurrency we need.
workers = int(os.environ.get('WEB_CONCURRENCY', 1))
worker_class = 'gthread'
threads = int(os.environ.get('GUNICORN_THREADS', 16))

timeout = 120
graceful_timeout = 30
keepalive = 5
max_requests = 0  # keep long-lived SMPP sessions alive across requests

accesslog = os.environ.get('GUNICORN_ACCESS_LOG', 'logs/access.log')
errorlog = os.environ.get('GUNICORN_ERROR_LOG', 'logs/error.log')
loglevel = 'info'
capture_output = True


def on_starting(server):
    url = f"http://{domain}:{port}" if domain else f"http://<SERVER_IP>:{port}"
    server.log.info("=========================================")
    server.log.info(f"Power SMS Panel is UP and RUNNING -> PORT={port} | DOMAIN={domain or 'not set'} | URL={url}")
    server.log.info(f"Bind address: {bind} | workers={workers} threads={threads}")
    server.log.info("=========================================")
