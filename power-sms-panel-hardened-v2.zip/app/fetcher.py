import threading
import time
import re
import logging
from datetime import datetime

log = logging.getLogger("Fetcher")

_stop_events = {}
_threads = {}
_sessions = {}

BUILTIN_PANELS = {
    "ChoiceSMS":   {"url": "http://51.77.52.79/ints",         "ptype": "ints"},
    "FlynSMS":     {"url": "http://91.232.105.47/ints",       "ptype": "ints"},
    "Gaza":        {"url": "http://144.217.71.192/ints",      "ptype": "ints"},
    "GoatPanel":   {"url": "http://167.114.117.67/ints",      "ptype": "ints"},
    "ImsPanel":    {"url": "https://www.imssms.org",          "ptype": "ims"},
    "KmSms":       {"url": "http://54.36.173.235/ints",       "ptype": "ints"},
    "KonektaPanel":{"url": "https://www.konektapremium.net",  "ptype": "konekta"},
    "MsiSMS":      {"url": "http://145.239.130.45/ints",      "ptype": "ints"},
    "ProofSMS":    {"url": "http://217.182.195.194/ints",     "ptype": "proofsms"},
    "PurplePanel": {"url": "http://85.195.94.50/sms",         "ptype": "standard"},
    "Seven1Tel":   {"url": "http://147.135.212.197/crapi/s1t/viewstats", "ptype": "api_token"},
    "SharkSMS":    {"url": "http://93.190.143.157/ints",      "ptype": "ints"},
    "TrueSMS":     {"url": "https://truesms.net",             "ptype": "standard"},
    "VoiceGate":   {"url": "http://51.89.7.175/sms",          "ptype": "voicegate"},
    "Wolf":        {"url": "http://213.32.24.208/ints",       "ptype": "ints"},
    "GreenSMS":    {"url": "http://139.99.9.4/ints",          "ptype": "ints"},
    "FireSMS":     {"url": "http://54.39.104.241/ints",       "ptype": "ints"},
    "SniperPanel": {"url": "http://135.125.222.224/ints",     "ptype": "ints"},
    "MAIT":        {"url": "http://168.119.13.175/ints",      "ptype": "ints"},
    "TimeSMS":     {"url": "http://147.135.212.197/crapi/time/viewstats", "ptype": "api_token"},
    # ── Added from FLASH-SMS-BOT.py so the panel uses the exact same
    #    panel list, login logic, and equation as the bot ──
    "XapSMS":      {"url": "http://147.135.212.148/ints",     "ptype": "ints"},
    "Num44":       {"url": "http://185.177.124.145/ints",     "ptype": "ints"},
    "LamixSMS":    {"url": "http://139.99.208.63/ints",       "ptype": "ints"},
    "GroupSMS":    {"url": "http://139.99.63.204/ints",       "ptype": "ints"},
    "ProtonSMS":   {"url": "http://109.236.84.81/ints",       "ptype": "ints"},
    "BoltSMS":     {"url": "http://93.190.143.35/ints",       "ptype": "ints"},
    "SquadSMS":    {"url": "http://51.77.221.209/ints",       "ptype": "ints"},
    "DGroupSMS":   {"url": "http://51.77.216.195/crapi/dgroup/viewstats", "ptype": "api_token"},
    "NumberPanel": {"url": "http://147.135.212.197/crapi/st/viewstats",  "ptype": "api_token"},
    "RoxySMS":     {"url": "http://51.77.216.195/crapi/rx/viewstats",   "ptype": "api_token"},
    "KonektaAPI":  {"url": "http://51.77.216.195/crapi/konek/viewstats", "ptype": "api_token"},
    "PcCall":      {"url": "http://pscall.net/restapi/smsreport",       "ptype": "api_token"},
    "HadiSMS":     {"url": "http://147.135.212.197/crapi/had/viewstats", "ptype": "api_token"},
    "Basha":       {"url": "https://basha.cc",                          "ptype": "basha"},
}

def _detect_otp(text):
    if not text:
        return None
    text = re.sub(r"<#>\s*", "", str(text))
    m = re.search(r"(\d{3,4}-\d{3,4})(?!\d)", text)
    if m:
        return m.group(1)
    m = re.search(
        r"(?:code|otp|pin|passcode|verif\w*|codigo|كود|رمز|رقم|Password|Confirmation)"
        r"[^\d]*(\d{4,8})", text, re.I)
    if m:
        return m.group(1)
    m = re.search(r":\s*(\d{4,8})\b", text)
    if m:
        return m.group(1)
    for m in re.finditer(r"(?<![/\-\d])(\d{4,6})(?![/\-\d])", text):
        c = m.group(1)
        if re.match(r"^20[0-9]{2}$", c):
            continue
        return c
    return None

def _save_otp(app, provider_id, number, otp, sender, message, order_id=None, service_name=None, source='poll', country_hint=None):
    with app.app_context():
        from app.models.provider import OTPLog
        from app.models.sms import SMSNumber, SMSCDR
        from app import db

        num_clean = re.sub(r"\D", "", str(number))

        # ── Duplicate check: same number + same OTP = always duplicate ──
        # No time window — if this exact OTP for this exact number was ever
        # logged before, skip it. Only a DIFFERENT OTP on the same number
        # counts as a new entry.
        existing = OTPLog.query.filter_by(
            number=num_clean,
            otp=otp
        ).first()

        if existing:
            log.info(f"Duplicate OTP skipped: {num_clean} → {otp}")
            return {
                'duplicate': True,
                'matched_number': bool(existing.number_id),
                'otp_log_id': existing.id,
                'country': existing.country,
            }

        # ── Progressive suffix match ─────────────────────────────────────
        # Username/password panels (ints, ims, konekta, standard, ...) and
        # api_token panels don't always normalize the destination number the
        # same way (leading 00/+, country code included or not, etc). Only
        # ever trying the last 10 digits meant a perfectly valid OTP could
        # fail to find its SMSNumber row just because of a 1-digit length
        # difference — the OTP still landed in OTPLog (so "OTP Logs" looked
        # fine) but no SMSCDR ever got created, so Dashboard / API / Test
        # Panel / Agent / Client views (which all read from SMSCDR) stayed
        # empty. Trying 10, then 9, then 8 digits — same idea already used
        # in sms_monitor.py's forward_to_reserved() — makes the match far
        # more forgiving without weakening the OTPLog duplicate check above.
        sms_number = None
        for suf_len in (10, 9, 8):
            if len(num_clean) < suf_len:
                continue
            sms_number = SMSNumber.query.filter(
                SMSNumber.number.like(f"%{num_clean[-suf_len:]}")
            ).first()
            if sms_number:
                break

        if not sms_number:
            log.warning(
                f"[provider_id={provider_id}] OTP for {num_clean} saved to "
                f"OTPLog only - no matching SMSNumber found, so it will NOT "
                f"show up in Dashboard / API / Test Panel / Agent / Client "
                f"views. Make sure this number is inside an imported SMS "
                f"Range and assigned to an agent/client."
            )

        user_id = None
        if sms_number:
            user_id = sms_number.client_id or sms_number.agent_id

        # Country of the matched range, if any — this is the "اسم الدولة"
        # that lets you tell at a glance whose number/traffic this is
        # without having to cross-reference the SMS Range separately.
        # Falls back to `country_hint` (e.g. from a Telegram-source
        # webhook that already detected the country itself) whenever
        # the number isn't inside any imported Range.
        country = None
        if sms_number and sms_number.range_id:
            from app.models.sms import SMDRange
            rng = SMDRange.query.get(sms_number.range_id)
            if rng:
                country = rng.country
        if not country and country_hint:
            country = country_hint

        entry = OTPLog(
            provider_id=provider_id,
            number=num_clean,
            otp=otp,
            sender=sender,
            message=message,
            number_id=sms_number.id if sms_number else None,
            user_id=user_id,
            order_id=order_id,
            service_name=service_name,
            source=source,
            country=country
        )
        db.session.add(entry)

        # ── Also write into SMSCDR so Agent CDR Reports + SMS Test Panel ──
        # show this OTP. Without this, only the Admin OTP Logs page sees it.
        # Guarded against the sms_monitor.py Panel4/TimeSMS path also
        # writing this same message into SMSCDR — see is_duplicate_cdr().
        from app.utils import is_duplicate_cdr
        if sms_number and is_duplicate_cdr(sms_number.id, message):
            log.info(f"Duplicate CDR skipped (already written by another source): {num_clean}")
        elif sms_number:
            cdr = SMSCDR(
                number_id=sms_number.id,
                range_id=sms_number.range_id,
                user_id=sms_number.agent_id,
                client_id=sms_number.client_id,
                caller_id=sender,
                destination=num_clean,
                cli=sender,
                message=message,
                created_at=datetime.utcnow(),
                currency='USD',
                agent_payout=sms_number.agent_payout or 0.0,
                client_payout=sms_number.client_payout or 0.0,
                profit=(sms_number.client_payout or 0.0) - (sms_number.agent_payout or 0.0),
                sms_type='received',
                status='completed'
            )
            db.session.add(cdr)

        db.session.commit()
        log.info(f"OTP saved: {num_clean} → {otp}")
        return {
            'duplicate': False,
            'matched_number': bool(sms_number),
            'otp_log_id': entry.id,
            'country': country,
        }


def _log_provider_poll(app, provider_name, status, message):
    """Record each panel login/fetch cycle into ApiRequestLog so the admin's
    monitor page (routes/sms_monitor.py → /monitor/api-live) shows real panel
    activity — which panel logged in fine, which one is failing — instead of
    only ever showing client-side API calls made against /api/*.
    Uses endpoint='provider.poll' so the UI can filter it separately from
    client API traffic."""
    try:
        with app.app_context():
            from app.models.activity import ApiRequestLog
            ApiRequestLog.log(
                user_id=None,
                username=provider_name,
                endpoint='provider.poll',
                method='POLL',
                number=None,
                status=status,
                status_code=200 if status == 'success' else 502,
                message=(message or '')[:255],
                ip_address=None,
            )
    except Exception:
        log.exception("Failed to write provider poll log")


def _fetch_loop(app, provider_id, stop_event):
    session_info = None

    while not stop_event.is_set():
        with app.app_context():
            from app.models.provider import Provider
            provider = Provider.query.get(provider_id)
            if not provider or not provider.is_active:
                break
            name           = provider.name
            url            = provider.url
            ptype          = provider.ptype
            username       = provider.username
            password       = provider.password
            api_token      = getattr(provider, 'api_token', '') or ''
            fetch_interval = provider.fetch_interval

            # 'webhook' providers never get logged into or polled — codes
            # arrive by push to /api/provider/receive-code instead. Nothing
            # for this loop to do, so it exits immediately instead of
            # falling through to the ints-login fallback below.
            if ptype == 'webhook':
                log.info(f"[{name}] ptype=webhook — nothing to poll, exiting loop")
                return

        try:
            from panel_fetchers import (
                ints_login, ints_fetch,
                ims_login, ims_fetch,
                konekta_login, konekta_fetch,
                panel_login, panel_fetch,
                new_panel_login, new_panel_fetch,
                timesms_login, timesms_fetch,
                proofsms_fetch,
                apitoken_login, apitoken_fetch,
                basha_login, basha_fetch,
            )

            if session_info is None:
                log.info(f"[{name}] Logging in...")
                try:
                    if ptype == "ints":
                        session_info = ints_login(name, username, password, url)
                    elif ptype == "ims":
                        session_info = ims_login(username, password, url)
                    elif ptype == "konekta":
                        session_info = konekta_login(username, password, url)
                    elif ptype == "standard":
                        session_info = panel_login(name, username, password, url)
                    elif ptype == "timesms":
                        session_info = timesms_login(name, username, password, url)
                    elif ptype == "basha":
                        session_info = basha_login(name, username, password, url)
                    elif ptype in ("roxy", "voicegate", "numberpanel", "proofsms"):
                        session_info = new_panel_login(name, username, password, url, ptype=ptype)
                    elif ptype == "api_token":
                        session_info = apitoken_login(name, api_token, url)
                    else:
                        session_info = ints_login(name, username, password, url)
                    log.info(f"[{name}] Login OK")
                    _log_provider_poll(app, name, 'success', 'Login OK')
                except Exception as e:
                    log.error(f"[{name}] Login failed: {e}")
                    _log_provider_poll(app, name, 'fail', f'Login failed: {e}')
                    stop_event.wait(30)
                    continue

            try:
                if ptype == "ints":
                    rows = ints_fetch(name, session_info, url)
                elif ptype == "ims":
                    rows = ims_fetch(session_info, url)
                elif ptype == "konekta":
                    rows = konekta_fetch(session_info)
                elif ptype == "standard":
                    rows = panel_fetch(session_info, url)
                elif ptype == "timesms":
                    rows = timesms_fetch(name, session_info, url)
                elif ptype == "basha":
                    rows = basha_fetch(session_info, url)
                elif ptype in ("roxy", "voicegate", "numberpanel", "proofsms"):
                    rows = new_panel_fetch(name, session_info, url, ptype=ptype)
                elif ptype == "api_token":
                    rows = apitoken_fetch(name, session_info, url)
                else:
                    rows = ints_fetch(name, session_info, url)
            except Exception as e:
                log.error(f"[{name}] Fetch error: {e}")
                _log_provider_poll(app, name, 'fail', f'Fetch error: {e}')
                session_info = None
                stop_event.wait(15)
                continue

            if rows is None:
                log.info(f"[{name}] Session expired, re-logging...")
                _log_provider_poll(app, name, 'fail', 'Session expired, re-logging...')
                session_info = None
                continue

            _log_provider_poll(app, name, 'success', f'{len(rows)} row(s) fetched')

            if rows:
                for row in rows:
                    if isinstance(row, list):
                        number  = str(row[2]) if len(row) > 2 else ""
                        sender  = str(row[3]) if len(row) > 3 else ""
                        message = str(row[5]) if len(row) > 5 else ""
                    elif isinstance(row, dict):
                        number  = str(row.get("number", ""))
                        sender  = str(row.get("cli", ""))
                        message = str(row.get("sms", ""))
                    else:
                        continue

                    if not number:
                        continue

                    otp = _detect_otp(message)
                    if not otp:
                        continue

                    _save_otp(app, provider_id, number, otp, sender, message)

        except Exception as e:
            log.error(f"[{name}] Loop error: {e}")
            session_info = None

        stop_event.wait(fetch_interval)

    log.info(f"[{name}] Stopped")

def start_provider(app, provider_id):
    import os as _os
    if _os.environ.get('VERCEL'):
        # No persistent process here — a thread started inside this
        # request would die the moment the request finishes. The actual
        # polling happens via /api/cron/poll-providers, called
        # periodically by an external scheduler (cron-job.org). All this
        # needs to do is mark the provider active and drop any stale
        # session so the next poll logs in fresh instead of reusing a
        # possibly-dead one.
        with app.app_context():
            from app.models.provider import Provider
            from app import db as _db
            p = Provider.query.get(provider_id)
            if p:
                p.is_active = True
                p.session_data = None
                _db.session.commit()
        return
    with app.app_context():
        from app.models.provider import Provider
        p = Provider.query.get(provider_id)
        if p and p.ptype == 'webhook':
            # Nothing to poll — codes arrive by push, not by logging in.
            return
    stop_provider(provider_id)
    stop_event = threading.Event()
    _stop_events[provider_id] = stop_event
    t = threading.Thread(
        target=_fetch_loop,
        args=(app, provider_id, stop_event),
        daemon=True,
        name=f"provider_{provider_id}"
    )
    t.start()
    _threads[provider_id] = t
    log.info(f"Provider {provider_id} started")

def stop_provider(provider_id):
    import os as _os
    if _os.environ.get('VERCEL'):
        # is_active is flipped by the caller (routes/provider.py); nothing
        # thread-related exists here to clean up on Vercel.
        return
    if provider_id in _stop_events:
        _stop_events[provider_id].set()
        del _stop_events[provider_id]
    if provider_id in _threads:
        del _threads[provider_id]
    log.info(f"Provider {provider_id} stopped")

def is_running(provider_id):
    import os as _os
    if _os.environ.get('VERCEL'):
        # There's no thread to check on Vercel. "Running" here just means
        # "the external cron (poll-providers) will pick this one up on
        # its next tick" — i.e. is_active. Whether that cron is actually
        # configured/firing is a separate concern, shown via
        # last_polled_at in the UI rather than folded into this flag, so
        # pressing Start doesn't flip straight back to "Stopped" before
        # the first tick has even had a chance to run.
        from app.models.provider import Provider
        p = Provider.query.get(provider_id)
        return bool(p and p.is_active)
    if provider_id not in _stop_events:
        return False
    if _stop_events[provider_id].is_set():
        return False
    t = _threads.get(provider_id)
    return t is not None and t.is_alive()

def start_all_providers(app):
    with app.app_context():
        from app.models.provider import Provider
        providers = Provider.query.filter_by(is_active=True).all()
        for p in providers:
            start_provider(app, p.id)
        log.info(f"Auto-started {len(providers)} providers")