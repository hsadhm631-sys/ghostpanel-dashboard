import os
import secrets
import sys
from urllib.parse import urlsplit

from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from sqlalchemy import event
from sqlalchemy.engine import Engine
from werkzeug.middleware.proxy_fix import ProxyFix
from config import config

db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()


# ── Fix: "database is locked" 500 errors ──────────────────────────────────
# The app runs many background threads (one per SMS provider + the
# scheduler jobs) that all write to the same SQLite file concurrently with
# normal web requests. SQLite's default locking mode + a short busy timeout
# means any overlap raises "database is locked", which the 500 handler
# turns into "An internal error occurred" and can also make an authenticated
# request fail mid-flight (looking like a random logout). WAL mode lets
# readers and a writer work at the same time, and a longer busy_timeout
# makes writers wait instead of failing immediately.
@event.listens_for(Engine, "connect")
def _set_sqlite_pragma(dbapi_connection, connection_record):
    if type(dbapi_connection).__module__.startswith('sqlite3'):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.close()


def _store_initial_admin_password(app, username, password):
    """Write a generated first-run admin password to a file readable only by
    the owner, and print where it is. Never written to the application log."""
    path = os.path.join(app.instance_path, 'initial_admin_password.txt')
    try:
        os.makedirs(app.instance_path, exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            fh.write(f'username: {username}\npassword: {password}\n'
                     'Log in, then change this password and delete this file.\n')
        print(f'[security] Created admin account. Initial credentials are in {path}',
              file=sys.stderr)
    except OSError:
        print('[security] Created admin account with a generated password, but the '
              'instance folder is not writable. Set ADMIN_PASSWORD and restart.',
              file=sys.stderr)


def create_app(config_name='default'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    # Flask-SQLAlchemy always calls os.makedirs(app.instance_path) during
    # init_app(), even when the DB is Postgres, not SQLite. Vercel's
    # filesystem is read-only everywhere except /tmp, so that makedirs()
    # call crashes the whole function before a single request is served.
    # Point instance_path at the one writable directory instead.
    if os.environ.get('VERCEL'):
        app.instance_path = '/tmp/instance'

    # Key for encrypting stored SMPP passwords. Must be set up before any
    # query that touches those columns.
    from app import crypto_box
    crypto_box.init_key(app.instance_path, os.environ.get('DATA_ENCRYPTION_KEY'))

    db.init_app(app)
    login_manager.init_app(app)
    bcrypt.init_app(app)
    # Only the API blueprint is meant to be called cross-origin (from client
    # sites). Everything else stays same-origin. The API still authenticates
    # with X-API-Token, so cross-origin browser access to it is safe.
    CORS(app, resources={r'/api/*': {'origins': '*'}}, supports_credentials=False)

    # Behind nginx / Vercel, trust the forwarded client address only for the
    # number of proxies configured. Nothing is trusted by default.
    hops = int(app.config.get('TRUST_PROXY_HOPS') or 0)
    if hops > 0:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=hops, x_proto=hops, x_host=0, x_port=0)

    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please login to continue.'
    login_manager.login_message_category = 'warning'

    from app.models.user import User
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    from app.routes.auth import auth_bp
    from app.routes.main import main_bp
    from app.routes.admin import admin_bp
    from app.routes.developer import dev_bp
    from app.routes.sms_monitor import monitor_bp
    from app.routes.provider import provider_bp
    from app.routes.billing import billing_bp
    from app.routes.api import api_bp
    from app.routes.backup import backup_bp
    from app.routes.telegram import telegram_bp
    from app.routes.gateway import gateway_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(dev_bp)
    app.register_blueprint(monitor_bp)
    app.register_blueprint(provider_bp)
    app.register_blueprint(billing_bp)
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(backup_bp)
    app.register_blueprint(telegram_bp)
    app.register_blueprint(gateway_bp)

    @app.before_request
    def _enforce_live_session():
        """Kill the session immediately if the logged-in user was deleted
        or deactivated by an admin, instead of letting the stale cookie
        keep them logged in until it naturally expires.

        Also enforces single-device sessions for client accounts (Test123
        exempt): if another device has since taken over the account's
        active session, this stale device is logged out too. Otherwise,
        it sends a lightweight heartbeat so this device's session isn't
        mistaken for dead by a login attempt from elsewhere.
        """
        from flask_login import current_user, logout_user
        from flask import session as flask_session
        from datetime import datetime
        if current_user.is_authenticated:
            from app.models.user import User
            fresh = User.query.get(current_user.id)
            if fresh is None or not fresh.is_active:
                logout_user()
                flask_session.clear()
                return

            if fresh.is_client() and not fresh.is_test_account():
                device_token = flask_session.get('device_token')
                if fresh.active_session_token and device_token != fresh.active_session_token:
                    # Another device has claimed the account; this one is stale.
                    logout_user()
                    flask_session.clear()
                elif device_token and fresh.active_session_token == device_token:
                    fresh.active_session_last_seen = datetime.utcnow()
                    db.session.commit()

    SAFE_METHODS = frozenset(('GET', 'HEAD', 'OPTIONS', 'TRACE'))

    @app.before_request
    def _csrf_origin_check():
        """Cross-site request forgery guard for logged-in browser sessions.

        Browsers always send an Origin header on cross-site POST/PUT/DELETE.
        If a signed-in user's browser sends a request whose Origin is a
        different site, refuse it. Requests without cookies (webhooks, API
        clients) do not send Origin and are not affected."""
        if request.method in SAFE_METHODS:
            return None
        origin = request.headers.get('Origin')
        if not origin:
            return None
        from flask_login import current_user
        if not current_user.is_authenticated:
            return None
        if urlsplit(origin).netloc.lower() != request.host.lower():
            return jsonify({'success': False, 'error': 'Cross-site request blocked'}), 403
        return None

    @app.after_request
    def _security_headers(response):
        h = response.headers
        h.setdefault('X-Content-Type-Options', 'nosniff')
        h.setdefault('X-Frame-Options', 'SAMEORIGIN')
        h.setdefault('Referrer-Policy', 'strict-origin-when-cross-origin')
        h.setdefault('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()')
        h.setdefault('Content-Security-Policy',
                     "frame-ancestors 'self'; base-uri 'self'; object-src 'none'; form-action 'self'")
        h.setdefault('Cross-Origin-Opener-Policy', 'same-origin-allow-popups')
        if request.is_secure:
            h.setdefault('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        return response

    @app.after_request
    def _no_store_authenticated_pages(response):
        """Prevent the browser (esp. mobile) from serving a cached copy of
        an authenticated page via the back button after Sign Out."""
        from flask_login import current_user
        if getattr(current_user, 'is_authenticated', False):
            response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
            response.headers['Pragma'] = 'no-cache'
        return response

    @app.context_processor
    def inject_panel_settings():
        from app.models.settings import PanelSettings
        try:
            return {'panel_settings': PanelSettings.get()}
        except Exception:
            return {'panel_settings': None}

    @app.context_processor
    def inject_server_now():
        from datetime import datetime
        return {'server_now': datetime.utcnow()}

    @app.context_processor
    def inject_turnstile_site_key():
        return {'turnstile_site_key': app.config.get('TURNSTILE_SITE_KEY', '')}

    @app.context_processor
    def inject_logo_url_helper():
        from flask import url_for as _url_for

        def logo_url(filename):
            """logo_filename is either a local path under static/img/uploads
            (older/non-serverless deploys) or a full https:// URL returned
            by Vercel Blob. Render whichever it is correctly."""
            if not filename:
                return ''
            if filename.startswith('http://') or filename.startswith('https://'):
                return filename
            return _url_for('static', filename='img/uploads/' + filename)

        return {'logo_url': logo_url}

    with app.app_context():
        db.create_all()

        # ── Lightweight column migration ────────────────────────────────
        # db.create_all() only creates tables that don't exist yet; it won't
        # add new columns to a table that already exists on disk. Cover the
        # `theme` column added to panel_settings so upgrades to existing
        # installs don't crash with "no such column: panel_settings.theme".
        try:
            from sqlalchemy import inspect as _sa_inspect, text as _sa_text
            inspector = _sa_inspect(db.engine)
            if 'panel_settings' in inspector.get_table_names():
                existing_cols = {c['name'] for c in inspector.get_columns('panel_settings')}
                if 'theme' not in existing_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE panel_settings ADD COLUMN theme VARCHAR(30) DEFAULT 'default'"
                        ))
                if 'test_account_max_numbers' not in existing_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE panel_settings ADD COLUMN test_account_max_numbers INTEGER DEFAULT 200"
                        ))
                if 'login_theme' not in existing_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE panel_settings ADD COLUMN login_theme VARCHAR(30) DEFAULT 'default'"
                        ))
                if 'custom_design_enabled' not in existing_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE panel_settings ADD COLUMN custom_design_enabled BOOLEAN DEFAULT FALSE"
                        ))
                if 'custom_colors' not in existing_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE panel_settings ADD COLUMN custom_colors TEXT"
                        ))
                if 'dashboard_layout' not in existing_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE panel_settings ADD COLUMN dashboard_layout TEXT"
                        ))

            # Single-device session enforcement columns on users
            if 'users' in inspector.get_table_names():
                existing_user_cols = {c['name'] for c in inspector.get_columns('users')}
                users_migrations = {
                    'active_session_token': "ALTER TABLE users ADD COLUMN active_session_token VARCHAR(64)",
                    'active_session_last_seen': "ALTER TABLE users ADD COLUMN active_session_last_seen TIMESTAMP",
                    'concurrent_lock_until': "ALTER TABLE users ADD COLUMN concurrent_lock_until TIMESTAMP",
                    'api_ip_whitelist': "ALTER TABLE users ADD COLUMN api_ip_whitelist TEXT",
                }
                with db.engine.begin() as conn:
                    for col_name, ddl in users_migrations.items():
                        if col_name not in existing_user_cols:
                            conn.execute(_sa_text(ddl))

            # api_token column on providers — needed for API-only panels
            # (Seven1Tel, D-Group, Konekta API, PC CALL, ...) that use a
            # crapi token instead of username/password, same as
            # FLASH-SMS-BOT.py's api_token panel type.
            if 'providers' in inspector.get_table_names():
                existing_provider_cols = {c['name'] for c in inspector.get_columns('providers')}
                if 'api_token' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN api_token VARCHAR(255) DEFAULT ''"
                        ))
                if 'session_data' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN session_data TEXT"
                        ))
                if 'last_polled_at' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN last_polled_at TIMESTAMP"
                        ))
                if 'webhook_secret' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN webhook_secret VARCHAR(255) DEFAULT ''"
                        ))
                if 'webhook_no_auth' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN webhook_no_auth BOOLEAN DEFAULT FALSE"
                        ))
                if 'last_webhook_test_at' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN last_webhook_test_at TIMESTAMP"
                        ))
                # Real push-traffic stats for /api/provider/receive-code,
                # separate from last_webhook_test_at (manual "Test
                # Connection" clicks only).
                if 'webhook_last_received_at' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN webhook_last_received_at TIMESTAMP"
                        ))
                if 'webhook_receive_count' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN webhook_receive_count INTEGER DEFAULT 0"
                        ))
                if 'webhook_fail_count' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN webhook_fail_count INTEGER DEFAULT 0"
                        ))
                # ── IP Whitelist + configurable field-name mapping for the
                # incoming webhook route. ip_whitelist is free text, one
                # entry per line — supports an exact IP, a CIDR range
                # (e.g. 93.190.143.0/24), or '*' to allow any IP (empty
                # also means "any IP", kept for backwards compatibility
                # with providers set up before this existed). cli_field /
                # message_field / uuid_field let a provider whose POST
                # body uses different key names (e.g. "cli" instead of
                # "phone") still be accepted without code changes.
                if 'ip_whitelist' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN ip_whitelist TEXT"
                        ))
                if 'cli_field' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN cli_field VARCHAR(50) DEFAULT 'cli'"
                        ))
                if 'message_field' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN message_field VARCHAR(50) DEFAULT 'message'"
                        ))
                if 'uuid_field' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN uuid_field VARCHAR(50) DEFAULT 'uuid'"
                        ))
                # Allowed HTTP method for this provider's webhook link
                # ('GET' / 'POST' / 'ANY'). Existing providers get 'ANY'
                # so nothing already working suddenly gets rejected.
                if 'http_method' not in existing_provider_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE providers ADD COLUMN http_method VARCHAR(10) DEFAULT 'ANY'"
                        ))
                # username/password used to be NOT NULL; api_token panels
                # don't have either, so older SQLite schemas would reject
                # inserts. SQLite can't drop NOT NULL in place, so this is
                # handled at the application layer (routes/provider.py
                # always sends '' instead of None for these fields).

            # order_id / service_name on otp_logs — only populated when a
            # row comes in through the push webhook (POST
            # /api/provider/receive-code) instead of the polling fetcher.
            if 'otp_logs' in inspector.get_table_names():
                existing_otplog_cols = {c['name'] for c in inspector.get_columns('otp_logs')}
                if 'order_id' not in existing_otplog_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE otp_logs ADD COLUMN order_id VARCHAR(100)"
                        ))
                if 'service_name' not in existing_otplog_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE otp_logs ADD COLUMN service_name VARCHAR(100)"
                        ))
                # 'webhook' vs 'poll' — which route brought this row in —
                # plus a country snapshot from the matched SMS range, so
                # OTP Logs can show/filter by both without extra joins.
                if 'source' not in existing_otplog_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE otp_logs ADD COLUMN source VARCHAR(20) DEFAULT 'poll'"
                        ))
                if 'country' not in existing_otplog_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE otp_logs ADD COLUMN country VARCHAR(100)"
                        ))

            # ip_whitelist on http_endpoints — the single HTTP Connection
            # gateway. Unlike providers.ip_whitelist above, a blank value
            # here means BLOCKED (deny by default), not "any IP" — this
            # endpoint is brand new so there's no pre-existing traffic to
            # stay backwards-compatible with, and defaulting to open on a
            # publicly reachable forward-to-SMPP endpoint is the wrong
            # default to ship. Existing rows get '' from this ALTER TABLE,
            # so upgrading an install effectively blocks the endpoint
            # until an admin explicitly sets 'all' or a real IP/CIDR list.
            if 'http_endpoints' in inspector.get_table_names():
                existing_endpoint_cols = {c['name'] for c in inspector.get_columns('http_endpoints')}
                if 'ip_whitelist' not in existing_endpoint_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE http_endpoints ADD COLUMN ip_whitelist TEXT DEFAULT ''"
                        ))
            # Per-endpoint API key for the HTTP Connection gateway.
            if 'http_endpoints' in inspector.get_table_names():
                existing_ep_cols = {c['name'] for c in inspector.get_columns('http_endpoints')}
                if 'api_token' not in existing_ep_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE http_endpoints ADD COLUMN api_token VARCHAR(64) DEFAULT ''"
                        ))

            # Multi-part SMS tracking: a long message is several parts, and it
            # is only 'delivered' once every part has a DLR.
            if 'smpp_sent_messages' in inspector.get_table_names():
                existing_sent_cols = {c['name'] for c in inspector.get_columns('smpp_sent_messages')}
                for col_name, ddl in {
                    'parts': "ALTER TABLE smpp_sent_messages ADD COLUMN parts INTEGER DEFAULT 1",
                    'parts_delivered': "ALTER TABLE smpp_sent_messages ADD COLUMN parts_delivered INTEGER DEFAULT 0",
                }.items():
                    if col_name not in existing_sent_cols:
                        with db.engine.begin() as conn:
                            conn.execute(_sa_text(ddl))

            # inactivity_penalty / last_penalty_date on wallets — powers the
            # "no activity for 3 days -> profit decays $0.025/day, floored
            # at 0" system.
            if 'wallets' in inspector.get_table_names():
                existing_wallet_cols = {c['name'] for c in inspector.get_columns('wallets')}
                if 'inactivity_penalty' not in existing_wallet_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE wallets ADD COLUMN inactivity_penalty FLOAT DEFAULT 0.0"
                        ))
                if 'last_penalty_date' not in existing_wallet_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE wallets ADD COLUMN last_penalty_date DATE"
                        ))
                if 'last_penalty_at' not in existing_wallet_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE wallets ADD COLUMN last_penalty_at TIMESTAMP"
                        ))

            # sms_cdr — this table was never covered here even though
            # several columns (agent_payout, client_payout, profit,
            # currency, rate, sms_type, duration...) were added to the
            # model over time. On any live DB created before one of these
            # columns existed, every query touching it throws a real SQL
            # error. The agent dashboard is the only place that queries
            # agent_payout directly, so a missing column there manifests
            # as: agent logs in -> dashboard 500s -> the 500 handler
            # redirects back to dashboard -> 500s again -> infinite
            # redirect loop (ERR_TOO_MANY_REDIRECTS), while admin/client
            # dashboards look fine since they don't touch that column.
            if 'sms_cdr' in inspector.get_table_names():
                existing_cdr_cols = {c['name'] for c in inspector.get_columns('sms_cdr')}
                cdr_migrations = {
                    'currency':      "ALTER TABLE sms_cdr ADD COLUMN currency VARCHAR(3) DEFAULT 'USD'",
                    'rate':          "ALTER TABLE sms_cdr ADD COLUMN rate FLOAT DEFAULT 0.0",
                    'agent_payout':  "ALTER TABLE sms_cdr ADD COLUMN agent_payout FLOAT DEFAULT 0.0",
                    'client_payout': "ALTER TABLE sms_cdr ADD COLUMN client_payout FLOAT DEFAULT 0.0",
                    'profit':        "ALTER TABLE sms_cdr ADD COLUMN profit FLOAT DEFAULT 0.0",
                    'sms_type':      "ALTER TABLE sms_cdr ADD COLUMN sms_type VARCHAR(20) DEFAULT 'received'",
                    'status':        "ALTER TABLE sms_cdr ADD COLUMN status VARCHAR(20) DEFAULT 'completed'",
                    'duration':      "ALTER TABLE sms_cdr ADD COLUMN duration INTEGER DEFAULT 0",
                }
                with db.engine.begin() as conn:
                    for col_name, ddl in cdr_migrations.items():
                        if col_name not in existing_cdr_cols:
                            conn.execute(_sa_text(ddl))

            # group_id on combo_numbers / pending_otps — links an uploaded
            # combo batch (and any code parked from it while unresolved)
            # to one specific monitored Telegram group, so masked-number
            # matching can stay scoped per group instead of always
            # searching every uploaded number across all groups.
            if 'combo_numbers' in inspector.get_table_names():
                existing_combo_cols = {c['name'] for c in inspector.get_columns('combo_numbers')}
                if 'group_id' not in existing_combo_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE combo_numbers ADD COLUMN group_id INTEGER"
                        ))
            if 'pending_otps' in inspector.get_table_names():
                existing_pending_cols = {c['name'] for c in inspector.get_columns('pending_otps')}
                if 'group_id' not in existing_pending_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE pending_otps ADD COLUMN group_id INTEGER"
                        ))

            # backup_chat_id on telegram_settings — the chat/group the
            # scheduled DB backup (cron-job.org hitting /api/cron/
            # telegram-backup or /api/backup/export-to-telegram every N
            # minutes) gets sent to, so that job can reuse the same bot
            # configured on the admin Telegram Bot page instead of a
            # separate TELEGRAM_BOT_TOKEN env var in Vercel.
            if 'telegram_settings' in inspector.get_table_names():
                existing_tg_cols = {c['name'] for c in inspector.get_columns('telegram_settings')}
                if 'backup_chat_id' not in existing_tg_cols:
                    with db.engine.begin() as conn:
                        conn.execute(_sa_text(
                            "ALTER TABLE telegram_settings ADD COLUMN backup_chat_id VARCHAR(64)"
                        ))
        except Exception as _mig_err:
            print(f'[schema migration] failed: {_mig_err}')

        # ── One-time auto-import of legacy data ─────────────────────────
        # When this panel used to run on a local SQLite file and is now
        # pointed at a fresh Postgres database (e.g. after moving to
        # Vercel), that Postgres DB starts out empty. app/seed_data/import_
        # data.sql (generated once from the old flash_sms.db) gets loaded
        # here automatically the first time the app boots against an empty
        # database, so the old numbers/users/logs show up immediately
        # without any manual step. It only runs on Postgres, and only if
        # the users table is still empty, so it's a strict one-time thing
        # — after that, the app just keeps writing to the same live DB
        # like normal, no seed file involved.
        try:
            is_postgres = db.engine.url.get_backend_name().startswith('postgres')
            if is_postgres:
                from sqlalchemy import text as _sa_text2
                users_count = db.session.execute(_sa_text2('SELECT COUNT(*) FROM users')).scalar()
                if users_count == 0:
                    seed_path = os.path.join(os.path.dirname(__file__), 'seed_data', 'import_data.sql')
                    if os.path.exists(seed_path):
                        with open(seed_path, 'r', encoding='utf-8') as f:
                            seed_sql = f.read()
                        # Managed Postgres providers (Neon, Supabase, ...)
                        # don't grant the app user permission to run this,
                        # and it isn't actually needed since the file
                        # inserts parents before children.
                        import re as _re2
                        seed_sql = _re2.sub(
                            r'(?im)^\s*SET session_replication_role[^;]*;\s*$', '', seed_sql
                        )
                        raw_conn = db.engine.raw_connection()
                        try:
                            cur = raw_conn.cursor()
                            cur.execute(seed_sql)
                            raw_conn.commit()
                            print('Legacy data imported from seed_data/import_data.sql')
                        except Exception:
                            raw_conn.rollback()
                            raise
                        finally:
                            raw_conn.close()
        except Exception as e:
            print(f'Legacy data auto-import skipped/failed: {e}')

        from app.models.user import User, Role
        from app.models.sms import AgentRangeLimit
        from app.models.wallet import Wallet, WithdrawalRequest
        from app.models.billing import AgentBankAccount, CreditNote
        from app.models.settings import PanelSettings

        # Roles create
        for role_name, display in [
            ('admin', 'Administrator'),
            ('agent', 'Agent'),
            ('client', 'Client'),
            ('developer', 'Developer')
        ]:
            if not Role.query.filter_by(name=role_name).first():
                db.session.add(Role(name=role_name, display_name=display))
        db.session.commit()

        # ── Admin account ───────────────────────────────────────────────
        # The old code created the admin with a fixed password written in
        # the source code (public to anyone who reads the repo) and reset it
        # on every boot. Now the password comes from ADMIN_PASSWORD. If that
        # is not set and no admin exists yet, a random password is generated
        # and written to instance/initial_admin_password.txt (owner-only).
        admin_role = Role.query.filter_by(name='admin').first()
        DEFAULT_ADMIN_USERNAME = (os.environ.get('ADMIN_USERNAME') or 'MohndDravex@987').strip()
        env_admin_password = os.environ.get('ADMIN_PASSWORD') or ''

        # Older deploys used the username 'admin'. Rename it, keeping the
        # existing password unless ADMIN_PASSWORD is set.
        legacy_admin = User.query.filter_by(username='admin').first()
        if (legacy_admin and legacy_admin.is_admin()
                and not User.query.filter_by(username=DEFAULT_ADMIN_USERNAME).first()):
            legacy_admin.username = DEFAULT_ADMIN_USERNAME
            db.session.commit()

        admin_user = User.query.filter_by(username=DEFAULT_ADMIN_USERNAME).first()
        if admin_user is None:
            initial_password = env_admin_password or secrets.token_urlsafe(18)
            admin_user = User(
                username=DEFAULT_ADMIN_USERNAME,
                email='admin@panel.com' if not User.query.filter_by(email='admin@panel.com').first()
                      else f'admin-{secrets.token_hex(4)}@panel.com',
                password_hash=bcrypt.generate_password_hash(initial_password).decode('utf-8'),
                role=admin_role,
                is_active=True,
            )
            db.session.add(admin_user)
            db.session.commit()
            if not env_admin_password:
                _store_initial_admin_password(app, DEFAULT_ADMIN_USERNAME, initial_password)
        elif env_admin_password and not admin_user.check_password(env_admin_password):
            admin_user.set_password(env_admin_password)
            admin_user.is_active = True
            db.session.commit()

        # ── SMPP secrets: widen the column (PostgreSQL) and encrypt legacy rows ──
        # Ciphertext is longer than the old VARCHAR(100), so the type change must
        # run before the rewrite. It is a no-op once applied, and SQLite ignores it.
        try:
            if db.engine.url.get_backend_name().startswith('postgres'):
                from sqlalchemy import text as _sa_text_pg
                with db.engine.begin() as conn:
                    conn.execute(_sa_text_pg('ALTER TABLE sms_gateway_providers ALTER COLUMN smsc_password TYPE TEXT'))
                    conn.execute(_sa_text_pg('ALTER TABLE sms_gateway_providers ALTER COLUMN esme_password TYPE TEXT'))
        except Exception as _pg_err:
            print(f'[schema migration] SMPP password column type update skipped: {_pg_err}')

        try:
            from sqlalchemy import text as _sa_text_enc
            from app import crypto_box as _cb
            if _cb.is_enabled():
                rows = db.session.execute(_sa_text_enc(
                    'SELECT id, smsc_password, esme_password FROM sms_gateway_providers')).fetchall()
                for row in rows:
                    for column, value in (('smsc_password', row[1]), ('esme_password', row[2])):
                        if value and not _cb.is_encrypted(value):
                            db.session.execute(
                                _sa_text_enc(f'UPDATE sms_gateway_providers SET {column} = :v WHERE id = :id'),
                                {'v': _cb.encrypt_value(value), 'id': row[0]})
                db.session.commit()
        except Exception as _enc_err:
            db.session.rollback()
            print(f'[security] SMPP secret encryption migration skipped: {_enc_err}')

        # Per-endpoint API keys for the HTTP Connection gateway (back-fill).
        from app.models.gateway import HttpEndpoint
        changed = False
        for endpoint in HttpEndpoint.query.all():
            if not endpoint.api_token:
                endpoint.api_token = secrets.token_urlsafe(24)
                changed = True
        if changed:
            db.session.commit()

        # Auto create the public Test123 demo account — must always exist,
        # not just after an admin visits the Test Account settings page,
        # otherwise nobody can actually log in with it.
        # It intentionally never gets an api_token: it's a message-testing
        # account only, with no API access.
        agent_role = Role.query.filter_by(name='agent').first()
        if not User.query.filter_by(username='test123').first():
            test_user = User(
                username='test123',
                email='test@voltsms.internal',
                password_hash=bcrypt.generate_password_hash('test123').decode('utf-8'),
                role=agent_role,
                is_active=True
            )
            db.session.add(test_user)
            db.session.commit()

        # ── Serverless (Vercel) guard ───────────────────────────────────
        # On Vercel each request is its own short-lived function instance
        # with no persistent process, so background threads (SMS provider
        # pollers) and an in-process APScheduler simply won't work — the
        # thread/scheduler dies the moment the request ends, and a new one
        # would be spun up on every single invocation, hammering the
        # provider panels. Vercel sets the VERCEL env var automatically,
        # so we use it to skip both here and expose them instead as HTTP
        # endpoints triggered by Vercel Cron (see routes/cron.py).
        IS_SERVERLESS = bool(os.environ.get('VERCEL'))

        if not IS_SERVERLESS:
            from app.fetcher import start_all_providers
            start_all_providers(app)

    # ---- Weekly Credit Note auto-generator (APScheduler) ----
    if not IS_SERVERLESS and (os.environ.get('WERKZEUG_RUN_MAIN') != 'true' or not app.debug):
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            from app.scheduler_jobs import generate_weekly_credit_notes

            scheduler = BackgroundScheduler(daemon=True)
            from app.routes.admin import auto_reclaim_inactive_numbers
            scheduler.add_job(
                func=lambda: generate_weekly_credit_notes(app),
                trigger='interval',
                hours=24,
                id='weekly_credit_note_job',
                replace_existing=True
            )
            scheduler.add_job(
                func=lambda: auto_reclaim_inactive_numbers(app),
                trigger='interval',
                hours=24,
                id='auto_reclaim_inactive_job',
                replace_existing=True
            )
            from app.scheduler_jobs import apply_inactivity_penalties
            scheduler.add_job(
                func=lambda: apply_inactivity_penalties(app),
                trigger='interval',
                hours=1,
                id='inactivity_penalty_job',
                replace_existing=True
            )
            scheduler.start()
        except Exception as e:
            print(f'Scheduler failed to start: {e}')

    if IS_SERVERLESS:
        from app.routes.cron import cron_bp
        app.register_blueprint(cron_bp)

    return app