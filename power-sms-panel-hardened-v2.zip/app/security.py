"""
Security helpers shared by the routes.

Everything here is standard-library only, so it can be imported and tested
without the web stack installed.
"""

import hmac
import ipaddress
import os
import secrets
import socket
import threading
import time
from collections import deque
from urllib.parse import urlsplit


# ── Rate limiting ───────────────────────────────────────────────────────────

class SlidingWindowLimiter:
    """Counts events per key over a sliding time window.

    Thread-safe. Keys are pruned when they go quiet, so memory stays bounded
    even under a flood from many distinct IP addresses."""

    _GC_EVERY = 2000

    def __init__(self):
        self._hits = {}
        self._lock = threading.Lock()
        self._ops = 0

    def _prune(self, dq, window, now):
        cutoff = now - window
        while dq and dq[0] <= cutoff:
            dq.popleft()

    def count(self, key, window):
        now = time.monotonic()
        with self._lock:
            dq = self._hits.get(key)
            if not dq:
                return 0
            self._prune(dq, window, now)
            return len(dq)

    def record(self, key, window):
        """Count one event for ``key`` (used for failures)."""
        now = time.monotonic()
        with self._lock:
            dq = self._hits.setdefault(key, deque())
            self._prune(dq, window, now)
            dq.append(now)
            self._maybe_gc(now, window)

    def consume(self, key, limit, window):
        """Count one event and return True if it is within ``limit``;
        return False (and do not count it) when the key is over the limit."""
        now = time.monotonic()
        with self._lock:
            dq = self._hits.setdefault(key, deque())
            self._prune(dq, window, now)
            allowed = len(dq) < limit
            if allowed:
                dq.append(now)
            self._maybe_gc(now, window)
            return allowed

    def _maybe_gc(self, now, window):
        self._ops += 1
        if self._ops % self._GC_EVERY:
            return
        stale = []
        for key, dq in self._hits.items():
            self._prune(dq, window, now)
            if not dq:
                stale.append(key)
        for key in stale:
            del self._hits[key]


limiter = SlidingWindowLimiter()


# ── Secrets ─────────────────────────────────────────────────────────────────

def secure_equals(provided, expected):
    """Constant-time comparison. An empty expected value never matches."""
    if not expected or provided is None:
        return False
    return hmac.compare_digest(str(provided).encode('utf-8'),
                               str(expected).encode('utf-8'))


def new_token(nbytes=24):
    return secrets.token_urlsafe(nbytes)


def load_or_create_secret(path, env_value=None):
    """Return a secret key.

    Priority: explicit value (environment) -> file at ``path`` -> a new random
    key written to ``path`` with owner-only permissions. Falls back to an
    in-memory random key if the file cannot be written (for example on a
    read-only serverless filesystem); in that case sessions do not survive a
    restart, and the caller should log a warning."""
    if env_value:
        return env_value, 'env'
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            existing = fh.read().strip()
        if existing:
            return existing, 'file'
    except OSError:
        pass
    key = secrets.token_hex(32)
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            fh.write(key)
        return key, 'generated'
    except OSError:
        return key, 'memory'


# ── Outbound URL safety (SSRF guard) ────────────────────────────────────────

def is_public_http_url(url):
    """Return (ok, reason). Only http/https to publicly routable addresses.

    Every resolved address must be global: loopback, private (RFC1918),
    link-local (including cloud metadata 169.254.169.254), multicast and
    reserved ranges are refused. Redirects must be disabled by the caller,
    otherwise a public URL can bounce the request to an internal one."""
    try:
        parts = urlsplit(url or '')
    except ValueError:
        return False, 'Malformed URL'
    if parts.scheme not in ('http', 'https'):
        return False, 'Only http and https URLs are allowed'
    host = parts.hostname
    if not host:
        return False, 'URL has no host'
    try:
        infos = socket.getaddrinfo(host, parts.port or (443 if parts.scheme == 'https' else 80),
                                   proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        return False, 'Host could not be resolved'
    for info in infos:
        address = info[4][0].split('%')[0]
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            return False, 'Unrecognised address'
        if not ip.is_global or ip.is_multicast:
            return False, 'URL points to a private or internal address'
    return True, ''


# ── Misc ────────────────────────────────────────────────────────────────────

def is_safe_relative_path(target):
    """True only for same-site relative paths such as /dashboard?x=1.
    Rejects protocol-relative (//host) and backslash tricks that browsers
    treat as absolute URLs (open redirect)."""
    if not target or not isinstance(target, str):
        return False
    if not target.startswith('/') or target.startswith('//'):
        return False
    if '\\' in target or any(ord(c) < 32 for c in target):
        return False
    return True


def digits_only(value):
    return ''.join(c for c in str(value or '') if c.isdigit())
