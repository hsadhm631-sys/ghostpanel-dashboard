"""
app/telegram_bot.py
The actual Telegram bot "brain": a small state machine driven entirely by
what's stored on TelegramSession, since a webhook handler has no memory
of the previous message. Every admin action available in the web panel
that this bot exposes (create/delete agent or client, add numbers to an
agent, create/delete an SMS range) reuses the exact same DB writes and
safe-delete helpers as app/routes/admin.py, so behavior stays identical
between the web UI and the bot.

Entry point: handle_update(settings, update) — called once per Telegram
update by the webhook route in app/routes/admin.py / app/routes/telegram.py.
"""
from datetime import datetime, timedelta
from sqlalchemy.exc import IntegrityError

from app import db
from app.models.user import User, Role
from app.models.sms import SMDRange, SMSNumber
from app.models.activity import ActivityLog
from app.models.telegram import TelegramSession
from app.telegram_client import (
    send_message, edit_message_text, answer_callback_query,
    delete_message, send_document, download_file,
)

PAGE_SIZE = 6
LOGIN_MAX_ATTEMPTS = 5
LOGIN_LOCK_MINUTES = 10
SKIP_WORDS = ('تخطي', 'skip', '-', 'تجاوز')


# ─────────────────────────── small helpers ───────────────────────────

def esc(s):
    """Minimal HTML-escaping for text interpolated into parse_mode=HTML."""
    if s is None:
        return ''
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def kb(rows):
    """rows: list of list of (text, callback_data) tuples -> Telegram
    inline keyboard markup dict."""
    return {'inline_keyboard': [
        [{'text': t, 'callback_data': c} for t, c in row] for row in rows
    ]}


def is_skip(text):
    return (text or '').strip().lower() in SKIP_WORDS


BULK_FIELD_ALIASES = {
    'name': ['الاسم الكامل', 'الاسم', 'full name', 'fullname', 'name'],
    'username': ['اسم المستخدم', 'يوزر', 'username', 'user name', 'user'],
    'password': ['الباسورد', 'كلمة السر', 'باسورد', 'password', 'pass'],
    'email': ['الايميل', 'الإيميل', 'ايميل', 'إيميل', 'email'],
    'country': ['الدولة', 'دولة', 'country'],
    'contact': ['الرقم', 'رقم الهاتف', 'رقم', 'number', 'phone'],
}


def parse_bulk_account_text(text):
    """Parse a single free-form message with 'label: value' lines (Arabic or
    English labels, any order) into the account-creation fields.
    Returns (data_dict, None) on success or (None, error_message) on failure."""
    values = {}
    for line in (text or '').splitlines():
        if ':' not in line:
            continue
        label, _, value = line.partition(':')
        label = label.strip().lower()
        value = value.strip()
        if not label or not value:
            continue
        for field, aliases in BULK_FIELD_ALIASES.items():
            if field in values:
                continue
            if any(label == a.lower() for a in aliases):
                values[field] = value
                break

    username = values.get('username') or ''
    if not username or ' ' in username:
        return None, "اسم المستخدم ناقص أو فيه مسافة. تأكد من سطر 'اسم المستخدم: ...' من غير مسافات."
    password = values.get('password') or ''
    if len(password) < 4:
        return None, "الباسورد ناقص أو أقل من 4 حروف/أرقام. تأكد من سطر 'الباسورد: ...'."
    email = values.get('email') or ''
    if '@' not in email or '.' not in email:
        return None, "الإيميل ناقص أو غير صحيح. تأكد من سطر 'الايميل: ...'."

    return {
        'name': values.get('name'),
        'username': username,
        'password': password,
        'email': email,
        'country': values.get('country'),
        'contact': values.get('contact'),
    }, None


def edit_or_send(token, sess, message_id, text, reply_markup=None):
    """Try to edit the message the button was attached to (keeps the chat
    tidy); fall back to a fresh message if that fails (e.g. too old)."""
    if message_id:
        res = edit_message_text(token, sess.chat_id, message_id, text, reply_markup=reply_markup)
        if res.get('ok'):
            return
    send_message(token, sess.chat_id, text, reply_markup=reply_markup)


def main_menu_kb():
    return kb([
        [('👤 إدارة الحسابات', 'acc')],
        [('🔎 بحث عن مستخدم', 'usersearch')],
        [('🌍 إدارة الرينجات', 'rng')],
        [('📞 إضافة أرقام لوكيل', 'num')],
        [('🔑 إدارة API', 'api:list:0')],
        [('📊 إحصائيات سريعة', 'stats')],
        [('💾 نسخة كاملة من الداتا', 'dbbackup')],
        [('🚪 تسجيل خروج', 'logout')],
    ])


def show_main_menu(token, sess, note=None):
    sess.state = 'menu'
    sess.set_data({})
    db.session.commit()
    text = (esc_note(note) + "\n\n" if note else "") + "🏠 <b>القائمة الرئيسية</b>\nاختار من تحت 👇"
    send_message(token, sess.chat_id, text, reply_markup=main_menu_kb())


def esc_note(note):
    # notes are pre-built HTML fragments (already escaped where needed),
    # so just pass them through.
    return note


# ─────────────────────────── entry point ───────────────────────────

def handle_update(settings, update):
    token = settings.bot_token
    if 'callback_query' in update:
        handle_callback(token, update['callback_query'])
    elif 'message' in update:
        handle_message(token, update['message'])


# ─────────────────────────── messages (text/documents) ───────────────────────────

def handle_message(token, message):
    chat = message.get('chat', {}) or {}
    chat_id = chat.get('id')
    if chat_id is None:
        return
    text = (message.get('text') or '').strip()
    document = message.get('document')

    sess = TelegramSession.get_or_create(chat_id, chat.get('username'), chat.get('first_name'))

    if sess.locked_until and sess.locked_until > datetime.utcnow():
        mins = max(1, int((sess.locked_until - datetime.utcnow()).total_seconds() // 60) + 1)
        send_message(token, chat_id, f"⏳ تم إيقاف محاولات الدخول مؤقتًا. حاول تاني بعد {mins} دقيقة.")
        return

    if text == '/start':
        user = User.query.get(sess.user_id) if sess.user_id else None
        if user and user.is_admin() and user.is_active:
            show_main_menu(token, sess)
        else:
            start_login(token, sess)
        return

    if text == '/cancel':
        user = User.query.get(sess.user_id) if sess.user_id else None
        if user and user.is_admin() and user.is_active:
            show_main_menu(token, sess, note='❌ تم إلغاء العملية الحالية.')
        else:
            start_login(token, sess)
        return

    if text == '/menu':
        user = User.query.get(sess.user_id) if sess.user_id else None
        if user and user.is_admin() and user.is_active:
            show_main_menu(token, sess)
        else:
            start_login(token, sess)
        return

    if not sess.user_id:
        handle_login_text(token, sess, text, message)
        return

    user = User.query.get(sess.user_id)
    if not user or not user.is_admin() or not user.is_active:
        sess.user_id = None
        sess.state = 'login_username'
        sess.set_data({})
        db.session.commit()
        send_message(token, chat_id, "⚠️ حساب الأدمن المرتبط بقى غير متاح. سجل دخول تاني:")
        start_login(token, sess)
        return

    handle_menu_text(token, sess, user, text, document, message)


def start_login(token, sess):
    sess.state = 'login_username'
    sess.set_data({})
    sess.user_id = None
    db.session.commit()
    send_message(
        token, sess.chat_id,
        "🤖 <b>أهلاً بيك في FLASH SMS Bot</b>\n\n"
        "البوت ده مخصص لحساب <b>الأدمن</b> بس، وبيديك تحكم كامل من تليجرام:\n"
        "➕ إنشاء وحذف حسابات (وكلاء / عملاء)\n"
        "📞 إضافة أرقام لوكيل\n"
        "🌍 إضافة وحذف رينجات\n"
        "📊 إحصائيات سريعة\n\n"
        "🔑 ابعت <b>اسم المستخدم</b> بتاع حساب الأدمن عشان تدخل:"
    )


def handle_login_text(token, sess, text, message):
    if not text:
        send_message(token, sess.chat_id, "من فضلك ابعت اسم المستخدم كنص.")
        return
    data = sess.get_data()

    if sess.state == 'login_username':
        data['username'] = text
        sess.set_data(data)
        sess.state = 'login_password'
        db.session.commit()
        send_message(token, sess.chat_id, "🔒 تمام، دلوقتي ابعت <b>الباسورد</b>:")
        return

    if sess.state == 'login_password':
        username = data.get('username', '')
        user = User.query.filter_by(username=username).first()
        ok = bool(user and user.is_active and user.is_admin() and user.check_password(text))

        # best-effort: wipe the password from the chat history
        msg_id = message.get('message_id')
        if msg_id:
            try:
                delete_message(token, sess.chat_id, msg_id)
            except Exception:
                pass

        if ok:
            sess.user_id = user.id
            sess.failed_attempts = 0
            sess.locked_until = None
            sess.set_data({})
            db.session.commit()
            ActivityLog.log(user.id, 'telegram_login',
                             f'Logged into Telegram bot (chat {sess.chat_id})')
            show_main_menu(token, sess, note=f"✅ أهلاً <b>{esc(user.username)}</b>! تم تسجيل الدخول بنجاح.")
        else:
            sess.failed_attempts = (sess.failed_attempts or 0) + 1
            if sess.failed_attempts >= LOGIN_MAX_ATTEMPTS:
                sess.locked_until = datetime.utcnow() + timedelta(minutes=LOGIN_LOCK_MINUTES)
                sess.state = 'login_username'
                sess.failed_attempts = 0
                sess.set_data({})
                db.session.commit()
                send_message(token, sess.chat_id,
                             f"🚫 محاولات كتير غلط. البوت اتقفل {LOGIN_LOCK_MINUTES} دقايق.")
            else:
                remaining = LOGIN_MAX_ATTEMPTS - sess.failed_attempts
                sess.state = 'login_username'
                db.session.commit()
                send_message(token, sess.chat_id,
                             f"❌ بيانات غلط أو الحساب مش أدمن. باقيلك {remaining} محاولات.\n"
                             f"ابعت اسم المستخدم تاني أو /start.")
        return


def handle_menu_text(token, sess, user, text, document, message):
    state = sess.state
    data = sess.get_data()

    if document and state != 'ra_numbers':
        send_message(token, sess.chat_id, "مش محتاج ملف دلوقتي، استخدم الأزرار تحت 👇", reply_markup=main_menu_kb())
        sess.state = 'menu'
        db.session.commit()
        return

    if not text and not document:
        send_message(token, sess.chat_id, "من فضلك ابعت رسالة نصية.")
        return

    # ---------------- type-the-username-directly states (skip the list) ----------------
    if state in ('search_del_user', 'search_ca_agent', 'search_api_user', 'search_num_agent', 'search_global_user'):
        handle_username_search(token, sess, user, state, text)
        return

    # ---------------- create-account: single message with all fields ----------------
    if state == 'ca_bulk':
        msg_id = message.get('message_id')
        parsed, error = parse_bulk_account_text(text)
        # wipe the message from the chat since it contains the plaintext password
        if msg_id:
            try:
                delete_message(token, sess.chat_id, msg_id)
            except Exception:
                pass
        if error:
            send_message(token, sess.chat_id, f"⚠️ {error}\n\nابعت البيانات تاني بنفس الشكل في رسالة واحدة:")
            return
        if User.query.filter_by(username=parsed['username']).first():
            send_message(token, sess.chat_id, "⚠️ اسم المستخدم ده موجود بالفعل، ابعت البيانات تاني باسم مستخدم مختلف:")
            return
        if User.query.filter_by(email=parsed['email']).first():
            send_message(token, sess.chat_id, "⚠️ الإيميل ده مستخدم بالفعل، ابعت البيانات تاني بإيميل مختلف:")
            return
        data.update(parsed)
        sess.set_data(data)
        if data.get('role') == 'client':
            sess.state = 'ca_pick_agent'
            db.session.commit()
            show_agent_picker_for_client(token, sess, page=0)
        else:
            sess.state = 'menu'
            db.session.commit()
            finalize_create_account(token, sess, user, data, agent_id=None)
        return

    # ---------------- range creation wizard ----------------
    if state == 'ra_name':
        data['name'] = None if is_skip(text) else text
        sess.set_data(data)
        sess.state = 'ra_prefix'
        db.session.commit()
        send_message(token, sess.chat_id, "🔢 ابعت الـ Prefix بتاع الرينج (مثال: 20111):")
        return

    if state == 'ra_prefix':
        if not text:
            send_message(token, sess.chat_id, "الـ Prefix مطلوب، ابعته تاني:")
            return
        data['prefix'] = text
        sess.set_data(data)
        sess.state = 'ra_country'
        db.session.commit()
        send_message(token, sess.chat_id, "🌍 ابعت اسم الدولة:")
        return

    if state == 'ra_country':
        if not text:
            send_message(token, sess.chat_id, "اسم الدولة مطلوب، ابعته تاني:")
            return
        data['country'] = text
        sess.set_data(data)
        sess.state = 'ra_daily'
        db.session.commit()
        send_message(token, sess.chat_id, "📅 الحد اليومي للأرقام (أو ابعت 'تخطي' لقيمة افتراضية 50):")
        return

    if state == 'ra_daily':
        if is_skip(text):
            data['daily_limit'] = 50
        else:
            try:
                data['daily_limit'] = max(0, int(text))
            except ValueError:
                send_message(token, sess.chat_id, "ابعت رقم صحيح أو 'تخطي':")
                return
        sess.set_data(data)
        sess.state = 'ra_payout'
        db.session.commit()
        send_message(token, sess.chat_id, "💰 قيمة الـ Payout لكل رقم (أو ابعت 'تخطي' = 0):")
        return

    if state == 'ra_payout':
        if is_skip(text):
            data['payout'] = 0.0
        else:
            try:
                data['payout'] = float(text)
            except ValueError:
                send_message(token, sess.chat_id, "ابعت رقم أو 'تخطي':")
                return
        sess.set_data(data)
        sess.state = 'ra_numbers'
        db.session.commit()
        send_message(
            token, sess.chat_id,
            "📄 دلوقتي ابعت ملف الأرقام (.txt أو .csv — رقم في كل سطر)، "
            "أو ابعت <b>تخطي</b> لإنشاء الرينج من غير أرقام دلوقتي."
        )
        return

    if state == 'ra_numbers':
        if document:
            finalize_create_range(token, sess, user, data, document=document)
        elif is_skip(text):
            finalize_create_range(token, sess, user, data, document=None)
        else:
            send_message(token, sess.chat_id, "ابعت ملف الأرقام كـ Document، أو اكتب 'تخطي'.")
        return

    # ---------------- add numbers to agent: count step ----------------
    if state == 'na_count':
        try:
            count = int(text)
            if count <= 0:
                raise ValueError()
        except ValueError:
            send_message(token, sess.chat_id, "ابعت عدد صحيح أكبر من صفر:")
            return
        finalize_add_numbers(token, sess, user, data, count)
        return

    # idle / unknown state -> nudge back to the menu
    send_message(token, sess.chat_id, "استخدم الأزرار تحت 👇", reply_markup=main_menu_kb())
    sess.state = 'menu'
    db.session.commit()


# ── shared handler for every "type the username directly instead of
#    scrolling the list" entry point, plus the standalone global lookup ──

def handle_username_search(token, sess, admin_user, state, text):
    query_text = (text or '').strip().lstrip('@')
    if not query_text:
        send_message(token, sess.chat_id, "من فضلك اكتب اسم المستخدم.")
        return

    if state == 'search_del_user':
        q = (User.query.filter(User.role.has(Role.name.in_(['agent', 'client'])))
             .filter(User.username != 'Test123'))
    elif state in ('search_ca_agent', 'search_num_agent'):
        q = User.query.filter(User.role.has(name='agent')).filter(User.username != 'Test123')
    elif state == 'search_api_user':
        q = User.query.filter(User.is_active == True)
    else:  # search_global_user — any account, any role
        q = User.query.filter(User.username != 'Test123')

    exact = q.filter(db.func.lower(User.username) == query_text.lower()).first()
    matches = [exact] if exact else (
        q.filter(User.username.ilike(f'%{query_text}%')).order_by(User.username).limit(6).all()
    )

    if not matches:
        sess.state = 'menu'
        db.session.commit()
        send_message(token, sess.chat_id, f"⚠️ مفيش يوزر بالاسم ده: <b>{esc(query_text)}</b>",
                     reply_markup=kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
        return

    if len(matches) > 1:
        # several close matches — let them tap the right one instead of retyping
        cb_prefix = {
            'search_del_user': 'acc:del:pick',
            'search_ca_agent': 'ca:agent',
            'search_num_agent': 'num:agent:pick',
            'search_api_user': 'api:view',
            'search_global_user': 'usersearch:view',
        }[state]
        rows = [[(f"👤 {m.username}", f'{cb_prefix}:{m.id}')] for m in matches]
        sess.state = 'menu'
        db.session.commit()
        send_message(token, sess.chat_id,
                     f"🔎 لقيت أكتر من يوزر قريب من <b>{esc(query_text)}</b>، اختار الصح:", reply_markup=kb(rows))
        return

    target = matches[0]
    sess.state = 'menu'
    db.session.commit()

    if state == 'search_del_user':
        if target.is_admin():
            send_message(token, sess.chat_id, "🚫 مينفعش تمسح حساب أدمن من البوت.", reply_markup=kb([[('⬅️ رجوع', 'acc')]]))
            return
        role_ar = 'وكيل' if target.is_agent() else ('عميل' if target.is_client() else (target.role.display_name if target.role else '-'))
        send_message(token, sess.chat_id,
            f"⚠️ متأكد إنك عايز تمسح الحساب ده؟ الإجراء مينفعش يترجع.\n\n👤 {esc(target.username)}\n🏷️ {role_ar}",
            reply_markup=kb([
                [('✅ تأكيد الحذف', f'acc:del:confirm:{target.id}')],
                [('❌ إلغاء', 'acc:del:list:0')],
            ]))
        return

    if state == 'search_ca_agent':
        data = sess.get_data()
        finalize_create_account(token, sess, admin_user, data, agent_id=target.id, message_id=None)
        return

    if state == 'search_api_user':
        show_api_token(token, sess, None, target.id)
        return

    if state == 'search_num_agent':
        data = sess.get_data()
        data['agent_id'] = target.id
        sess.set_data(data)
        db.session.commit()
        show_range_list_for_numbers(token, sess, None, 0)
        return

    if state == 'search_global_user':
        show_user_profile_card(token, sess, target.id)
        return


def show_user_profile_card(token, sess, user_id, message_id=None):
    """Quick lookup card for the global '🔎 بحث عن مستخدم' entry point —
    profile summary plus one-tap shortcuts into the flows that already
    exist (delete / API token / add numbers), so typing a username once
    is enough no matter what the admin wants to do with them next."""
    u = User.query.get(user_id)
    if not u:
        edit_or_send(token, sess, message_id, "⚠️ المستخدم مش موجود.", kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
        return

    role_ar = 'أدمن' if u.is_admin() else ('وكيل' if u.is_agent() else ('عميل' if u.is_client() else (u.role.display_name if u.role else '-')))
    numbers_count = SMSNumber.query.filter(
        (SMSNumber.agent_id == u.id) | (SMSNumber.client_id == u.id)
    ).count()
    joined = u.created_at.strftime('%Y-%m-%d') if u.created_at else '—'

    text = (
        f"👤 <b>{esc(u.username)}</b>\n"
        f"🏷️ النوع: {role_ar}\n"
        f"🟢 الحالة: {'مفعّل' if u.is_active else 'موقوف'}\n"
        f"📛 الاسم: {esc(u.name) if u.name else '—'}\n"
        f"🌍 الدولة: {esc(u.country) if u.country else '—'}\n"
        f"📞 الأرقام المرتبطة: {numbers_count}\n"
        f"✉️ إجمالي SMS: {u.sms_count or 0}\n"
        f"📅 تاريخ الإنشاء: {joined}"
    )
    rows = []
    if u.is_agent() and not u.is_admin():
        rows.append([('📞 إضافة أرقام له', f'num:agent:pick:{u.id}')])
    if not u.is_admin():
        rows.append([('🔑 عرض API Token', f'api:view:{u.id}')])
        rows.append([('🗑️ حذف الحساب', f'acc:del:pick:{u.id}')])
    rows.append([('🔎 بحث تاني', 'usersearch')])
    rows.append([('⬅️ القائمة الرئيسية', 'menu')])
    edit_or_send(token, sess, message_id, text, kb(rows))


# ─────────────────────────── callback (inline button) handling ───────────────────────────

def handle_callback(token, cq):
    msg = cq.get('message', {}) or {}
    chat = msg.get('chat', {}) or {}
    chat_id = chat.get('id')
    message_id = msg.get('message_id')
    cq_id = cq.get('id')
    cdata = cq.get('data', '') or ''
    if chat_id is None:
        return

    sess = TelegramSession.get_or_create(chat_id)
    if cq_id:
        answer_callback_query(token, cq_id)

    user = User.query.get(sess.user_id) if sess.user_id else None
    if not user or not user.is_admin() or not user.is_active:
        sess.user_id = None
        sess.state = 'login_username'
        db.session.commit()
        edit_or_send(token, sess, message_id, "⚠️ لازم تسجل دخول الأول. ابعت /start")
        return

    parts = cdata.split(':')
    root = parts[0]

    if root == 'menu':
        sess.state = 'menu'
        sess.set_data({})
        db.session.commit()
        edit_or_send(token, sess, message_id, "🏠 <b>القائمة الرئيسية</b>\nاختار من تحت 👇", main_menu_kb())
        return

    if root == 'stats':
        show_stats(token, sess, message_id)
        return

    if root == 'dbbackup':
        send_db_backup_now(token, sess, message_id)
        return

    if root == 'usersearch':
        if len(parts) > 2 and parts[1] == 'view':
            show_user_profile_card(token, sess, int(parts[2]), message_id)
            return
        sess.state = 'search_global_user'
        sess.set_data({})
        db.session.commit()
        edit_or_send(token, sess, message_id,
                     "🔎 اكتب اسم المستخدم اللي عايز تدور عليه (تقدر تكتب جزء منه):",
                     kb([[('⬅️ رجوع', 'menu')]]))
        return

    if root == 'logout':
        sess.user_id = None
        sess.state = 'login_username'
        sess.set_data({})
        db.session.commit()
        edit_or_send(token, sess, message_id, "👋 تم تسجيل الخروج. ابعت /start لتسجيل الدخول تاني.")
        return

    if root == 'acc':
        handle_acc_callback(token, sess, user, parts, message_id)
        return

    if root == 'rng':
        handle_rng_callback(token, sess, user, parts, message_id)
        return

    if root == 'num':
        handle_num_callback(token, sess, user, parts, message_id)
        return

    if root == 'ca':
        handle_ca_callback(token, sess, user, parts, message_id)
        return

    if root == 'api':
        handle_api_callback(token, sess, user, parts, message_id)
        return

    edit_or_send(token, sess, message_id, "🏠 <b>القائمة الرئيسية</b>", main_menu_kb())


# ---- API management ----

def handle_api_callback(token, sess, user, parts, message_id):
    sub = parts[1] if len(parts) > 1 else 'list'

    if sub == 'search':
        sess.state = 'search_api_user'
        db.session.commit()
        edit_or_send(token, sess, message_id, "🔎 اكتب اسم المستخدم اللي عايز تشوف الـ API Token بتاعه:",
                     kb([[('⬅️ رجوع', 'api:list:0')]]))
        return

    if sub == 'list':
        page = int(parts[2]) if len(parts) > 2 else 0
        show_api_list(token, sess, message_id, page)
        return

    if sub == 'view':
        show_api_token(token, sess, message_id, int(parts[2]))
        return

    if sub == 'regen':
        do_regen_api_token(token, sess, user, int(parts[2]), message_id)
        return


def show_api_list(token, sess, message_id, page):
    q = User.query.filter(User.is_active == True).order_by(User.username)
    total = q.count()
    items = q.offset(page * PAGE_SIZE).limit(PAGE_SIZE).all()
    rows = [[(f"🔑 {u.username}", f'api:view:{u.id}')] for u in items]
    nav = []
    if page > 0:
        nav.append(('⬅️ السابق', f'api:list:{page-1}'))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(('التالي ➡️', f'api:list:{page+1}'))
    if nav:
        rows.append(nav)
    rows.append([('🔎 اكتب اسم المستخدم', 'api:search')])
    rows.append([('⬅️ رجوع', 'menu')])
    text = "🔑 <b>إدارة API — اختار المستخدم:</b>" if items else "مفيش مستخدمين متاحين."
    edit_or_send(token, sess, message_id, text, kb(rows))


def show_api_token(token, sess, message_id, user_id):
    u = User.query.get(user_id)
    if not u:
        edit_or_send(token, sess, message_id, "⚠️ المستخدم مش موجود.", kb([[('⬅️ رجوع', 'api:list:0')]]))
        return
    if not u.api_token:
        u.generate_api_token()
        db.session.commit()
    text = (f"🔑 <b>API Token</b>\n\n"
            f"👤 المستخدم: <code>{esc(u.username)}</code>\n"
            f"🏷️ النوع: {u.role.display_name if u.role else '-'}\n"
            f"🔐 التوكن:\n<code>{esc(u.api_token)}</code>")
    edit_or_send(token, sess, message_id, text, kb([
        [('🔄 توليد توكن جديد', f'api:regen:{u.id}')],
        [('⬅️ رجوع', 'api:list:0')],
    ]))


def do_regen_api_token(token, sess, admin_user, user_id, message_id):
    u = User.query.get(user_id)
    if not u:
        edit_or_send(token, sess, message_id, "⚠️ المستخدم مش موجود.", kb([[('⬅️ رجوع', 'api:list:0')]]))
        return
    u.generate_api_token()
    db.session.commit()
    ActivityLog.log(admin_user.id, 'admin_api_regenerate',
                     f'Regenerated API token for {u.username} (via Telegram bot)')
    text = (f"✅ <b>تم توليد توكن جديد لـ {esc(u.username)}</b>\n\n"
            f"🔐 التوكن الجديد:\n<code>{esc(u.api_token)}</code>")
    edit_or_send(token, sess, message_id, text, kb([
        [('⬅️ رجوع لقائمة API', 'api:list:0')],
        [('🏠 القائمة الرئيسية', 'menu')],
    ]))


# ---- accounts ----

def handle_acc_callback(token, sess, user, parts, message_id):
    if len(parts) == 1:
        edit_or_send(token, sess, message_id, "👤 <b>إدارة الحسابات</b>", kb([
            [('➕ إنشاء حساب جديد', 'acc:create')],
            [('🗑️ حذف حساب', 'acc:del:list:0')],
            [('⬅️ رجوع', 'menu')],
        ]))
        return

    sub = parts[1]

    if sub == 'create':
        edit_or_send(token, sess, message_id, "اختار نوع الحساب اللي عايز تنشئه:", kb([
            [('🧑\u200d💼 وكيل (Agent)', 'acc:role:agent')],
            [('🙍 عميل (Client)', 'acc:role:client')],
            [('⬅️ رجوع', 'acc')],
        ]))
        return

    if sub == 'role':
        role_name = parts[2]
        sess.state = 'ca_bulk'
        sess.set_data({'role': role_name})
        db.session.commit()
        template = (
            "✍️ ابعت بيانات الحساب <b>في رسالة واحدة</b> بالشكل ده بالظبط، سطر لكل بيانة:\n\n"
            "<code>الاسم الكامل: \n"
            "اسم المستخدم: \n"
            "الباسورد: \n"
            "الايميل: \n"
            "الدولة: \n"
            "الرقم: </code>\n\n"
            "املا القيمة بعد كل \":\" وابعت الرسالة كلها مرة واحدة، والحساب هيتعمل على طول.\n"
            "(الدولة والرقم اختياريين، سيبهم فاضيين لو مش عايز تحطهم)."
        )
        edit_or_send(token, sess, message_id, template, kb([[('⬅️ رجوع', 'acc:create')]]))
        return

    if sub == 'del' and parts[2] == 'search':
        sess.state = 'search_del_user'
        db.session.commit()
        edit_or_send(token, sess, message_id, "🔎 اكتب اسم المستخدم اللي عايز تمسحه (تقدر تكتب جزء منه):",
                     kb([[('⬅️ رجوع', 'acc:del:list:0')]]))
        return

    if sub == 'del' and parts[2] == 'list':
        show_user_delete_list(token, sess, message_id, int(parts[3]))
        return

    if sub == 'del' and parts[2] == 'pick':
        target_id = int(parts[3])
        target = User.query.get(target_id)
        if not target:
            edit_or_send(token, sess, message_id, "⚠️ الحساب مش موجود.", kb([[('⬅️ رجوع', 'acc:del:list:0')]]))
            return
        role_ar = 'وكيل' if target.is_agent() else ('عميل' if target.is_client() else (target.role.display_name if target.role else '-'))
        edit_or_send(
            token, sess, message_id,
            f"⚠️ متأكد إنك عايز تمسح الحساب ده؟ الإجراء مينفعش يترجع.\n\n"
            f"👤 {esc(target.username)}\n🏷️ {role_ar}",
            kb([
                [('✅ تأكيد الحذف', f'acc:del:confirm:{target_id}')],
                [('❌ إلغاء', 'acc:del:list:0')],
            ])
        )
        return

    if sub == 'del' and parts[2] == 'confirm':
        do_delete_user(token, sess, user, int(parts[3]), message_id)
        return


def show_user_delete_list(token, sess, message_id, page):
    q = (User.query
         .filter(User.role.has(Role.name.in_(['agent', 'client'])))
         .filter(User.username != 'Test123')
         .order_by(User.username))
    total = q.count()
    items = q.offset(page * PAGE_SIZE).limit(PAGE_SIZE).all()
    rows = []
    for u in items:
        tag = '🧑\u200d💼' if u.is_agent() else '🙍'
        rows.append([(f"{tag} {u.username}", f'acc:del:pick:{u.id}')])
    nav = []
    if page > 0:
        nav.append(('⬅️ السابق', f'acc:del:list:{page-1}'))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(('التالي ➡️', f'acc:del:list:{page+1}'))
    if nav:
        rows.append(nav)
    rows.append([('🔎 اكتب اسم المستخدم', 'acc:del:search')])
    rows.append([('⬅️ رجوع', 'acc')])
    text = "🗑️ <b>اختار الحساب اللي عايز تمسحه:</b>" if items else "مفيش حسابات وكلاء/عملاء متاحة حاليًا."
    edit_or_send(token, sess, message_id, text, kb(rows))


def do_delete_user(token, sess, admin_user, target_id, message_id):
    from app.routes.admin import _purge_user_children
    target = User.query.get(target_id)
    if not target:
        edit_or_send(token, sess, message_id, "⚠️ الحساب مش موجود.", kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
        return
    if target.is_admin():
        edit_or_send(token, sess, message_id, "🚫 مينفعش تمسح حساب أدمن من البوت.", kb([[('⬅️ رجوع', 'acc')]]))
        return
    username = target.username
    try:
        _purge_user_children(target, admin_user.id)
        db.session.delete(target)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        edit_or_send(token, sess, message_id, f"⚠️ حصل خطأ أثناء حذف {esc(username)}، حاول تاني.",
                     kb([[('⬅️ رجوع', 'acc')]]))
        return
    ActivityLog.log(admin_user.id, 'admin_delete_user', f'Deleted user {username} (via Telegram bot)')
    edit_or_send(token, sess, message_id, f"✅ تم حذف الحساب <b>{esc(username)}</b> بنجاح.",
                 kb([[('⬅️ القائمة الرئيسية', 'menu')]]))


# ---- account creation finalize + agent picker for client ----

def show_agent_picker_for_client(token, sess, page):
    q = (User.query
         .filter(User.role.has(name='agent'))
         .filter(User.username != 'Test123')
         .order_by(User.username))
    total = q.count()
    items = q.offset(page * PAGE_SIZE).limit(PAGE_SIZE).all()
    rows = [[(f"🧑\u200d💼 {a.username}", f'ca:agent:{a.id}')] for a in items]
    nav = []
    if page > 0:
        nav.append(('⬅️ السابق', f'ca:agentlist:{page-1}'))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(('التالي ➡️', f'ca:agentlist:{page+1}'))
    if nav:
        rows.append(nav)
    rows.append([('🔎 اكتب اسم اليوزر', 'ca:agent:search')])
    rows.append([('🚫 بدون وكيل', 'ca:agent:0')])
    send_message(token, sess.chat_id, "🔗 <b>اختار الوكيل اللي هيكون تابعله العميل:</b>", kb(rows))


def handle_ca_callback(token, sess, user, parts, message_id):
    sub = parts[1]
    if sub == 'agentlist':
        show_agent_picker_for_client(token, sess, int(parts[2]))
        return
    if sub == 'agent' and len(parts) > 2 and parts[2] == 'search':
        sess.state = 'search_ca_agent'
        db.session.commit()
        send_message(token, sess.chat_id, "🔎 اكتب اسم اليوزر (الوكيل) اللي عايز تربط بيه العميل:")
        return
    if sub == 'agent':
        agent_id = int(parts[2]) or None
        data = sess.get_data()
        sess.state = 'menu'
        db.session.commit()
        finalize_create_account(token, sess, user, data, agent_id=agent_id, message_id=message_id)
        return


def finalize_create_account(token, sess, admin_user, data, agent_id=None, message_id=None):
    role_name = data.get('role')
    role = Role.query.filter_by(name=role_name).first()
    if not role or not data.get('username') or not data.get('password'):
        edit_or_send(token, sess, message_id, "⚠️ حصل خطأ أثناء إنشاء الحساب، ابدأ تاني من القائمة.",
                     kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
        return
    if User.query.filter_by(username=data['username']).first():
        edit_or_send(token, sess, message_id, "⚠️ اسم المستخدم اتاخد قبل ما تخلص، ابدأ تاني.",
                     kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
        return

    new_user = User(
        username=data['username'], email=data.get('email'), role=role,
        name=data.get('name'), country=data.get('country'), contact=data.get('contact'),
        agent_id=agent_id, is_active=True
    )
    new_user.set_password(data['password'])
    new_user.generate_api_token()
    db.session.add(new_user)
    db.session.commit()

    ActivityLog.log(admin_user.id, 'admin_create_user',
                     f'Created user {new_user.username} with role {role.display_name} (via Telegram bot)')

    role_ar = 'وكيل' if role_name == 'agent' else 'عميل'
    text = (f"✅ <b>تم إنشاء الحساب بنجاح!</b>\n\n"
            f"👤 الاسم الكامل: {esc(new_user.name) if new_user.name else '—'}\n"
            f"🆔 اسم المستخدم: <code>{esc(new_user.username)}</code>\n"
            f"🔑 الباسورد: <code>{esc(data['password'])}</code>\n"
            f"📧 الإيميل: {esc(new_user.email)}\n"
            f"🌍 الدولة: {esc(new_user.country) if new_user.country else '—'}\n"
            f"📱 الرقم: {esc(new_user.contact) if new_user.contact else '—'}\n"
            f"🏷️ النوع: {role_ar}\n")
    if agent_id:
        parent = User.query.get(agent_id)
        if parent:
            text += f"🔗 تابع للوكيل: {esc(parent.username)}\n"
    send_message(token, sess.chat_id, text, reply_markup=kb([[('⬅️ القائمة الرئيسية', 'menu')]]))


# ---- ranges ----

def handle_rng_callback(token, sess, user, parts, message_id):
    if len(parts) == 1:
        edit_or_send(token, sess, message_id, "🌍 <b>إدارة الرينجات</b>", kb([
            [('➕ إضافة رينج جديد', 'rng:add')],
            [('🗑️ حذف رينج', 'rng:del:list:0')],
            [('⬅️ رجوع', 'menu')],
        ]))
        return

    sub = parts[1]

    if sub == 'add':
        sess.state = 'ra_name'
        sess.set_data({})
        db.session.commit()
        edit_or_send(token, sess, message_id, "✍️ ابعت اسم الرينج (أو ابعت 'تخطي'):")
        return

    if sub == 'del' and parts[2] == 'list':
        show_range_delete_list(token, sess, message_id, int(parts[3]))
        return

    if sub == 'del' and parts[2] == 'pick':
        rid = int(parts[3])
        r = SMDRange.query.get(rid)
        if not r:
            edit_or_send(token, sess, message_id, "⚠️ الرينج مش موجود.", kb([[('⬅️ رجوع', 'rng:del:list:0')]]))
            return
        count = SMSNumber.query.filter_by(range_id=rid).count()
        edit_or_send(
            token, sess, message_id,
            f"⚠️ متأكد إنك عايز تمسح الرينج ده؟ هيتمسح معاه كل الأرقام اللي فيه.\n\n"
            f"🌍 {esc(r.country)} — <code>{esc(r.prefix)}</code>\n📞 عدد الأرقام: {count}",
            kb([
                [('✅ تأكيد الحذف', f'rng:del:confirm:{rid}')],
                [('❌ إلغاء', 'rng:del:list:0')],
            ])
        )
        return

    if sub == 'del' and parts[2] == 'confirm':
        do_delete_range(token, sess, user, int(parts[3]), message_id)
        return


def show_range_delete_list(token, sess, message_id, page):
    q = SMDRange.query.order_by(SMDRange.country)
    total = q.count()
    items = q.offset(page * PAGE_SIZE).limit(PAGE_SIZE).all()
    rows = [[(f"🌍 {r.country} - {r.prefix}", f'rng:del:pick:{r.id}')] for r in items]
    nav = []
    if page > 0:
        nav.append(('⬅️ السابق', f'rng:del:list:{page-1}'))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(('التالي ➡️', f'rng:del:list:{page+1}'))
    if nav:
        rows.append(nav)
    rows.append([('⬅️ رجوع', 'rng')])
    text = "🗑️ <b>اختار الرينج اللي عايز تمسحه:</b>" if items else "مفيش رينجات متاحة حاليًا."
    edit_or_send(token, sess, message_id, text, kb(rows))


def do_delete_range(token, sess, admin_user, range_id, message_id):
    from app.routes.admin import _detach_number_history, _purge_range_children
    r = SMDRange.query.get(range_id)
    if not r:
        edit_or_send(token, sess, message_id, "⚠️ الرينج مش موجود.", kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
        return
    info = f'{r.name or r.prefix} - {r.country}'
    number_ids = [n.id for n in SMSNumber.query.filter_by(range_id=range_id).with_entities(SMSNumber.id).all()]
    try:
        _detach_number_history(number_ids)
        _purge_range_children(range_id)
        SMSNumber.query.filter_by(range_id=range_id).delete(synchronize_session=False)
        db.session.delete(r)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        edit_or_send(token, sess, message_id, "⚠️ حصل خطأ أثناء الحذف، حاول تاني.", kb([[('⬅️ رجوع', 'rng')]]))
        return
    ActivityLog.log(admin_user.id, 'admin_delete_range',
                     f'Deleted range {info} ({len(number_ids)} numbers) (via Telegram bot)')
    edit_or_send(token, sess, message_id,
                 f"✅ تم حذف الرينج <b>{esc(info)}</b> ({len(number_ids)} رقم).",
                 kb([[('⬅️ القائمة الرئيسية', 'menu')]]))


def finalize_create_range(token, sess, admin_user, data, document):
    from app.routes.admin import _auto_assign_to_test

    numbers_raw = []
    if document:
        content = download_file(token, document['file_id'])
        if content is None:
            send_message(token, sess.chat_id,
                         "⚠️ حصل خطأ في تنزيل الملف، ابعته تاني أو ابعت 'تخطي'.")
            return
        try:
            text_content = content.decode('utf-8')
        except UnicodeDecodeError:
            text_content = content.decode('latin-1')
        for line in text_content.strip().split('\n'):
            cell = line.split(',')[0].strip()
            if cell:
                numbers_raw.append(cell)

    prefix = data['prefix']
    sms_range = SMDRange(
        name=data.get('name'), prefix=prefix, country=data['country'],
        daily_limit=data.get('daily_limit', 50), payout=data.get('payout', 0.0),
        cost_per_sms=0.005, is_active=True
    )
    db.session.add(sms_range)
    db.session.commit()

    created_count = 0
    skip_count = 0
    if numbers_raw:
        existing_numbers = set(n[0] for n in db.session.query(SMSNumber.number).all())
        for num_str in numbers_raw:
            num_clean = num_str.strip()
            if not num_clean:
                continue
            if not num_clean.startswith(prefix):
                num_clean = f"{prefix}{num_clean}"
            if num_clean in existing_numbers:
                skip_count += 1
                continue
            num = SMSNumber(range_id=sms_range.id, number=num_clean, prefix=prefix,
                             status='available', is_active=True)
            db.session.add(num)
            created_count += 1
            existing_numbers.add(num_clean)
        db.session.commit()

    test_assigned = _auto_assign_to_test(sms_range.id, count=50)

    ActivityLog.log(admin_user.id, 'admin_create_range',
                     f'Created range {sms_range.prefix} and added {created_count} numbers (via Telegram bot)')

    text = (f"✅ <b>تم إنشاء الرينج بنجاح!</b>\n\n"
            f"🌍 الدولة: {esc(data['country'])}\n"
            f"🔢 Prefix: <code>{esc(prefix)}</code>\n"
            f"📅 الحد اليومي: {data.get('daily_limit', 50)}\n"
            f"💰 Payout: {data.get('payout', 0.0)}\n"
            f"📞 أرقام تم إضافتها: {created_count}\n")
    if skip_count:
        text += f"♻️ أرقام متكررة اتجاهلت: {skip_count}\n"
    if test_assigned:
        text += f"🧪 اتعين {test_assigned} رقم لحساب Test123 تلقائيًا\n"
    send_message(token, sess.chat_id, text, reply_markup=kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
    sess.state = 'menu'
    sess.set_data({})
    db.session.commit()


# ---- add numbers to agent ----

def handle_num_callback(token, sess, user, parts, message_id):
    if len(parts) == 1:
        sess.set_data({})
        db.session.commit()
        show_agent_list_for_numbers(token, sess, message_id, 0)
        return

    sub = parts[1]

    if sub == 'agent' and parts[2] == 'search':
        sess.state = 'search_num_agent'
        db.session.commit()
        edit_or_send(token, sess, message_id, "🔎 اكتب اسم اليوزر (الوكيل) اللي عايز تضيفله أرقام:",
                     kb([[('⬅️ رجوع', 'num:agent:list:0')]]))
        return

    if sub == 'agent' and parts[2] == 'list':
        show_agent_list_for_numbers(token, sess, message_id, int(parts[3]))
        return

    if sub == 'agent' and parts[2] == 'pick':
        agent_id = int(parts[3])
        data = sess.get_data()
        data['agent_id'] = agent_id
        sess.set_data(data)
        db.session.commit()
        show_range_list_for_numbers(token, sess, message_id, 0)
        return

    if sub == 'range' and parts[2] == 'list':
        show_range_list_for_numbers(token, sess, message_id, int(parts[3]))
        return

    if sub == 'range' and parts[2] == 'pick':
        range_id = int(parts[3])
        data = sess.get_data()
        data['range_id'] = range_id
        sess.set_data(data)
        sess.state = 'na_count'
        db.session.commit()
        r = SMDRange.query.get(range_id)
        available = SMSNumber.query.filter_by(range_id=range_id, agent_id=None, is_active=True).count()
        edit_or_send(
            token, sess, message_id,
            f"📞 الرينج: {esc(r.country)} - <code>{esc(r.prefix)}</code>\n"
            f"✅ متاح دلوقتي: {available} رقم\n\n"
            f"اكتب عدد الأرقام اللي عايز تضيفها للوكيل:"
        )
        return


def show_agent_list_for_numbers(token, sess, message_id, page):
    q = (User.query
         .filter(User.role.has(name='agent'))
         .filter(User.username != 'Test123')
         .order_by(User.username))
    total = q.count()
    items = q.offset(page * PAGE_SIZE).limit(PAGE_SIZE).all()
    rows = [[(f"🧑\u200d💼 {a.username}", f'num:agent:pick:{a.id}')] for a in items]
    nav = []
    if page > 0:
        nav.append(('⬅️ السابق', f'num:agent:list:{page-1}'))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(('التالي ➡️', f'num:agent:list:{page+1}'))
    if nav:
        rows.append(nav)
    rows.append([('🔎 اكتب اسم اليوزر', 'num:agent:search')])
    rows.append([('⬅️ رجوع', 'menu')])
    text = "📞 <b>اختار الوكيل اللي عايز تضيفله أرقام:</b>" if items else "مفيش وكلاء متاحين حاليًا."
    edit_or_send(token, sess, message_id, text, kb(rows))


def show_range_list_for_numbers(token, sess, message_id, page):
    q = SMDRange.query.filter_by(is_active=True).order_by(SMDRange.country)
    total = q.count()
    items = q.offset(page * PAGE_SIZE).limit(PAGE_SIZE).all()
    rows = [[(f"🌍 {r.country} - {r.prefix}", f'num:range:pick:{r.id}')] for r in items]
    nav = []
    if page > 0:
        nav.append(('⬅️ السابق', f'num:range:list:{page-1}'))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(('التالي ➡️', f'num:range:list:{page+1}'))
    if nav:
        rows.append(nav)
    rows.append([('⬅️ رجوع', 'num')])
    text = "🌍 <b>اختار الرينج:</b>" if items else "مفيش رينجات متاحة حاليًا."
    edit_or_send(token, sess, message_id, text, kb(rows))


def finalize_add_numbers(token, sess, admin_user, data, count):
    agent = User.query.get(data.get('agent_id'))
    sms_range = SMDRange.query.get(data.get('range_id'))
    if not agent or not sms_range:
        send_message(token, sess.chat_id, "⚠️ حصل خطأ، ابدأ تاني من القائمة.",
                     reply_markup=kb([[('⬅️ القائمة الرئيسية', 'menu')]]))
        return

    available = SMSNumber.query.filter_by(range_id=sms_range.id, agent_id=None, is_active=True).limit(count).all()
    if not available:
        show_main_menu(token, sess, note="⚠️ مفيش أرقام متاحة في الرينج ده دلوقتي.")
        return

    added_numbers = []
    for num in available:
        num.agent_id = agent.id
        num.status = 'reserved'
        num.assigned_at = datetime.utcnow()
        num.agent_payout = sms_range.payout or 0.0
        added_numbers.append(num.number)
    db.session.commit()

    ActivityLog.log(admin_user.id, 'admin_add_numbers_to_agent',
                     f'Added {len(added_numbers)} numbers from {sms_range.prefix} to agent {agent.username} (via Telegram bot)')

    note = (f"✅ <b>تم إضافة {len(added_numbers)} رقم</b> من رينج "
            f"<code>{esc(sms_range.prefix)}</code> للوكيل <b>{esc(agent.username)}</b>.")
    show_main_menu(token, sess, note=note)

    txt_content = '\n'.join(added_numbers) + '\n'
    filename = f"{agent.username}_{sms_range.prefix}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.txt"
    send_document(token, sess.chat_id, filename, txt_content.encode('utf-8'), caption='📄 الأرقام اللي تمت إضافتها')


# ---- quick stats ----

def show_stats(token, sess, message_id):
    from app.models.sms import SMSCDR
    from datetime import date

    total_agents = User.query.filter(User.role.has(name='agent')).filter(User.username != 'Test123').count()
    total_clients = User.query.filter(User.role.has(name='client')).count()
    total_numbers = SMSNumber.query.count()
    total_ranges = SMDRange.query.filter_by(is_active=True).count()
    today_sms = SMSCDR.query.filter(db.func.date(SMSCDR.created_at) == date.today()).count()

    text = (f"📊 <b>إحصائيات سريعة</b>\n\n"
            f"🧑\u200d💼 الوكلاء: {total_agents}\n"
            f"🙍 العملاء: {total_clients}\n"
            f"📞 إجمالي الأرقام: {total_numbers}\n"
            f"🌍 الرينجات النشطة: {total_ranges}\n"
            f"💬 رسائل SMS اليوم: {today_sms}\n")
    edit_or_send(token, sess, message_id, text, kb([[('⬅️ رجوع', 'menu')]]))


def send_db_backup_now(token, sess, message_id):
    """Handler for the '💾 نسخة كاملة من الداتا' button: builds a fresh
    snapshot of every table in the live database as a .db file and sends
    it into this same chat immediately (on top of the automatic backup
    that an external cron hits every 15 minutes via
    /api/cron/telegram-backup — see app/db_backup.py for the shared
    export code both paths use)."""
    from app.db_backup import build_full_db_backup, build_caption

    edit_or_send(token, sess, message_id, "⏳ بتجهز نسخة كاملة من الداتا دلوقتي...")
    try:
        file_bytes, filename, exported = build_full_db_backup()
        caption = build_caption(exported)
        send_document(token, sess.chat_id, filename, file_bytes, caption=caption)
        send_message(token, sess.chat_id, "✅ اتبعتت النسخة.", reply_markup=kb([[('⬅️ رجوع', 'menu')]]))
    except Exception as e:
        send_message(token, sess.chat_id, f"❌ حصل خطأ أثناء تجهيز النسخة:\n{esc(str(e))}",
                     reply_markup=kb([[('⬅️ رجوع', 'menu')]]))
