"""
app/db_backup.py
Single shared implementation for "export the whole live database into one
SQLite .db file" — used by BOTH:
  - app/routes/cron.py  -> /api/cron/telegram-backup   (hit every 15 min by
    an external scheduler like cron-job.org, since Vercel's own Cron is
    capped at once/day on the free Hobby plan)
  - app/telegram_bot.py -> the "💾 نسخة كاملة من الداتا" button, so an
    admin can also pull a fresh backup on demand straight from the bot,
    not just wait for the next scheduled tick.

Keeping this in one place means both paths always produce an identical
file (same tables, same column handling) instead of slowly drifting apart.
"""
import os
import sqlite3
import tempfile
import uuid
from datetime import datetime

from sqlalchemy import inspect as sa_inspect, text as sa_text

from app import db


def build_full_db_backup():
    """Snapshot every table in the live database (SQLite or Postgres) into
    a fresh local SQLite file and return (file_bytes, filename, exported)
    where `exported` is {table_name: row_count}.

    All values are stringified on the way in, same as the original
    /api/cron/telegram-backup implementation — this is a portable,
    read-only snapshot for backup/inspection, not a byte-perfect clone of
    column types.
    """
    tmp_path = os.path.join(tempfile.gettempdir(), f'flash_sms_backup_{uuid.uuid4().hex}.db')
    if os.path.exists(tmp_path):
        os.remove(tmp_path)

    inspector = sa_inspect(db.engine)
    table_names = inspector.get_table_names()

    sconn = sqlite3.connect(tmp_path)
    scur = sconn.cursor()
    exported = {}
    try:
        for t in table_names:
            cols = [c['name'] for c in inspector.get_columns(t)]
            if not cols:
                continue
            col_list_sql = ', '.join(f'"{c}" TEXT' for c in cols)
            scur.execute(f'CREATE TABLE "{t}" ({col_list_sql})')

            rows = db.session.execute(sa_text(f'SELECT * FROM "{t}"')).fetchall()
            if rows:
                placeholders = ', '.join('?' for _ in cols)
                scur.executemany(
                    f'INSERT INTO "{t}" VALUES ({placeholders})',
                    [tuple(str(v) if v is not None else None for v in row) for row in rows]
                )
            exported[t] = len(rows)
        sconn.commit()
    finally:
        sconn.close()

    with open(tmp_path, 'rb') as f:
        file_bytes = f.read()
    os.remove(tmp_path)

    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    filename = f'flash_sms_backup_{timestamp}.db'
    return file_bytes, filename, exported


def build_caption(exported, prefix='💾 نسخة احتياطية كاملة للداتا'):
    """Human-friendly Telegram caption: table:count pairs + UTC timestamp,
    trimmed to Telegram's 1024-char caption limit."""
    now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    total_rows = sum(exported.values())
    counts_line = ', '.join(f'{k}:{v}' for k, v in sorted(exported.items()))
    caption = f'{prefix}\n🕒 {now}\n📦 {len(exported)} جدول / {total_rows} صف\n{counts_line}'
    return caption[:1024]
