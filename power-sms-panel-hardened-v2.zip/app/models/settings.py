from app import db
from datetime import datetime


class PanelSettings(db.Model):
    """Singleton row (id=1) holding white-label branding for the panel."""
    __tablename__ = 'panel_settings'

    id = db.Column(db.Integer, primary_key=True)
    panel_name = db.Column(db.String(100), default='VOLT SMS')
    logo_filename = db.Column(db.String(255))  # stored under app/static/img/uploads/
    primary_color = db.Column(db.String(9), default='#4f46e5')   # --accent
    secondary_color = db.Column(db.String(9), default='#38bdf8')  # --accent-light
    theme = db.Column(db.String(30), default='flashv2')  # panel-wide visual theme, see THEMES
    login_theme = db.Column(db.String(30), default='default')  # login page visual theme, see LOGIN_THEMES
    test_account_max_numbers = db.Column(db.Integer, default=200)  # cap on numbers the Test account may hold
    # ── Design Editor (admin-only, applies to everyone) ──────────────────
    # When custom_design_enabled is True, custom_colors overrides the
    # picked `theme`'s palette instead of using it. dashboard_layout stores
    # per-view card order/visibility (see DASHBOARD_CARDS below).
    custom_design_enabled = db.Column(db.Boolean, default=False)
    custom_colors = db.Column(db.Text)   # JSON string, keys = CUSTOM_COLOR_FIELDS
    dashboard_layout = db.Column(db.Text)  # JSON string: {"agent": [...], "admin": [...]}
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Available panel themes: each is a fully different look (palette + card
    # style), not just a color swap. Keyed by the value stored in `theme`.
    THEMES = {
        'default': {
            'label': 'Flash (Default)',
            'desc': 'The classic indigo/cyan Flash SMS look.',
            'swatch': ['#0a0e27', '#4f46e5', '#38bdf8'],
        },
        'midnight': {
            'label': 'Midnight',
            'desc': 'Deep black-blue, violet accents. Flat & sharp: square corners, no shadows, glowing left-border cards.',
            'swatch': ['#05070f', '#8b5cf6', '#22d3ee'],
        },
        'sunset': {
            'label': 'Sunset',
            'desc': 'Warm charcoal, orange/pink accents. Soft & rounded: pill-shaped cards with a gentle amber glow.',
            'swatch': ['#1a1210', '#f97316', '#ec4899'],
        },
        'emerald': {
            'label': 'Emerald',
            'desc': 'Slate background, green/teal accents. Calm & minimal: completely flat cards with a slim top accent bar.',
            'swatch': ['#0b1512', '#10b981', '#34d399'],
        },
        'crimson': {
            'label': 'Crimson',
            'desc': 'Near-black, red/amber accents. Bold & dramatic: sharp corners, heavy shadow, extra-bold headers.',
            'swatch': ['#120707', '#dc2626', '#f59e0b'],
        },
        'light': {
            'label': 'Daylight',
            'desc': 'Clean white theme, indigo/cyan accents. Soft daylight shadows and generous rounding for bright rooms.',
            'swatch': ['#f3f4f6', '#4338ca', '#0ea5e9'],
        },
        'neon': {
            'label': 'Neon',
            'desc': 'Near-black red glow, every stat card gets its own neon-colored border (blue/orange/green/purple/pink/teal). Big rounded glass cards.',
            'swatch': ['#0d0406', '#ff375f', '#3b82f6'],
        },
        'glass': {
            'label': 'Glass',
            'desc': 'Frosted translucent panels with blur, floating shadows, no hard borders, extra-large rounding. A completely different structure, not just colors.',
            'swatch': ['#0f172a', '#38bdf8', '#818cf8'],
        },
        'snow': {
            'label': 'Snow (Plain White)',
            'desc': 'Pure flat white/grey theme, monochrome slate accent, thin hairline borders, tiny rounding, zero colored shadows. The plainest, most neutral look.',
            'swatch': ['#f8fafc', '#334155', '#64748b'],
        },
        'mono': {
            'label': 'Mono (Light/Dark)',
            'desc': 'True neutral theme: bright light-white in light mode, soft "light black" charcoal (never pure black) in dark mode. No color tint, flat minimal cards with hairline borders.',
            'swatch': ['#1a1a1a', '#525252', '#e5e5e5'],
        },
        'ocean': {
            'label': 'Ocean',
            'desc': 'Deep-sea blues and cyan. Rounded cards with a glowing wave-blue top border and a soft cyan shadow.',
            'swatch': ['#071a2c', '#0ea5e9', '#22d3ee'],
        },
        'royal': {
            'label': 'Royal Gold',
            'desc': 'Regal purple background with gold trim. Every card gets a thin gold hairline border and a subtle golden glow.',
            'swatch': ['#0f0a1e', '#c9a227', '#7c3aed'],
        },
        'cyber': {
            'label': 'Cyber Terminal',
            'desc': 'Black hacker-terminal look with neon green/cyan. Sharp square corners, monospace stat numbers, glowing top scanline on every card.',
            'swatch': ['#050807', '#00ff9d', '#00d1ff'],
        },
        'rose': {
            'label': 'Rose',
            'desc': 'Soft blush pink, airy and gentle. Fully pill-rounded, borderless cards floating on a pink-tinted shadow.',
            'swatch': ['#1f0f17', '#ec4899', '#f9a8d4'],
        },
        'coffee': {
            'label': 'Coffee & Cream',
            'desc': 'Warm browns and cream tones. Cozy cards with a cream inner highlight and a soft brown shadow.',
            'swatch': ['#1c140d', '#b8845a', '#e0b989'],
        },
        'arctic': {
            'label': 'Arctic',
            'desc': 'Icy blue-white, very bright and airy. Frosted glass cards with hairline ice-blue borders — a second, cooler light theme.',
            'swatch': ['#eef6fb', '#0284c7', '#38bdf8'],
        },
        'forest': {
            'label': 'Forest',
            'desc': 'Deep woodland green-brown, earthy and organic. Softly rounded cards with a mossy inner glow.',
            'swatch': ['#0e150f', '#65a30d', '#a3e635'],
        },
        'obsidian': {
            'label': 'Obsidian',
            'desc': 'Pure volcanic black with molten orange/gold embers. Sharp glass-shard corners, glowing ember top edge on every card.',
            'swatch': ['#000000', '#f97316', '#fbbf24'],
        },
        'candy': {
            'label': 'Candy Pop',
            'desc': 'Playful near-black canvas, every stat card gets its own bright pastel-candy color (mint/lilac/peach/sky). Big bouncy rounded cards.',
            'swatch': ['#120b1a', '#a78bfa', '#5eead4'],
        },
        'steel': {
            'label': 'Steel',
            'desc': 'Industrial blue-grey metal. Flat brushed-steel cards, thin cyan seam on top, monospace numbers — technical control-room feel.',
            'swatch': ['#12171c', '#64748b', '#38bdf8'],
        },
        'flysms': {
            'label': 'FlySMS Style',
            'desc': 'Flat card-grid SaaS look with small round color-badge icons per stat card — full light AND dark mode support (charcoal cards in dark mode, white cards in light mode), matching both variants of the reference dashboard.',
            'swatch': ['#f4f5f9', '#6f4ee8', '#0ea5e9'],
        },
        'flashv2': {
            'label': 'V2 Flash',
            'desc': 'Deep violet-black dashboard with a colorful round icon badge on every stat card, a purple filled line chart, and full light/dark support — matches the newest reference design.',
            'swatch': ['#17101f', '#6f4ee8', '#22c55e'],
        },
    }

    # Available login-page themes: each is a structurally distinct layout
    # (not just a recolor) that the admin can switch on the Login Themes
    # settings page. Keyed by the value stored in `login_theme`.
    LOGIN_THEMES = {
        'default': {
            'label': 'Flash (Default)',
            'desc': 'Centered card on a deep indigo/violet gradient. Indigo->cyan gradient button.',
            'swatch': ['#0a0e27', '#4338ca', '#0ea5e9'],
        },
        'minimal': {
            'label': 'Minimal Solid',
            'desc': 'Flat solid slate background, sharp-cornered flat card, single monochrome accent. No gradients, no glow.',
            'swatch': ['#0f172a', '#1e293b', '#64748b'],
        },
        'split': {
            'label': 'Split Screen',
            'desc': 'Two-column layout: colorful brand panel on one side, plain white form panel on the other. Completely different structure.',
            'swatch': ['#ffffff', '#7c3aed', '#ec4899'],
        },
        'aurora': {
            'label': 'Aurora (Vibrant)',
            'desc': 'Full-bleed multi-color animated gradient background with a frosted glass, blurred, translucent card floating on top.',
            'swatch': ['#4c1d95', '#db2777', '#0ea5e9'],
        },
        'daylight': {
            'label': 'Daylight (Plain White)',
            'desc': 'Solid plain white/light-grey background, soft light card, indigo accent. Clean and simple, no dark tones anywhere.',
            'swatch': ['#f3f4f6', '#ffffff', '#4338ca'],
        },
        'neon': {
            'label': 'Neon Bold',
            'desc': 'Near-black background, sharp-edged card with a glowing neon-red border and bold high-contrast typography.',
            'swatch': ['#0a0505', '#ff375f', '#111111'],
        },
        'sunrise': {
            'label': 'Sunrise',
            'desc': 'Warm orange-to-pink sunrise gradient background, soft cream card, rounded and friendly.',
            'swatch': ['#fb923c', '#f472b6', '#fffaf0'],
        },
        'terminal': {
            'label': 'Terminal',
            'desc': 'Black hacker-terminal look, monospace green text, sharp square card with a scanline glow.',
            'swatch': ['#020a04', '#00ff9d', '#001a0d'],
        },
        'frosted': {
            'label': 'Frosted Light',
            'desc': 'Soft pastel-blue background with a frosted, blurred white glass card. Bright and calm.',
            'swatch': ['#dbeafe', '#ffffff', '#3b82f6'],
        },
        'orbit': {
            'label': 'Orbit (Network)',
            'desc': 'Soft lavender background with a faint connected-dots network pattern, a clean white card, a folder-lock badge icon, a show/hide password toggle, and an inline math captcha.',
            'swatch': ['#ece9fb', '#ffffff', '#6d5ef8'],
        },
    }

    # Cards that can be reordered/shown-hidden per dashboard view from the
    # Design Editor. `key` must match the hc-*/stat-box block in
    # main/dashboard.html for that view.
    DASHBOARD_CARDS = {
        'agent': [
            {'key': 'today',     'label': 'Today SMS',     'kind': 'hero'},
            {'key': 'yesterday', 'label': 'Yesterday SMS', 'kind': 'hero'},
            {'key': 'week',      'label': 'Week SMS',      'kind': 'hero'},
            {'key': 'month',     'label': 'Month SMS',     'kind': 'hero'},
            {'key': 'ranges',    'label': 'SMS Ranges',    'kind': 'stat'},
            {'key': 'numbers',   'label': 'My Numbers',    'kind': 'stat'},
            {'key': 'clients',   'label': 'My Clients',    'kind': 'stat'},
        ],
        'admin': [
            {'key': 'agents',  'label': 'Total Agents',        'kind': 'hero'},
            {'key': 'clients', 'label': 'Total Clients',       'kind': 'hero'},
            {'key': 'numbers', 'label': 'Total Numbers',       'kind': 'hero'},
            {'key': 'sms',     'label': 'Total SMS (All Time)','kind': 'hero'},
            {'key': 'ranges',  'label': 'SMS Ranges',          'kind': 'stat'},
            {'key': 'active',  'label': 'Active Users',        'kind': 'stat'},
        ],
    }

    # Fields the Design Editor's color pickers control. `var` is the CSS
    # variable each one maps to (see base.html's custom-design override).
    CUSTOM_COLOR_FIELDS = [
        ('bg',           'Background',   '--bg'),
        ('card',         'Card',         '--card'),
        ('hover',        'Hover',        '--hover'),
        ('border',       'Border',       '--border'),
        ('txt',          'Text',         '--txt'),
        ('muted',        'Muted Text',   '--muted'),
        ('accent',       'Accent',       '--accent'),
        ('accent_light', 'Accent Light', '--accent-light'),
        ('accent2',      'Accent 2',     '--accent2'),
    ]

    DEFAULT_CUSTOM_COLORS = {
        'bg': '#0a0e27', 'card': '#131a3a', 'hover': '#1c2450', 'border': '#252d55',
        'txt': '#f1f2f8', 'muted': '#8a92c0', 'accent': '#4f46e5', 'accent_light': '#38bdf8',
        'accent2': '#4338ca', 'radius': '14', 'pad': '20',
    }

    # Real palette behind every built-in theme (see base.html's per-theme
    # :root blocks — these are extracted straight from there so the Design
    # Editor can start from "what the panel looks like right now" instead
    # of an unrelated placeholder palette. Keys match CUSTOM_COLOR_FIELDS.
    THEME_COLOR_PRESETS = {
        'default':  {'bg':'#0a0e27','card':'#111827','hover':'#1f2937','border':'#374151','txt':'#f3f4f6','muted':'#9ca3af','accent':'#4f46e5','accent_light':'#38bdf8','accent2':'#06b6d4','radius':'14','pad':'20'},
        'midnight': {'bg':'#05070f','card':'#0b0f1c','hover':'#151b2e','border':'#232b42','txt':'#eef1ff','muted':'#8892b0','accent':'#8b5cf6','accent_light':'#22d3ee','accent2':'#06b6d4','radius':'4','pad':'20'},
        'sunset':   {'bg':'#1a1210','card':'#211714','hover':'#2c1e19','border':'#40291f','txt':'#fdf3ee','muted':'#c9a793','accent':'#f97316','accent_light':'#ec4899','accent2':'#fb923c','radius':'20','pad':'20'},
        'emerald':  {'bg':'#0b1512','card':'#0f1e19','hover':'#16281f','border':'#20372c','txt':'#ecfdf5','muted':'#86ac9c','accent':'#10b981','accent_light':'#34d399','accent2':'#059669','radius':'8','pad':'20'},
        'crimson':  {'bg':'#120707','card':'#1a0a0a','hover':'#241010','border':'#3a1616','txt':'#fef2f2','muted':'#c39494','accent':'#dc2626','accent_light':'#f59e0b','accent2':'#ef4444','radius':'4','pad':'20'},
        'light':    {'bg':'#f3f4f6','card':'#ffffff','hover':'#eef0f4','border':'#dfe3ea','txt':'#101828','muted':'#5b6473','accent':'#4338ca','accent_light':'#0ea5e9','accent2':'#0284c7','radius':'14','pad':'20'},
        'neon':     {'bg':'#0d0406','card':'#170709','hover':'#210a0e','border':'#3d151a','txt':'#fdeeef','muted':'#b58e93','accent':'#ff375f','accent_light':'#3b82f6','accent2':'#ff6b6b','radius':'16','pad':'20'},
        'glass':    {'bg':'#0f172a','card':'#1e293b','hover':'#293548','border':'#334155','txt':'#f1f5f9','muted':'#a3b1c6','accent':'#38bdf8','accent_light':'#818cf8','accent2':'#22d3ee','radius':'24','pad':'20'},
        'snow':     {'bg':'#f8fafc','card':'#ffffff','hover':'#f1f5f9','border':'#e2e8f0','txt':'#0f172a','muted':'#64748b','accent':'#334155','accent_light':'#64748b','accent2':'#475569','radius':'6','pad':'20'},
        'mono':     {'bg':'#1a1a1a','card':'#212121','hover':'#2a2a2a','border':'#333333','txt':'#f2f2f2','muted':'#9e9e9e','accent':'#525252','accent_light':'#8a8a8a','accent2':'#6b6b6b','radius':'10','pad':'20'},
        'ocean':    {'bg':'#071a2c','card':'#0d2438','hover':'#123147','border':'#1c3f57','txt':'#e6f4ff','muted':'#7fa8c4','accent':'#0ea5e9','accent_light':'#22d3ee','accent2':'#0284c7','radius':'16','pad':'20'},
        'royal':    {'bg':'#0f0a1e','card':'#160f2b','hover':'#1e1638','border':'#3a2a5c','txt':'#f5f0ff','muted':'#a698c4','accent':'#c9a227','accent_light':'#e5c76b','accent2':'#7c3aed','radius':'10','pad':'20'},
        'cyber':    {'bg':'#050807','card':'#0a100d','hover':'#101a15','border':'#1d3327','txt':'#d7ffe9','muted':'#5f9c81','accent':'#00ff9d','accent_light':'#00d1ff','accent2':'#ff00e6','radius':'2','pad':'20'},
        'rose':     {'bg':'#1f0f17','card':'#2a1620','hover':'#3a1e2b','border':'#4a2438','txt':'#ffeef5','muted':'#c99bb0','accent':'#ec4899','accent_light':'#f9a8d4','accent2':'#db2777','radius':'24','pad':'20'},
        'coffee':   {'bg':'#1c140d','card':'#251b12','hover':'#332415','border':'#4a3520','txt':'#f5ead9','muted':'#b89b7c','accent':'#b8845a','accent_light':'#e0b989','accent2':'#8b5e34','radius':'12','pad':'20'},
        'arctic':   {'bg':'#eef6fb','card':'#ffffff','hover':'#e3f1fb','border':'#cfe6f5','txt':'#0b2436','muted':'#5c7b90','accent':'#0284c7','accent_light':'#38bdf8','accent2':'#0369a1','radius':'16','pad':'20'},
        'forest':   {'bg':'#0e150f','card':'#141f16','hover':'#1c2c1e','border':'#2b3d2c','txt':'#eefbe8','muted':'#9bb495','accent':'#65a30d','accent_light':'#a3e635','accent2':'#4d7c0f','radius':'18','pad':'20'},
        'obsidian': {'bg':'#000000','card':'#0a0a0a','hover':'#151515','border':'#262626','txt':'#f5f5f5','muted':'#8a8a8a','accent':'#f97316','accent_light':'#fbbf24','accent2':'#ea580c','radius':'2','pad':'20'},
        'candy':    {'bg':'#120b1a','card':'#1b1128','hover':'#261939','border':'#382451','txt':'#fbf5ff','muted':'#b3a3cf','accent':'#a78bfa','accent_light':'#5eead4','accent2':'#f9a8d4','radius':'26','pad':'20'},
        'steel':    {'bg':'#12171c','card':'#191f26','hover':'#232b34','border':'#333d49','txt':'#e6ebf0','muted':'#8492a1','accent':'#64748b','accent_light':'#38bdf8','accent2':'#475569','radius':'6','pad':'20'},
        'flysms':   {'bg':'#161616','card':'#1f1f1f','hover':'#262626','border':'#2c2c2c','txt':'#f2f2f2','muted':'#9a9a9a','accent':'#6f4ee8','accent_light':'#0ea5e9','accent2':'#22c55e','radius':'16','pad':'20'},
        'flashv2':  {'bg':'#17101f','card':'#1e1729','hover':'#271e35','border':'#332a44','txt':'#f2f0f7','muted':'#a099b3','accent':'#6f4ee8','accent_light':'#0ea5e9','accent2':'#22c55e','radius':'16','pad':'20'},
    }

    def get_custom_colors_dict(self):
        """Parsed custom_colors JSON, filled in with defaults for any
        missing key so templates never have to guard against None."""
        import json
        colors = dict(PanelSettings.DEFAULT_CUSTOM_COLORS)
        if self.custom_colors:
            try:
                colors.update(json.loads(self.custom_colors))
            except (ValueError, TypeError):
                pass
        return colors

    def get_dashboard_layout_dict(self):
        """Parsed dashboard_layout JSON: {'agent': [...], 'admin': [...]}
        with every card guaranteed present (visible=True) even if it was
        added to DASHBOARD_CARDS after this row was last saved, and any
        stale/removed keys dropped."""
        import json
        saved = {}
        if self.dashboard_layout:
            try:
                saved = json.loads(self.dashboard_layout)
            except (ValueError, TypeError):
                saved = {}

        # V2 Flash gets its own default reading order (Today, Yesterday,
        # Week, Month) to match its reference layout — only used as a
        # starting point when the admin hasn't customized the layout via
        # the Design Editor yet, and only for this theme.
        V2_ORDER = {'agent': ['today', 'yesterday', 'week', 'month', 'ranges', 'numbers', 'clients']}

        result = {}
        for view, cards in PanelSettings.DASHBOARD_CARDS.items():
            by_key = {c['key']: c for c in cards}
            if self.theme == 'flashv2' and view in V2_ORDER:
                cards = [by_key[k] for k in V2_ORDER[view] if k in by_key]
                cards += [c for c in PanelSettings.DASHBOARD_CARDS[view] if c['key'] not in V2_ORDER[view]]
            saved_order = saved.get(view) or []
            ordered = []
            seen = set()
            for entry in saved_order:
                key = entry.get('key')
                if key in by_key and key not in seen:
                    ordered.append({**by_key[key], 'visible': bool(entry.get('visible', True))})
                    seen.add(key)
            # Append any cards missing from the saved order (new cards)
            for c in cards:
                if c['key'] not in seen:
                    ordered.append({**c, 'visible': True})
            result[view] = ordered
        return result

    @staticmethod
    def get():
        settings = PanelSettings.query.get(1)
        if not settings:
            settings = PanelSettings(id=1)
            db.session.add(settings)
            db.session.commit()
        return settings
