from app import db
from datetime import datetime
import json


class TelegramSettings(db.Model):
    """Singleton row (id=1) holding the Telegram bot configuration,
    same pattern as PanelSettings."""
    __tablename__ = 'telegram_settings'

    id = db.Column(db.Integer, primary_key=True)
    bot_token = db.Column(db.String(255))
    bot_username = db.Column(db.String(100))
    webhook_secret = db.Column(db.String(64))
    webhook_base_url = db.Column(db.String(255))  # optional override
    is_active = db.Column(db.Boolean, default=False)
    backup_chat_id = db.Column(db.String(64))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @staticmethod
    def get():
        settings = TelegramSettings.query.get(1)
        if not settings:
            settings = TelegramSettings(id=1)
            db.session.add(settings)
            db.session.commit()
        return settings


class TelegramSession(db.Model):
    __tablename__ = 'telegram_sessions'

    id = db.Column(db.Integer, primary_key=True)
    chat_id = db.Column(db.BigInteger, unique=True, nullable=False, index=True)
    telegram_username = db.Column(db.String(100))
    telegram_name = db.Column(db.String(150))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)

    state = db.Column(db.String(40), default='login_username')
    data = db.Column(db.Text, default='{}')  # JSON scratch space for the current wizard

    failed_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', foreign_keys=[user_id])

    def get_data(self):
        try:
            return json.loads(self.data or '{}')
        except (ValueError, TypeError):
            return {}

    def set_data(self, d):
        self.data = json.dumps(d or {})

    @staticmethod
    def get_or_create(chat_id, telegram_username=None, telegram_name=None):
        sess = TelegramSession.query.filter_by(chat_id=chat_id).first()
        if not sess:
            sess = TelegramSession(
                chat_id=chat_id,
                telegram_username=telegram_username,
                telegram_name=telegram_name,
                state='login_username',
                data='{}'
            )
            db.session.add(sess)
            db.session.commit()
        else:
            changed = False
            if telegram_username and sess.telegram_username != telegram_username:
                sess.telegram_username = telegram_username
                changed = True
            if telegram_name and sess.telegram_name != telegram_name:
                sess.telegram_name = telegram_name
                changed = True
            if changed:
                db.session.commit()
        return sess
