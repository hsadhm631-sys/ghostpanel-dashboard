from app import db
from app.models.sms import SMSCDR
from datetime import datetime, date, timedelta
from sqlalchemy import case, func

INACTIVITY_GRACE_DAYS = 3
INACTIVITY_HOURLY_PENALTY = 0.025
INACTIVITY_MIN_BALANCE = 0.01


class Wallet(db.Model):
    __tablename__ = 'wallets'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)
    balance = db.Column(db.Float, default=0.0)
    total_earned = db.Column(db.Float, default=0.0)
    total_withdrawn = db.Column(db.Float, default=0.0)
    inactivity_penalty = db.Column(db.Float, default=0.0)
    last_penalty_at = db.Column(db.DateTime, nullable=True)
    last_penalty_date = db.Column(db.Date, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('wallet', uselist=False))

    def __repr__(self):
        return f'<Wallet user_id={self.user_id} balance={self.balance}>'

    @staticmethod
    def get_or_create(user_id):
        wallet = Wallet.query.filter_by(user_id=user_id).first()
        if not wallet:
            wallet = Wallet(user_id=user_id, balance=0.0)
            db.session.add(wallet)
            db.session.commit()
        return wallet


class WithdrawalRequest(db.Model):
    __tablename__ = 'withdrawal_requests'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    method = db.Column(db.String(50))
    account_details = db.Column(db.Text)
    status = db.Column(db.String(20), default='pending')   # pending / approved / rejected / paid
    admin_note = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    processed_at = db.Column(db.DateTime)

    user = db.relationship('User', backref='withdrawal_requests')

    def __repr__(self):
        return f'<WithdrawalRequest user_id={self.user_id} amount={self.amount} status={self.status}>'

def get_agent_total_earning(agent_id):
    earning_expr = case(
        (SMSCDR.client_id.isnot(None), SMSCDR.client_payout),
        else_=SMSCDR.agent_payout
    )
    total = db.session.query(func.sum(earning_expr)).filter(
        SMSCDR.user_id == agent_id
    ).scalar()
    return total or 0.0


def get_agent_withdrawn_total(agent_id):
    total = db.session.query(func.sum(WithdrawalRequest.amount)).filter(
        WithdrawalRequest.user_id == agent_id,
        WithdrawalRequest.status.in_(['approved', 'paid'])
    ).scalar()
    return total or 0.0


def get_agent_pending_withdrawal_total(agent_id):
    """Sum of pending withdrawal requests (locked, not yet deducted)."""
    total = db.session.query(func.sum(WithdrawalRequest.amount)).filter(
        WithdrawalRequest.user_id == agent_id,
        WithdrawalRequest.status == 'pending'
    ).scalar()
    return total or 0.0


def get_agent_balance(agent_id):
    earning = get_agent_total_earning(agent_id)
    withdrawn = get_agent_withdrawn_total(agent_id)
    wallet = Wallet.query.filter_by(user_id=agent_id).first()
    penalty = wallet.inactivity_penalty if wallet and wallet.inactivity_penalty else 0.0
    return round(max(earning - withdrawn - penalty, 0.0), 4)


def get_agent_available_balance(agent_id):
    balance = get_agent_balance(agent_id)
    pending = get_agent_pending_withdrawal_total(agent_id)
    return round(max(balance - pending, 0.0), 4)

def get_agent_last_activity(agent_id):
    """Timestamp of the agent's most recent received SMS, or their
    account creation date if they've never received one."""
    from app.models.user import User
    last_sms = db.session.query(func.max(SMSCDR.created_at)).filter(
        SMSCDR.user_id == agent_id
    ).scalar()
    if last_sms:
        return last_sms
    user = User.query.get(agent_id)
    return (user.created_at if user and user.created_at else datetime.utcnow())


def apply_inactivity_penalty_for_agent(agent_id, now=None):
    now = now or datetime.utcnow()

    last_activity = get_agent_last_activity(agent_id)
    penalty_start = last_activity + timedelta(days=INACTIVITY_GRACE_DAYS)
    if now < penalty_start:
        return 0.0  # still inside the grace period

    wallet = Wallet.get_or_create(agent_id)
    bill_from = wallet.last_penalty_at if (wallet.last_penalty_at and wallet.last_penalty_at > penalty_start) else penalty_start
    hours_due = int((now - bill_from).total_seconds() // 3600)
    if hours_due <= 0:
        return 0.0

    earning = get_agent_total_earning(agent_id)
    withdrawn = get_agent_withdrawn_total(agent_id)
    current_balance = round(earning - withdrawn - (wallet.inactivity_penalty or 0.0), 4)
    room = round(current_balance - INACTIVITY_MIN_BALANCE, 4)

    if room <= 0:
        wallet.last_penalty_at = bill_from + timedelta(hours=hours_due)
        db.session.commit()
        return 0.0

    full_amount = round(hours_due * INACTIVITY_HOURLY_PENALTY, 4)
    step = min(full_amount, room)

    wallet.inactivity_penalty = round((wallet.inactivity_penalty or 0.0) + step, 4)
    wallet.last_penalty_at = bill_from + timedelta(hours=hours_due)
    db.session.commit()
    return step


def run_inactivity_penalty_job():
    from app.models.user import User, Role
    now = datetime.utcnow()
    agents = User.query.join(Role).filter(Role.name == 'agent').all()
    charged = 0
    for agent in agents:
        try:
            amount = apply_inactivity_penalty_for_agent(agent.id, now=now)
            if amount:
                charged += 1
        except Exception:
            db.session.rollback()
    return {'agents_checked': len(agents), 'agents_charged': charged}