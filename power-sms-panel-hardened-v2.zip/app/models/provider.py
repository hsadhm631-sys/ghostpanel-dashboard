from app import db
from datetime import datetime

class Provider(db.Model):
    __tablename__ = 'providers'
    id             = db.Column(db.Integer, primary_key=True)
    name           = db.Column(db.String(100), unique=True, nullable=False)
    url            = db.Column(db.String(200), nullable=False)
    ptype          = db.Column(db.String(50), nullable=False)
    username       = db.Column(db.String(100), nullable=True, default='')
    password       = db.Column(db.String(100), nullable=True, default='')
    api_token      = db.Column(db.String(255), nullable=True, default='')
    fetch_interval = db.Column(db.Integer, default=10)
    is_active      = db.Column(db.Boolean, default=True)
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)
    session_data   = db.Column(db.Text, nullable=True)
    last_polled_at = db.Column(db.DateTime, nullable=True)
    webhook_secret = db.Column(db.String(255), nullable=True, default='')
    webhook_no_auth = db.Column(db.Boolean, default=False)
    last_webhook_test_at = db.Column(db.DateTime, nullable=True)
    webhook_last_received_at = db.Column(db.DateTime, nullable=True)
    webhook_receive_count    = db.Column(db.Integer, default=0)
    webhook_fail_count       = db.Column(db.Integer, default=0)
    ip_whitelist   = db.Column(db.Text, nullable=True)
    http_method    = db.Column(db.String(10), nullable=True, default='ANY')
    cli_field      = db.Column(db.String(50), nullable=True, default='cli')
    message_field  = db.Column(db.String(50), nullable=True, default='message')
    uuid_field     = db.Column(db.String(50), nullable=True, default='uuid')

    def is_ip_allowed(self, ip_address):
        from app.utils import ip_matches_whitelist
        return ip_matches_whitelist(ip_address, self.ip_whitelist)
        if not self.webhook_secret or not self.is_active:
            return 'disabled'
        if not self.webhook_last_received_at:
            return 'waiting'
        age = (datetime.utcnow() - self.webhook_last_received_at).total_seconds()
        return 'active' if age <= 900 else 'stale'  # 15 minutes

    def last_activity_at(self):
        candidates = [t for t in (self.last_polled_at, self.webhook_last_received_at) if t]
        return max(candidates) if candidates else None

    def connection_status(self):
        last = self.last_activity_at()
        if not last:
            return 'never'
        age = (datetime.utcnow() - last).total_seconds()
        if age <= 120:
            return 'online'
        if age <= 600:
            return 'idle'
        return 'offline'

class OTPLog(db.Model):
    __tablename__ = 'otp_logs'
    id          = db.Column(db.Integer, primary_key=True)
    provider_id = db.Column(db.Integer, db.ForeignKey('providers.id'))
    number      = db.Column(db.String(50), nullable=False)
    otp         = db.Column(db.String(20), nullable=False)
    sender      = db.Column(db.String(100))
    message     = db.Column(db.Text)
    received_at = db.Column(db.DateTime, default=datetime.utcnow)
    number_id   = db.Column(db.Integer, db.ForeignKey('sms_numbers.id'), nullable=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    order_id     = db.Column(db.String(100), nullable=True)
    service_name = db.Column(db.String(100), nullable=True)
    source       = db.Column(db.String(20), nullable=True, default='poll')
    country      = db.Column(db.String(100), nullable=True)
    provider    = db.relationship('Provider', backref='otp_logs')
    sms_number  = db.relationship('SMSNumber', foreign_keys=[number_id])
    recipient   = db.relationship('User', foreign_keys=[user_id])
    user        = db.relationship('User', foreign_keys=[user_id])