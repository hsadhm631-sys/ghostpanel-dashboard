from app import db
from datetime import datetime

class ActivityLog(db.Model):
    __tablename__ = 'activity_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user = db.relationship('User', backref='activities')

    def __repr__(self):
        return f'<ActivityLog {self.user_id} - {self.action}>'

    @staticmethod
    def log(user_id, action, details=None, ip_address=None, user_agent=None):
        log = ActivityLog(
            user_id=user_id,
            action=action,
            details=details,
            ip_address=ip_address,
            user_agent=user_agent
        )
        db.session.add(log)
        db.session.commit()
        return log

class ApiRequestLog(db.Model):
    """Live log of every incoming API call — who called it, on which
    number, for which endpoint, and whether it succeeded or failed."""
    __tablename__ = 'api_request_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, index=True)
    username = db.Column(db.String(100))          # snapshot, survives user deletion
    endpoint = db.Column(db.String(150), index=True)
    method = db.Column(db.String(10))
    number = db.Column(db.String(50), index=True)
    status = db.Column(db.String(10), index=True)  # 'success' | 'fail'
    status_code = db.Column(db.Integer)
    message = db.Column(db.String(255))
    ip_address = db.Column(db.String(45))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    user = db.relationship('User', backref='api_request_logs')

    def __repr__(self):
        return f'<ApiRequestLog {self.endpoint} {self.status}>'

    @staticmethod
    def log(user_id=None, username=None, endpoint=None, method=None,
            number=None, status='success', status_code=200,
            message=None, ip_address=None):
        entry = ApiRequestLog(
            user_id=user_id, username=username, endpoint=endpoint,
            method=method, number=number, status=status,
            status_code=status_code, message=(message or '')[:255],
            ip_address=ip_address
        )
        db.session.add(entry)
        db.session.commit()
        return entry

    def to_dict(self):
        return {
            'id': self.id,
            'account': self.username or (self.user.username if self.user else 'guest'),
            'endpoint': self.endpoint,
            'method': self.method,
            'number': self.number or '\u2014',
            'status': self.status,
            'status_code': self.status_code,
            'message': self.message or '',
            'ip_address': self.ip_address or '\u2014',
            'is_provider': self.endpoint in ('provider.poll', 'provider.webhook'),
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else ''
        }


class News(db.Model):
    __tablename__ = 'news'

    id = db.Column(db.Integer, primary_key=True)
    headline = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    creator = db.relationship('User', backref='news')

    def __repr__(self):
        return f'<News {self.headline}>'

    def to_dict(self):
        return {
            'id': self.id,
            'headline': self.headline,
            'content': self.content,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
