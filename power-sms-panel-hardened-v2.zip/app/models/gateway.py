from app import db
from app.db_types import EncryptedText
from datetime import datetime

class HttpIncomingLog(db.Model):
    __tablename__ = 'http_incoming_logs'

    id             = db.Column(db.Integer, primary_key=True)
    endpoint_name  = db.Column(db.String(100), nullable=True, default='')
    ip_address     = db.Column(db.String(64), nullable=True, default='')
    method         = db.Column(db.String(10), nullable=True, default='POST')
    status         = db.Column(db.String(20), nullable=True, default='')  # SUCCESS / DUPLICATE / FAILED
    status_code    = db.Column(db.Integer, default=200)
    error_message  = db.Column(db.Text, nullable=True, default='')
    body           = db.Column(db.Text, nullable=True, default='')
    query_params   = db.Column(db.Text, nullable=True, default='')
    response_body  = db.Column(db.Text, nullable=True, default='')
    user_agent     = db.Column(db.String(255), nullable=True, default='')
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': str(self.id),
            'endpointName': self.endpoint_name or '',
            'ipAddress': self.ip_address or '',
            'method': self.method or 'POST',
            'status': self.status or '',
            'statusCode': self.status_code or 0,
            'errorMessage': self.error_message or '',
            'body': self.body or '',
            'queryParams': self.query_params or '',
            'responseBody': self.response_body or '',
            'userAgent': self.user_agent or '',
            'createdAt': self.created_at.isoformat() if self.created_at else None,
        }


class DlrMessage(db.Model):
    __tablename__ = 'dlr_messages'

    id          = db.Column(db.Integer, primary_key=True)
    msgid       = db.Column(db.String(120), nullable=True, default='')
    number      = db.Column(db.String(64), nullable=True, default='')
    message     = db.Column(db.Text, nullable=True, default='')
    status      = db.Column(db.String(20), nullable=True, default='pending')  # delivered / failed / pending
    raw_status  = db.Column(db.String(40), nullable=True, default='')
    time        = db.Column(db.String(60), nullable=True, default='')
    sender_ip   = db.Column(db.String(64), nullable=True, default='')
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': str(self.id),
            'msgid': self.msgid or '',
            'number': self.number or '',
            'message': self.message or '',
            'status': self.status or 'pending',
            'rawStatus': self.raw_status or '',
            'time': self.time or '',
            'senderIp': self.sender_ip or '',
            'createdAt': self.created_at.isoformat() if self.created_at else None,
        }


class SmsGatewayProvider(db.Model):
    __tablename__ = 'sms_gateway_providers'

    id                     = db.Column(db.Integer, primary_key=True)
    provider_name          = db.Column(db.String(100), nullable=False)
    email                  = db.Column(db.String(120), nullable=True, default='')
    ip_addresses           = db.Column(db.Text, nullable=True, default='')
    esme_username          = db.Column(db.String(20), nullable=True, default='')
    esme_password          = db.Column(EncryptedText(), nullable=True, default='')
    number_field           = db.Column(db.String(50), nullable=True, default='number')
    cli_field              = db.Column(db.String(50), nullable=True, default='cli')
    message_field          = db.Column(db.String(50), nullable=True, default='message')
    unique_id_field        = db.Column(db.String(50), nullable=True, default='uuid')
    return_value           = db.Column(db.String(50), nullable=True, default='OK-#uuid')
    smpp_host              = db.Column(db.String(150), nullable=True, default='')
    smpp_port              = db.Column(db.String(10), nullable=True, default='2775')
    system_id              = db.Column(db.String(50), nullable=True, default='')
    smsc_password          = db.Column(EncryptedText(), nullable=True, default='')
    bind_mode              = db.Column(db.String(20), nullable=True, default='')  # transmitter/receiver/transceiver
    connection_allowed_ip  = db.Column(db.String(255), nullable=True, default='')
    is_active              = db.Column(db.Boolean, default=True)
    bind_status            = db.Column(db.String(20), nullable=True, default='disconnected')  # connected/connecting/failed/disconnected
    last_bind_at           = db.Column(db.DateTime, nullable=True)
    last_bind_ms           = db.Column(db.Integer, nullable=True)
    created_at             = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': str(self.id),
            'providerName': self.provider_name,
            'email': self.email or '',
            'ipAddresses': self.ip_addresses or '',
            'esmeUsername': self.esme_username or '',
            'esmePassword': self.esme_password or '',
            'numberField': self.number_field or 'number',
            'cliField': self.cli_field or 'cli',
            'messageField': self.message_field or 'message',
            'uniqueIdField': self.unique_id_field or 'uuid',
            'returnValue': self.return_value or 'OK-#uuid',
            'smppHost': self.smpp_host or '',
            'smppPort': self.smpp_port or '2775',
            'systemId': self.system_id or '',
            'smscPassword': self.smsc_password or '',
            'bindMode': self.bind_mode or '',
            'bindType': self.bind_mode or '',
            'connectionAllowedIp': self.connection_allowed_ip or '',
            'isActive': bool(self.is_active),
            'bindStatus': self.bind_status or 'disconnected',
        }


class SmppSentMessage(db.Model):
    __tablename__ = 'smpp_sent_messages'

    id                = db.Column(db.Integer, primary_key=True)
    provider_id       = db.Column(db.Integer, db.ForeignKey('sms_gateway_providers.id'), nullable=True)
    provider_name     = db.Column(db.String(100), nullable=True, default='')
    source_addr       = db.Column(db.String(64), nullable=True, default='')
    dest_addr         = db.Column(db.String(64), nullable=True, default='')
    message_content   = db.Column(db.Text, nullable=True, default='')
    encoding          = db.Column(db.String(10), nullable=True, default='GSM')
    smpp_status       = db.Column(db.String(20), nullable=True, default='pending')  # delivered/failed/pending/sending
    smpp_message_id   = db.Column(db.String(80), nullable=True, default='')
    parts             = db.Column(db.Integer, nullable=True, default=1)
    parts_delivered   = db.Column(db.Integer, nullable=True, default=0)
    created_at        = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': str(self.id),
            'providerId': str(self.provider_id) if self.provider_id else '',
            'providerName': self.provider_name or '',
            'sourceAddr': self.source_addr or '',
            'destAddr': self.dest_addr or '',
            'messageContent': self.message_content or '',
            'encoding': self.encoding or 'GSM',
            'smppStatus': self.smpp_status or 'pending',
            'smppMessageId': self.smpp_message_id or '',
            'parts': self.parts or 1,
            'partsDelivered': self.parts_delivered or 0,
            'createdAt': self.created_at.isoformat() if self.created_at else None,
        }


class HttpEndpoint(db.Model):
    """The single auto-created unified HTTP Connection endpoint
    (/http/incoming/<slug>) shown on the HTTP Connection page."""
    __tablename__ = 'http_endpoints'

    id             = db.Column(db.Integer, primary_key=True)
    name           = db.Column(db.String(100), nullable=False, default='HTTP Incoming Gateway')
    slug           = db.Column(db.String(60), unique=True, nullable=False)
    method         = db.Column(db.String(10), nullable=True, default='ANY')
    ip_whitelist   = db.Column(db.Text, nullable=True, default='')
    # Secret key every caller must send (X-API-Key header or ?key=). Without
    # it, anyone who guessed the slug could push messages through the SMS
    # provider at your cost.
    api_token      = db.Column(db.String(64), nullable=True, default='')
    is_active      = db.Column(db.Boolean, default=True)
    total_requests = db.Column(db.Integer, default=0)
    total_success  = db.Column(db.Integer, default=0)
    total_failed   = db.Column(db.Integer, default=0)
    created_at     = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': str(self.id),
            'name': self.name,
            'slug': self.slug,
            'method': self.method or 'ANY',
            'ipWhitelist': self.ip_whitelist or '',
            'apiKey': self.api_token or '',
            'isActive': bool(self.is_active),
            'totalRequests': self.total_requests or 0,
            'totalSuccess': self.total_success or 0,
            'totalFailed': self.total_failed or 0,
        }