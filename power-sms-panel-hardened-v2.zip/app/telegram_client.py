"""
app/telegram_client.py
Thin wrapper around the raw Telegram Bot HTTP API. Deliberately not using
python-telegram-bot / aiogram / etc: this panel already ships `requests`
as a dependency, the bot only needs ~8 endpoints, and a plain webhook
handler is much simpler to reason about inside a normal Flask request
than wiring an async library into a sync WSGI app on serverless.
"""
import requests

API_BASE = "https://api.telegram.org/bot{token}/{method}"
FILE_BASE = "https://api.telegram.org/file/bot{token}/{path}"


def call(token, method, payload=None, files=None, timeout=15):
    if not token:
        return {'ok': False, 'description': 'no bot token configured'}
    url = API_BASE.format(token=token, method=method)
    try:
        if files:
            resp = requests.post(url, data=payload or {}, files=files, timeout=timeout)
        else:
            resp = requests.post(url, json=payload or {}, timeout=timeout)
        return resp.json()
    except Exception as e:
        return {'ok': False, 'description': str(e)}


def send_message(token, chat_id, text, reply_markup=None, parse_mode='HTML'):
    payload = {'chat_id': chat_id, 'text': text, 'parse_mode': parse_mode,
               'disable_web_page_preview': True}
    if reply_markup is not None:
        payload['reply_markup'] = reply_markup
    return call(token, 'sendMessage', payload)


def edit_message_text(token, chat_id, message_id, text, reply_markup=None, parse_mode='HTML'):
    payload = {'chat_id': chat_id, 'message_id': message_id, 'text': text,
               'parse_mode': parse_mode, 'disable_web_page_preview': True}
    if reply_markup is not None:
        payload['reply_markup'] = reply_markup
    return call(token, 'editMessageText', payload)


def answer_callback_query(token, callback_query_id, text=None, show_alert=False):
    payload = {'callback_query_id': callback_query_id}
    if text:
        payload['text'] = text
        payload['show_alert'] = show_alert
    return call(token, 'answerCallbackQuery', payload)


def delete_message(token, chat_id, message_id):
    return call(token, 'deleteMessage', {'chat_id': chat_id, 'message_id': message_id})


def send_document(token, chat_id, filename, content_bytes, caption=None):
    files = {'document': (filename, content_bytes)}
    payload = {'chat_id': chat_id}
    if caption:
        payload['caption'] = caption
    return call(token, 'sendDocument', payload, files=files)


def get_me(token):
    return call(token, 'getMe', {})


def set_webhook(token, url, secret_token=None):
    payload = {'url': url, 'drop_pending_updates': True}
    if secret_token:
        payload['secret_token'] = secret_token
    return call(token, 'setWebhook', payload)


def delete_webhook(token):
    return call(token, 'deleteWebhook', {'drop_pending_updates': True})


def download_file(token, file_id):
    """Returns raw bytes of a file a user uploaded to the bot, or None."""
    info = call(token, 'getFile', {'file_id': file_id})
    if not info.get('ok'):
        return None
    file_path = info['result']['file_path']
    url = FILE_BASE.format(token=token, path=file_path)
    try:
        resp = requests.get(url, timeout=30)
        if resp.status_code == 200:
            return resp.content
    except Exception:
        return None
    return None
