"""
Encryption at rest for secrets the panel must read back (SMPP bind passwords).

Passwords that only need checking (user logins) are hashed with bcrypt and
are not touched here. SMPP passwords have to be sent to the SMSC in clear,
so they are encrypted with Fernet (AES-128-CBC + HMAC-SHA256).

Key handling
------------
* ``DATA_ENCRYPTION_KEY`` (environment) wins when set. It must be a Fernet
  key: 32 url-safe base64 bytes, as produced by ``Fernet.generate_key()``.
* Otherwise a key is generated once and stored in ``<instance>/.data_key``
  with owner-only permissions.
* The key is deliberately NOT derived from SECRET_KEY. Rotating the session
  key must not make every stored SMPP password unreadable.
* If no persistent location is writable (typical for a read-only serverless
  filesystem), encryption is switched off and a warning is printed. An
  ephemeral key would make the passwords unreadable after the next restart,
  which is worse than storing them as they were before.

Stored values carry the prefix ``enc:v1:``. Values without the prefix are
treated as legacy plaintext, which lets an upgraded database keep working
until the startup migration encrypts it.
"""

import os
import sys

from cryptography.fernet import Fernet, InvalidToken

PREFIX = 'enc:v1:'

_fernet = None
_source = None


def init_key(instance_path, env_value=None):
    """Load or create the data key. Returns where it came from:
    'env', 'file', 'generated', or 'disabled' (no persistent location)."""
    global _fernet, _source

    env_value = (env_value or '').strip()
    if env_value:
        try:
            _fernet = Fernet(env_value.encode('ascii'))
        except (ValueError, TypeError) as e:
            raise RuntimeError(
                'DATA_ENCRYPTION_KEY is not a valid Fernet key. Generate one with: '
                'python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"'
            ) from e
        _source = 'env'
        return _source

    path = os.path.join(instance_path, '.data_key')
    try:
        with open(path, 'r', encoding='ascii') as fh:
            stored = fh.read().strip()
        if stored:
            _fernet = Fernet(stored.encode('ascii'))
            _source = 'file'
            return _source
    except (OSError, ValueError):
        pass

    try:
        os.makedirs(instance_path, exist_ok=True)
        key = Fernet.generate_key()
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w', encoding='ascii') as fh:
            fh.write(key.decode('ascii'))
        _fernet = Fernet(key)
        _source = 'generated'
        print(f'[security] Generated a data-encryption key at {path}. Back it up: '
              'stored SMPP passwords cannot be read without it.', file=sys.stderr)
        return _source
    except OSError:
        _fernet = None
        _source = 'disabled'
        print('[security] No writable location for the data-encryption key. SMPP passwords '
              'will be stored unencrypted until DATA_ENCRYPTION_KEY is set.', file=sys.stderr)
        return _source


def is_enabled():
    return _fernet is not None


def is_encrypted(value):
    return isinstance(value, str) and value.startswith(PREFIX)


def encrypt_value(plaintext):
    """Encrypt for storage. Already-encrypted and empty values pass through."""
    if plaintext is None or plaintext == '' or is_encrypted(plaintext):
        return plaintext
    if _fernet is None:
        return plaintext
    token = _fernet.encrypt(str(plaintext).encode('utf-8')).decode('ascii')
    return PREFIX + token


def decrypt_value(stored):
    """Decrypt a stored value. Legacy plaintext is returned unchanged.

    A value that cannot be decrypted (wrong or lost key) returns '' instead of
    raising, so one bad row cannot take the whole admin page down. A warning
    is printed so the problem is visible in the logs."""
    if not is_encrypted(stored):
        return stored
    if _fernet is None:
        print('[security] Encrypted SMPP secret found but no data key is loaded.', file=sys.stderr)
        return ''
    try:
        return _fernet.decrypt(stored[len(PREFIX):].encode('ascii')).decode('utf-8')
    except (InvalidToken, UnicodeDecodeError, ValueError):
        print('[security] Could not decrypt a stored SMPP secret - the data key does not match.',
              file=sys.stderr)
        return ''
