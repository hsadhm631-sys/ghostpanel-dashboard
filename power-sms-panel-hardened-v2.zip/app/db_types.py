"""SQLAlchemy column types. Kept separate from app/crypto_box.py so the crypto
logic can be tested without SQLAlchemy installed."""

from sqlalchemy import Text
from sqlalchemy.types import TypeDecorator

from app.crypto_box import decrypt_value, encrypt_value


class EncryptedText(TypeDecorator):
    """Text column encrypted transparently on write and decrypted on read.

    Application code keeps reading and writing plain strings. The stored form
    is ciphertext, so a copied database file does not reveal SMSC passwords."""

    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return encrypt_value(value)

    def process_result_value(self, value, dialect):
        return decrypt_value(value)
