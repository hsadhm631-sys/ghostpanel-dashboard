"""
SMPP v3.4 client used by the panel.

Two ways to use it:

* ``test_bind`` / ``send_test_sms`` - one-shot helpers that open a link,
  do their job and close it (used by the admin "Test bind" / "Test SMS"
  buttons).
* ``SmppSession`` - a long-lived, thread-safe bound session with
  enquire_link keepalive, automatic reconnect, concatenated (multi-part)
  messages and delivery-receipt (DLR) handling. ``get_bound_session``
  keeps one session per provider configuration in this process.

Design notes
------------
* Every PDU is built from the spec layout. The previous version sent an
  extra byte in bind and an off-by-one submit_sm body that real SMSCs
  would reject or misparse.
* Incoming data goes through a buffer (``PduParser``), so a socket read
  timeout in the middle of a PDU cannot corrupt the stream.
* Frames larger than ``MAX_PDU_LENGTH`` are refused before any memory is
  allocated for them, so a broken or hostile SMSC cannot exhaust memory.
* GSM-7 is used only for plain ASCII text that fits in 160 characters.
  Everything else (Arabic, emoji, long text) is sent as UCS-2, split into
  67-character parts with a UDH header when needed. UCS-2 multipart is the
  most widely accepted encoding across SMSCs.
"""

import hashlib
import random
import re
import socket
import struct
import threading
import time

# ── SMPP command IDs (v3.4) ─────────────────────────────────────────────────
CMD_GENERIC_NACK = 0x80000000
CMD_BIND_RECEIVER = 0x00000001
CMD_BIND_TRANSMITTER = 0x00000002
CMD_SUBMIT_SM = 0x00000004
CMD_DELIVER_SM = 0x00000005
CMD_UNBIND = 0x00000006
CMD_BIND_TRANSCEIVER = 0x00000009
CMD_ENQUIRE_LINK = 0x00000015
RESP_FLAG = 0x80000000

BIND_METHOD_TO_CMD = {
    'transmitter': CMD_BIND_TRANSMITTER,
    'receiver': CMD_BIND_RECEIVER,
    'transceiver': CMD_BIND_TRANSCEIVER,
}

# ── Command status codes ────────────────────────────────────────────────────
ESME_ROK = 0x00000000
ESME_RSYSERR = 0x00000008
ESME_RINVPASWD = 0x0000000E
ESME_RTHROTTLED = 0x00000058

COMMAND_STATUS = {
    0x00000000: "ESME_ROK (Success)",
    0x00000001: "ESME_RINVMSGLEN (Invalid message length)",
    0x00000002: "ESME_RINVCMDLEN (Invalid command length)",
    0x00000003: "ESME_RINVCMDID (Invalid command ID)",
    0x00000004: "ESME_RINVBNDSTS (Incorrect BIND status)",
    0x00000005: "ESME_RALYBND (Already in bound state)",
    0x00000006: "ESME_RINVPRTFLG (Invalid priority flag)",
    0x00000007: "ESME_RINVREGDLVFLG (Invalid registered delivery flag)",
    0x00000008: "ESME_RSYSERR (System error)",
    0x0000000A: "ESME_RINVSRCADR (Invalid source address)",
    0x0000000B: "ESME_RINVDSTADR (Invalid destination address)",
    0x0000000C: "ESME_RINVMSGID (Invalid message ID)",
    0x0000000D: "ESME_RBINDFAIL (Bind failed)",
    0x0000000E: "ESME_RINVPASWD (Invalid password)",
    0x0000000F: "ESME_RINVSYSID (Invalid System ID)",
    0x00000011: "ESME_RCANCELFAIL (Cancel SM failed)",
    0x00000045: "ESME_RINVSCHED (Invalid scheduled delivery time)",
    0x00000058: "ESME_RTHROTTLED (Throttling error)",
    0x00000061: "ESME_RINVDFTMSGID (Invalid default message ID)",
    0x00000088: "ESME_RSERTYPUNAUTH (ESME not authorised for this service_type)",
}

MAX_PDU_LENGTH = 16 * 1024      # SMPP PDUs are small; refuse anything bigger
HEADER_LENGTH = 16
DEFAULT_PORT = 2775
MAX_PARTS = 8                   # cap on concatenated parts per message

# Characters that are safe to send as plain ASCII / GSM-7 without escapes.
# The GSM extension characters ^ { } \ [ ~ ] | and the backtick are left out,
# so those messages go out as UCS-2 instead of being silently corrupted.
_GSM_SAFE = (frozenset(chr(c) for c in range(0x20, 0x7F)) | {'\n', '\r'}) \
    - frozenset('^{}\\[~]|`')

# TLV tags used by this client
TLV_RECEIPTED_MESSAGE_ID = 0x001E
TLV_MESSAGE_PAYLOAD = 0x0424
TLV_SC_INTERFACE_VERSION = 0x0210


def status_description(code):
    if code in COMMAND_STATUS:
        return COMMAND_STATUS[code]
    return f"Unknown error (0x{code:08x})"


class SmppError(Exception):
    """Any SMPP failure. ``code`` is the SMPP command_status (int) or a short
    local reason string: 'timeout', 'closed', 'refused', 'dns', 'oserror'.
    ``partial_ids`` lists message IDs of parts that were already accepted."""

    def __init__(self, message, code=None, partial_ids=None):
        super().__init__(message)
        self.code = code
        self.partial_ids = partial_ids or []


class SmppProtocolError(SmppError):
    pass


# ═════════════════════════════════════════════════════════════════════════════
# Encoding helpers
# ═════════════════════════════════════════════════════════════════════════════

def _cstr(value, max_len):
    """SMPP C-Octet String, ASCII with a NUL terminator. ``max_len`` is the
    spec limit *including* the terminator."""
    s = '' if value is None else str(value)
    raw = s.encode('ascii', errors='replace')[:max_len - 1]
    return raw + b'\x00'


def _read_cstr(body, pos):
    end = body.find(b'\x00', pos)
    if end < 0:
        raise SmppProtocolError('Malformed PDU: unterminated C-string')
    return body[pos:end].decode('ascii', errors='replace'), end + 1


def _need(body, pos, n):
    if pos + n > len(body):
        raise SmppProtocolError('Malformed PDU: body shorter than its fields')


def normalize_destination(number):
    """Return the digits of a destination number (no '+', no spaces).
    Raises ValueError when the number is not usable."""
    digits = re.sub(r'[\s\-()]', '', str(number or '')).lstrip('+')
    if not digits.isdigit() or not (6 <= len(digits) <= 20):
        raise ValueError(f'Invalid destination number: {number!r}')
    return digits


def _source_type(source):
    """(ton, npi) for a sender ID: alphanumeric -> 5/0,
    numeric with at least 7 digits -> 1/1, anything else -> 0/0."""
    if any(c.isalpha() for c in source):
        return 5, 0
    if source.isdigit() and len(source) >= 7:
        return 1, 1
    return 0, 0


def detect_encoding(text):
    """'GSM' for plain ASCII text that fits one 160-character SMS,
    otherwise 'UCS2'."""
    if len(text) <= 160 and all(c in _GSM_SAFE for c in text):
        return 'GSM'
    return 'UCS2'


def _split_ucs2(text, max_bytes):
    """Split text into chunks whose UTF-16BE size is at most max_bytes.
    Splits on character boundaries, so surrogate pairs stay intact."""
    chunks, current, used = [], [], 0
    for ch in text:
        size = len(ch.encode('utf-16-be'))
        if used + size > max_bytes and current:
            chunks.append(''.join(current))
            current, used = [], 0
        current.append(ch)
        used += size
    if current:
        chunks.append(''.join(current))
    return chunks


def build_segments(text):
    """Turn a message into submit_sm segments.

    Returns ``(encoding, segments)``; each segment is a tuple
    ``(esm_class, data_coding, payload_bytes)``. The payload already
    contains the UDH header for multi-part messages."""
    if text is None:
        raise ValueError('Message is empty')
    # Lone surrogates (from broken JSON input) cannot be encoded as UTF-16.
    text = ''.join('\uFFFD' if 0xD800 <= ord(c) <= 0xDFFF else c for c in text)
    if not text.strip():
        raise ValueError('Message is empty')

    if detect_encoding(text) == 'GSM':
        return 'GSM', [(0x00, 0x00, text.encode('ascii'))]

    single = text.encode('utf-16-be')
    if len(single) <= 140:
        return 'UCS2', [(0x00, 0x08, single)]

    # Multi-part: 6-byte UDH = length, IEI 0x00, IEDL 3, ref, total, sequence.
    parts = _split_ucs2(text, 134)
    if len(parts) > MAX_PARTS:
        raise ValueError(
            f'Message too long: {len(parts)} parts (maximum is {MAX_PARTS})')
    ref = random.randint(0, 255)
    segments = []
    for index, part in enumerate(parts, start=1):
        udh = bytes([0x05, 0x00, 0x03, ref, len(parts), index])
        segments.append((0x40, 0x08, udh + part.encode('utf-16-be')))
    return 'UCS2', segments


# ═════════════════════════════════════════════════════════════════════════════
# PDU building and parsing
# ═════════════════════════════════════════════════════════════════════════════

def build_pdu(command_id, sequence, body=b'', status=ESME_ROK):
    return struct.pack('>IIII', HEADER_LENGTH + len(body), command_id,
                       status, sequence) + body


def build_bind_body(system_id, password, system_type=''):
    # system_id, password, system_type, interface_version (0x34 = v3.4),
    # addr_ton, addr_npi, address_range
    return (_cstr(system_id, 16) + _cstr(password, 9) + _cstr(system_type, 13)
            + struct.pack('>BBB', 0x34, 0, 0) + _cstr('', 41))


def build_submit_body(source, destination, esm_class, data_coding, payload,
                      registered_delivery=1):
    src = str(source or '').strip()[:20] or 'SMS'
    src_ton, src_npi = _source_type(src)
    dst = normalize_destination(destination)
    dst_ton, dst_npi = (1, 1) if len(dst) >= 7 else (0, 0)
    if len(payload) > 254:
        raise ValueError('Segment payload exceeds 254 octets')
    return (
        _cstr('', 6)                                      # service_type
        + struct.pack('>BB', src_ton, src_npi) + _cstr(src, 21)
        + struct.pack('>BB', dst_ton, dst_npi) + _cstr(dst, 21)
        + struct.pack('>BBB', esm_class, 0, 0)            # esm_class, protocol_id, priority
        + _cstr('', 17) + _cstr('', 17)                   # schedule, validity
        + struct.pack('>BBBB', registered_delivery, 0, data_coding, 0)
        + struct.pack('>B', len(payload)) + payload
    )


def parse_message_body(body):
    """Parse a deliver_sm body (same layout as submit_sm) including TLVs."""
    pos = 0
    service_type, pos = _read_cstr(body, pos)
    _need(body, pos, 2)
    src_ton, src_npi = body[pos], body[pos + 1]
    pos += 2
    source, pos = _read_cstr(body, pos)
    _need(body, pos, 2)
    dst_ton, dst_npi = body[pos], body[pos + 1]
    pos += 2
    destination, pos = _read_cstr(body, pos)
    _need(body, pos, 3)
    esm_class, protocol_id, priority = body[pos], body[pos + 1], body[pos + 2]
    pos += 3
    _schedule, pos = _read_cstr(body, pos)
    _validity, pos = _read_cstr(body, pos)
    _need(body, pos, 4)
    registered_delivery, _replace, data_coding = body[pos], body[pos + 1], body[pos + 2]
    pos += 4
    _need(body, pos, 1)
    sm_length = body[pos]
    pos += 1
    _need(body, pos, sm_length)
    short_message = body[pos:pos + sm_length]
    pos += sm_length

    tlvs = _parse_tlvs(body[pos:])
    if sm_length == 0 and TLV_MESSAGE_PAYLOAD in tlvs:
        short_message = tlvs[TLV_MESSAGE_PAYLOAD]

    return {
        'service_type': service_type,
        'source_ton': src_ton, 'source_npi': src_npi, 'source': source,
        'dest_ton': dst_ton, 'dest_npi': dst_npi, 'destination': destination,
        'esm_class': esm_class, 'protocol_id': protocol_id, 'priority': priority,
        'registered_delivery': registered_delivery, 'data_coding': data_coding,
        'short_message': short_message,
        'tlvs': tlvs,
    }


def _parse_tlvs(data):
    tlvs, pos = {}, 0
    while pos + 4 <= len(data):
        tag, length = struct.unpack('>HH', data[pos:pos + 4])
        pos += 4
        if pos + length > len(data):
            break
        tlvs[tag] = data[pos:pos + length]
        pos += length
    return tlvs


def decode_text(short_message, data_coding):
    """Best-effort text from a deliver_sm payload (a UDH header is stripped)."""
    payload = short_message
    if payload and payload[0] == 0x05 and len(payload) > 6:
        payload = payload[6:]
    if data_coding in (0x08, 0x02):
        return payload.decode('utf-16-be', errors='replace')
    return payload.decode('latin-1', errors='replace')


_RECEIPT_ID = re.compile(r'\bid:(\S+)')
_RECEIPT_STAT = re.compile(r'\bstat:(\w+)')
_RECEIPT_ERR = re.compile(r'\berr:(\w+)')


def parse_receipt(message):
    """Parse an SMSC delivery receipt, e.g.
    'id:ABC sub:001 dlvrd:001 submit date:... done date:... stat:DELIVRD err:000 text:...'
    Returns a dict, or None when the text is not a receipt."""
    if not message:
        return None
    m_id = _RECEIPT_ID.search(message)
    m_stat = _RECEIPT_STAT.search(message)
    if not m_id or not m_stat:
        return None
    m_err = _RECEIPT_ERR.search(message)
    return {
        'message_id': m_id.group(1),
        'stat': m_stat.group(1).upper(),
        'err': m_err.group(1) if m_err else '',
        'raw': message,
    }


class PduParser:
    """Incremental frame parser: feed bytes as they arrive, get complete PDUs."""

    def __init__(self):
        self._buf = bytearray()

    def feed(self, data):
        self._buf += data
        pdus = []
        while len(self._buf) >= HEADER_LENGTH:
            length, cid, status, seq = struct.unpack('>IIII', self._buf[:HEADER_LENGTH])
            if length < HEADER_LENGTH or length > MAX_PDU_LENGTH:
                self._buf.clear()
                raise SmppProtocolError(f'Malformed PDU length {length}')
            if len(self._buf) < length:
                break
            body = bytes(self._buf[HEADER_LENGTH:length])
            del self._buf[:length]
            pdus.append({
                'command_id': cid,
                'command_status': status,
                'sequence_number': seq,
                'body': body,
            })
        return pdus


def _read_until(sock, parser, wanted, deadline):
    """Read until a PDU matching ``wanted`` arrives, or the deadline passes.
    Returns ``(matching_pdu, other_pdus)``."""
    others = []
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise SmppError('Timed out waiting for SMSC response', code='timeout')
        sock.settimeout(max(0.05, min(remaining, 1.0)))
        try:
            data = sock.recv(4096)
        except socket.timeout:
            continue
        if not data:
            raise SmppError('Connection closed by SMSC', code='closed')
        for pdu in parser.feed(data):
            if wanted(pdu):
                return pdu, others
            others.append(pdu)


def _bind_response_info(body):
    info = {'system_id': None, 'sc_interface_version': None}
    try:
        system_id, pos = _read_cstr(body, 0)
        info['system_id'] = system_id
        tlvs = _parse_tlvs(body[pos:])
        if tlvs.get(TLV_SC_INTERFACE_VERSION):
            v = tlvs[TLV_SC_INTERFACE_VERSION][0]
            info['sc_interface_version'] = f"{(v >> 4) & 0xF}.{v & 0xF}"
    except SmppProtocolError:
        pass
    return info


def _safe_close(sock):
    try:
        sock.close()
    except Exception:
        pass


# ═════════════════════════════════════════════════════════════════════════════
# Persistent session
# ═════════════════════════════════════════════════════════════════════════════

class _Waiter:
    __slots__ = ('event', 'pdu')

    def __init__(self):
        self.event = threading.Event()
        self.pdu = None


class SmppSession:
    """A bound SMPP link (transceiver, transmitter or receiver).

    Thread-safe: many threads may call ``submit``; responses are matched to
    requests by sequence number. A background reader thread handles responses,
    deliver_sm (delivery receipts and MO messages), enquire_link and unbind,
    and sends enquire_link periodically to keep the link alive.
    """

    READ_TICK = 0.5

    def __init__(self, host, port, system_id, password, bind_type='transceiver',
                 system_type='', connect_timeout=10, response_timeout=15,
                 enquire_interval=30, on_receipt=None, on_message=None, log=None):
        self.host = host
        self.port = int(port or DEFAULT_PORT)
        self.system_id = system_id or ''
        self.password = password or ''
        self.bind_type = bind_type if bind_type in BIND_METHOD_TO_CMD else 'transceiver'
        self.system_type = system_type or ''
        self.connect_timeout = connect_timeout
        self.response_timeout = response_timeout
        self.enquire_interval = enquire_interval
        self.on_receipt = on_receipt
        self.on_message = on_message
        self.signature = None
        self._log = log or (lambda msg: None)

        self._sock = None
        self._bound = False
        self._seq = 0
        self._pending = {}
        self._last_rx = 0.0
        self._state_lock = threading.Lock()   # sequence, pending, socket state
        self._write_lock = threading.Lock()   # serialises socket writes
        self._connect_lock = threading.Lock()  # one bind attempt at a time
        self._stop = threading.Event()
        self.bind_info = {}
        self.last_error = None

    # ── state ──────────────────────────────────────────────────────────────
    @property
    def is_bound(self):
        return self._bound and self._sock is not None

    def _next_seq(self):
        with self._state_lock:
            self._seq = (self._seq % 0x7FFFFFFE) + 1
            return self._seq

    # ── connect / bind ─────────────────────────────────────────────────────
    def connect(self):
        """Open the TCP link and bind. Returns timing/bind details.
        Calling it while already bound is a no-op."""
        with self._connect_lock:
            if self.is_bound:
                return {'bind': self.bind_info}
            self._detach(None, 'reconnecting')
            return self._open_and_bind()

    def _open_and_bind(self):
        details = {}
        start = time.monotonic()
        try:
            sock = socket.create_connection((self.host, self.port),
                                            timeout=self.connect_timeout)
        except socket.timeout as e:
            raise SmppError(f'Timed out connecting to {self.host}:{self.port}',
                            code='timeout') from e
        except socket.gaierror as e:
            raise SmppError(f'Host not found - {self.host} cannot be resolved',
                            code='dns') from e
        except ConnectionRefusedError as e:
            raise SmppError(f'Connection refused - no SMPP server at {self.host}:{self.port}',
                            code='refused') from e
        except OSError as e:
            raise SmppError(f'Connection error: {e}', code='oserror') from e
        details['connectTime'] = int((time.monotonic() - start) * 1000)

        parser = PduParser()
        try:
            cmd = BIND_METHOD_TO_CMD[self.bind_type]
            seq = self._next_seq()
            body = build_bind_body(self.system_id, self.password, self.system_type)
            bind_start = time.monotonic()
            sock.sendall(build_pdu(cmd, seq, body))
            resp, _ = _read_until(sock, parser,
                                  lambda p: p['sequence_number'] == seq,
                                  time.monotonic() + self.response_timeout)
            details['bindTime'] = int((time.monotonic() - bind_start) * 1000)
            if resp['command_status'] != ESME_ROK:
                raise SmppError(f"Bind failed: {status_description(resp['command_status'])}",
                                code=resp['command_status'])
            if resp['command_id'] != (cmd | RESP_FLAG):
                raise SmppProtocolError('Unexpected response to bind request')
        except SmppError:
            _safe_close(sock)
            raise
        except (OSError, struct.error) as e:
            _safe_close(sock)
            raise SmppError(f'Bind error: {e}', code='oserror') from e

        with self._state_lock:
            self._sock = sock
            self._bound = True
            self._last_rx = time.monotonic()
            self.last_error = None
        self._stop.clear()
        threading.Thread(target=self._reader_loop, args=(sock, parser),
                         name='smpp-reader', daemon=True).start()

        info = _bind_response_info(resp['body'])
        self.bind_info = {
            'serverSystemId': info['system_id'],
            'scInterfaceVersion': info['sc_interface_version'],
        }
        details['bind'] = self.bind_info
        self._log(f'SMPP bound to {self.host}:{self.port} as {self.bind_type}')
        return details

    # ── reader thread ──────────────────────────────────────────────────────
    def _reader_loop(self, sock, parser):
        reason = 'closed'
        last_enquire = time.monotonic()
        try:
            while not self._stop.is_set() and self._sock is sock:
                now = time.monotonic()
                if now - self._last_rx > self.enquire_interval * 3:
                    raise SmppError('No traffic from SMSC - link considered dead',
                                    code='closed')
                if now - last_enquire >= self.enquire_interval:
                    last_enquire = now
                    self._send(CMD_ENQUIRE_LINK, self._next_seq())
                # Wake up often enough that keepalive timing stays accurate
                # even for short intervals.
                sock.settimeout(max(0.05, min(self.READ_TICK, self.enquire_interval / 4)))
                try:
                    data = sock.recv(4096)
                except socket.timeout:
                    continue
                if not data:
                    raise SmppError('Connection closed by SMSC', code='closed')
                self._last_rx = time.monotonic()
                for pdu in parser.feed(data):
                    self._dispatch(pdu)
        except SmppError as e:
            reason = str(e)
        except Exception as e:  # the thread must never die silently
            reason = f'reader error: {e}'
        finally:
            self._detach(sock, reason)

    def _dispatch(self, pdu):
        cid = pdu['command_id']
        seq = pdu['sequence_number']

        if (cid & RESP_FLAG) or cid == CMD_GENERIC_NACK:
            with self._state_lock:
                waiter = self._pending.pop(seq, None)
            if waiter is not None:
                waiter.pdu = pdu
                waiter.event.set()
            return

        if cid == CMD_ENQUIRE_LINK:
            self._send(CMD_ENQUIRE_LINK | RESP_FLAG, seq)
            return

        if cid == CMD_UNBIND:
            self._send(CMD_UNBIND | RESP_FLAG, seq)
            raise SmppError('Unbound by SMSC', code='closed')

        if cid == CMD_DELIVER_SM:
            try:
                msg = parse_message_body(pdu['body'])
            except SmppError as e:
                self._log(f'Malformed deliver_sm rejected: {e}')
                self._send(CMD_DELIVER_SM | RESP_FLAG, seq, b'\x00', ESME_RSYSERR)
                return
            self._send(CMD_DELIVER_SM | RESP_FLAG, seq, b'\x00', ESME_ROK)
            self._handle_deliver(msg)
            return

        self._log(f'Ignoring unexpected SMPP PDU 0x{cid:08x}')

    def _handle_deliver(self, msg):
        text = decode_text(msg['short_message'], msg['data_coding'])
        is_receipt = (msg['esm_class'] & 0x3C) == 0x04
        if is_receipt:
            receipt = parse_receipt(text) or {}
            receipted = msg['tlvs'].get(TLV_RECEIPTED_MESSAGE_ID)
            if receipted:
                receipt['message_id'] = receipted.rstrip(b'\x00').decode('ascii', 'replace')
            if receipt.get('message_id') and self.on_receipt:
                self._run_callback(self.on_receipt, receipt)
        elif self.on_message:
            self._run_callback(self.on_message, {
                'source': msg['source'], 'destination': msg['destination'], 'text': text,
            })

    def _run_callback(self, fn, payload):
        try:
            fn(payload)
        except Exception as e:
            self._log(f'SMPP callback failed: {e}')

    # ── low-level send / request ───────────────────────────────────────────
    def _send(self, cid, seq, body=b'', status=ESME_ROK):
        data = build_pdu(cid, seq, body, status)
        with self._write_lock:
            sock = self._sock
            if sock is None:
                raise SmppError('Not connected', code='closed')
            sock.sendall(data)

    def _request(self, cid, body, timeout):
        if not self.is_bound:
            raise SmppError('Connection lost', code='closed')
        seq = self._next_seq()
        waiter = _Waiter()
        with self._state_lock:
            self._pending[seq] = waiter
        try:
            self._send(cid, seq, body)
        except (OSError, SmppError) as e:
            with self._state_lock:
                self._pending.pop(seq, None)
            raise SmppError(f'Send failed: {e}', code='closed') from e
        if not waiter.event.wait(timeout):
            with self._state_lock:
                self._pending.pop(seq, None)
            raise SmppError('Timed out waiting for SMSC response', code='timeout')
        if waiter.pdu is None:
            raise SmppError('Connection lost while waiting for response', code='closed')
        return waiter.pdu

    def _detach(self, sock, reason):
        """Forget the socket if it is the current one, fail every request
        still waiting on it, and close it. ``sock=None`` means 'the current
        socket, if any'. A stale socket that was already replaced is only
        closed, never allowed to touch the new connection's state."""
        with self._state_lock:
            if sock is None:
                sock = self._sock
            is_current = sock is not None and sock is self._sock
            waiters = []
            if is_current:
                self._sock = None
                self._bound = False
                self.last_error = reason
                waiters = list(self._pending.values())
                self._pending.clear()
        for waiter in waiters:
            waiter.pdu = None
            waiter.event.set()
        if sock is not None:
            _safe_close(sock)
        if is_current and reason not in ('closed locally', 'reconnecting'):
            self._log(f'SMPP link to {self.host}:{self.port} down: {reason}')

    # ── public API ─────────────────────────────────────────────────────────
    def submit(self, source, destination, text, retries=2):
        """Send one message, splitting it into parts when needed.

        Returns ``{'encoding', 'parts', 'messageIds'}``. Raises ValueError for
        bad input and SmppError for SMSC or network failures; a failure after
        some parts were accepted puts their IDs in ``SmppError.partial_ids``."""
        encoding, segments = build_segments(text)
        dest = normalize_destination(destination)
        if not self.is_bound:
            self.connect()

        ids = []
        for esm_class, data_coding, payload in segments:
            body = build_submit_body(source, dest, esm_class, data_coding, payload)
            try:
                ids.append(self._submit_one(body, retries))
            except SmppError as e:
                if e.code == 'closed' and not ids:
                    # The link dropped before anything was accepted: reconnect once.
                    self.connect()
                    ids.append(self._submit_one(body, retries))
                    continue
                e.partial_ids = list(ids)
                raise
        return {'encoding': encoding, 'parts': len(segments), 'messageIds': ids}

    def _submit_one(self, body, retries):
        for attempt in range(retries + 1):
            resp = self._request(CMD_SUBMIT_SM, body, self.response_timeout)
            status = resp['command_status']
            if status == ESME_ROK:
                message_id = ''
                if resp['body']:
                    message_id, _ = _read_cstr(resp['body'], 0)
                return message_id or f'MSG-{int(time.time() * 1000)}'
            if status == ESME_RTHROTTLED and attempt < retries:
                time.sleep(0.5 * (attempt + 1))
                continue
            raise SmppError(f'SMS rejected: {status_description(status)}', code=status)
        raise SmppError('SMS rejected: throttled', code=ESME_RTHROTTLED)

    def close(self):
        """Unbind (best effort) and close the link."""
        if self.is_bound:
            try:
                self._request(CMD_UNBIND, b'', 2)
            except SmppError:
                pass
        self._stop.set()
        self._detach(None, 'closed locally')


# ── Session registry: one bound session per provider configuration ─────────

_registry = {}
_registry_lock = threading.Lock()


def _config_signature(host, port, system_id, password, bind_type):
    raw = f'{host}|{port}|{system_id}|{password}|{bind_type}'.encode('utf-8')
    return hashlib.sha256(raw).hexdigest()[:16]


def get_bound_session(provider_key, *, host, port, system_id, password,
                      bind_type='transceiver', on_receipt=None, on_message=None,
                      log=None):
    """Return a bound session for this provider, connecting if needed.

    When the provider's settings change, the old session is closed and a new
    one is created. ``provider_key`` is any stable identifier (the DB id)."""
    signature = _config_signature(host, port, system_id, password, bind_type)
    key = str(provider_key)
    with _registry_lock:
        current = _registry.get(key)
        if current is None or current.signature != signature:
            if current is not None:
                current.close()
            current = SmppSession(host, port, system_id, password, bind_type,
                                  on_receipt=on_receipt, on_message=on_message, log=log)
            current.signature = signature
            _registry[key] = current
    if not current.is_bound:
        current.connect()
    return current


def drop_bound_session(provider_key):
    with _registry_lock:
        session = _registry.pop(str(provider_key), None)
    if session is not None:
        session.close()


# ═════════════════════════════════════════════════════════════════════════════
# One-shot helpers for the admin pages
# ═════════════════════════════════════════════════════════════════════════════

def _error_status(e, bind_phase):
    if e.code == 'timeout':
        return 'timeout'
    if bind_phase:
        return 'failed' if isinstance(e.code, int) else 'error'
    return 'rejected' if isinstance(e.code, int) else 'error'


def test_bind(host, port, system_id, password, bind_type='transceiver',
              system_type='', timeout=15):
    """Open a link, bind, unbind. Returns success / status / message / details."""
    port = int(port or DEFAULT_PORT)
    bind_type = bind_type if bind_type in BIND_METHOD_TO_CMD else 'transceiver'
    details = {'host': host, 'port': port, 'systemId': system_id, 'bindType': bind_type}
    session = SmppSession(host, port, system_id, password, bind_type,
                          system_type=system_type, connect_timeout=timeout,
                          response_timeout=timeout)
    try:
        result = session.connect()
    except SmppError as e:
        details['errorMessage'] = str(e)
        if isinstance(e.code, int):
            details['errorCode'] = e.code
        return {'success': False, 'status': _error_status(e, True),
                'message': str(e), 'details': details}
    finally:
        session.close()

    bind = result.get('bind', {})
    details.update({
        'connectTime': result.get('connectTime'),
        'bindTime': result.get('bindTime'),
        'serverSystemId': bind.get('serverSystemId'),
        'scInterfaceVersion': bind.get('scInterfaceVersion'),
    })
    return {
        'success': True, 'status': 'connected',
        'message': f"Successfully bound to {host}:{port} as {bind_type}",
        'details': details,
    }


def send_test_sms(host, port, system_id, password, destination, message,
                  bind_type='transceiver', system_type='', sender_id='TEST', timeout=15):
    """Bind, submit one message, unbind. Returns success / status / messageId / details."""
    details = {'source': sender_id, 'destination': destination,
               'messageLength': len(message or '')}
    try:
        encoding, _ = build_segments(message)
        normalize_destination(destination)
    except ValueError as e:
        details['errorMessage'] = str(e)
        return {'success': False, 'status': 'invalid', 'message': str(e), 'details': details}
    details['encoding'] = encoding

    session = SmppSession(host, int(port or DEFAULT_PORT), system_id, password, bind_type,
                          system_type=system_type, connect_timeout=timeout,
                          response_timeout=timeout)
    try:
        session.connect()
    except SmppError as e:
        session.close()
        details['errorMessage'] = str(e)
        if isinstance(e.code, int):
            details['errorCode'] = e.code
        return {'success': False, 'status': _error_status(e, True),
                'message': f"Cannot send SMS - {e}", 'details': details}

    try:
        sent = session.submit(sender_id, destination, message, retries=2)
    except SmppError as e:
        details['errorMessage'] = str(e)
        if isinstance(e.code, int):
            details['errorCode'] = e.code
        return {'success': False, 'status': _error_status(e, False),
                'message': str(e), 'details': details}
    finally:
        session.close()

    details['encoding'] = sent['encoding']
    return {
        'success': True, 'status': 'submitted',
        'message': (f"SMS submitted successfully to {destination} "
                    f"({sent['encoding']}, {sent['parts']} part(s))"),
        'messageId': sent['messageIds'][0],
        'messageIds': sent['messageIds'],
        'details': details,
    }
