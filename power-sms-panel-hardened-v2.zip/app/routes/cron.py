import os
from flask import Blueprint, request, jsonify, current_app

from app.security import secure_equals

cron_bp = Blueprint('cron', __name__, url_prefix='/api/cron')


def _cron_auth_error():
    """Shared check for /api/cron/* and the backup endpoints.

    Fails closed: with CRON_SECRET unset these endpoints refuse to run (the
    old code ran them unauthenticated in that case). Comparison is constant
    time, and the error never reveals any part of the real secret.
    """
    def _clean(value):
        value = (value or '').strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1].strip()
        return value

    expected = _clean(os.environ.get('CRON_SECRET'))
    if not expected:
        return jsonify({
            'error': 'disabled',
            'reason': 'CRON_SECRET is not configured on the server.',
        }), 503

    provided = request.headers.get('Authorization', '')
    if provided.lower().startswith('bearer '):
        provided = provided[7:]
    else:
        provided = ''
    if not provided:
        provided = request.args.get('secret', '')

    if not secure_equals(_clean(provided), expected):
        return jsonify({'error': 'unauthorized'}), 401
    return None


@cron_bp.route('/inactivity-penalty', methods=['GET', 'POST'])
def inactivity_penalty():
    _auth_err = _cron_auth_error()
    if _auth_err:
        return _auth_err

    from app.scheduler_jobs import apply_inactivity_penalties
    result = apply_inactivity_penalties(current_app._get_current_object())
    return jsonify({'status': 'ok', 'result': result})


@cron_bp.route('/daily', methods=['GET', 'POST'])
def run_daily_jobs():
    _auth_err = _cron_auth_error()
    if _auth_err:
        return _auth_err

    from app.scheduler_jobs import generate_weekly_credit_notes, apply_inactivity_penalties
    from app.routes.admin import auto_reclaim_inactive_numbers

    results = {}
    try:
        generate_weekly_credit_notes(current_app._get_current_object())
        results['credit_notes'] = 'ok'
    except Exception as e:
        results['credit_notes'] = f'error: {e}'

    try:
        auto_reclaim_inactive_numbers(current_app._get_current_object())
        results['auto_reclaim'] = 'ok'
    except Exception as e:
        results['auto_reclaim'] = f'error: {e}'

    try:
        penalty_result = apply_inactivity_penalties(current_app._get_current_object())
        results['inactivity_penalty'] = penalty_result or 'ok'
    except Exception as e:
        results['inactivity_penalty'] = f'error: {e}'

    return jsonify(results)


@cron_bp.route('/telegram-backup', methods=['GET', 'POST'])
def telegram_backup():
    import os
    import requests
    from app.db_backup import build_full_db_backup, build_caption
    from app.models.telegram import TelegramSettings

    _auth_err = _cron_auth_error()
    if _auth_err:
        return _auth_err

    settings = TelegramSettings.get()
    bot_token = settings.bot_token or os.environ.get('TELEGRAM_BOT_TOKEN')
    chat_id = settings.backup_chat_id or os.environ.get('TELEGRAM_CHAT_ID')
    if not bot_token or not chat_id:
        return jsonify({
            'error': 'Bot token / backup chat id not configured. '
                     'Set them on the admin Telegram Bot page (Backup Chat ID field), '
                     'or set TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID env vars as a fallback.'
        }), 500

    file_bytes, filename, exported = build_full_db_backup()
    caption = build_caption(exported, prefix='FLASH SMS backup (auto, every 15 min)')

    resp = requests.post(
        f'https://api.telegram.org/bot{bot_token}/sendDocument',
        data={'chat_id': chat_id, 'caption': caption},
        files={'document': (filename, file_bytes)},
        timeout=30,
    )

    if not resp.ok:
        return jsonify({'error': 'telegram_send_failed', 'detail': resp.text}), 502

    return jsonify({'status': 'sent', 'tables': exported})


@cron_bp.route('/restore-legacy-data', methods=['POST'])
def restore_legacy_data():
    # This endpoint TRUNCATEs users, providers, roles and more before
    # reloading seed data. It needs POST, the cron secret, and an explicit
    # ALLOW_LEGACY_RESTORE=1 on the server, so a stray request cannot wipe the panel.
    if os.environ.get('ALLOW_LEGACY_RESTORE', '').strip() != '1':
        return jsonify({'error': 'disabled',
                        'reason': 'Set ALLOW_LEGACY_RESTORE=1 on the server to enable this destructive endpoint.'}), 403
    import re as _re
    from sqlalchemy import text as _sa_text4
    from app import db as _db2

    _auth_err = _cron_auth_error()
    if _auth_err:
        return _auth_err

    seed_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        'seed_data', 'import_data.sql'
    )
    if not os.path.exists(seed_path):
        return jsonify({'error': 'seed_data/import_data.sql not found in this deployment'}), 404

    with open(seed_path, 'r', encoding='utf-8') as f:
        seed_sql = f.read()
    seed_sql = _re.sub(
        r'(?im)^\s*SET session_replication_role[^;]*;\s*$', '', seed_sql
    )
    tables_to_clear = [
        'activity_logs', 'sms_numbers', 'sms_ranges',
        'panel_settings', 'providers', 'users', 'roles',
    ]

    raw_conn = _db2.engine.raw_connection()
    try:
        cur = raw_conn.cursor()
        quoted = ', '.join(f'"{t}"' for t in tables_to_clear)
        cur.execute(f'TRUNCATE TABLE {quoted} RESTART IDENTITY CASCADE')
        cur.execute(seed_sql)
        raw_conn.commit()
    except Exception as e:
        raw_conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        raw_conn.close()

    counts = {}
    for t in ['roles', 'users', 'providers', 'panel_settings', 'sms_ranges', 'sms_numbers', 'activity_logs']:
        try:
            counts[t] = _db2.session.execute(_sa_text4(f'SELECT COUNT(*) FROM "{t}"')).scalar()
        except Exception:
            pass

    return jsonify({'status': 'restored', 'row_counts': counts})


@cron_bp.route('/poll-providers', methods=['GET', 'POST'])
def poll_providers():
    import re as _re2
    import json as _json2
    from datetime import datetime as _dt2
    from app import db as _db3
    from app.models.provider import Provider
    from app.models.activity import ApiRequestLog
    from app.fetcher import _detect_otp, _save_otp
    from panel_fetchers import (
        serialize_session, deserialize_session,
        ints_login, ints_fetch,
        ims_login, ims_fetch,
        konekta_login, konekta_fetch,
        panel_login, panel_fetch,
        new_panel_login, new_panel_fetch,
        timesms_login, timesms_fetch,
        apitoken_login, apitoken_fetch,
        basha_login, basha_fetch,
    )

    _auth_err = _cron_auth_error()
    if _auth_err:
        return _auth_err

    def do_login(ptype, name, username, password, api_token, url):
        if ptype == "ints":
            return ints_login(name, username, password, url)
        elif ptype == "ims":
            return ims_login(username, password, url)
        elif ptype == "konekta":
            return konekta_login(username, password, url)
        elif ptype == "standard":
            return panel_login(name, username, password, url)
        elif ptype == "timesms":
            return timesms_login(name, username, password, url)
        elif ptype == "basha":
            return basha_login(name, username, password, url)
        elif ptype in ("roxy", "voicegate", "numberpanel", "proofsms"):
            return new_panel_login(name, username, password, url, ptype=ptype)
        elif ptype == "api_token":
            return apitoken_login(name, api_token, url)
        return ints_login(name, username, password, url)

    def log_poll(provider_name, ptype, stage, status, message):
        try:
            tag = f"[{(ptype or '?').upper()}]"
            ApiRequestLog.log(
                user_id=None, username=f"{tag} {provider_name}", endpoint='provider.poll',
                method='POLL', number=None, status=status,
                status_code=200 if status == 'success' else 502,
                message=f"{stage}: {(message or '').strip()}"[:255], ip_address=None,
            )
        except Exception:
            pass

    def do_fetch(ptype, name, session_info, url):
        if ptype == "ints":
            return ints_fetch(name, session_info, url)
        elif ptype == "ims":
            return ims_fetch(session_info, url)
        elif ptype == "konekta":
            return konekta_fetch(session_info)
        elif ptype == "standard":
            return panel_fetch(session_info, url)
        elif ptype == "timesms":
            return timesms_fetch(name, session_info, url)
        elif ptype == "basha":
            return basha_fetch(session_info, url)
        elif ptype in ("roxy", "voicegate", "numberpanel", "proofsms"):
            return new_panel_fetch(name, session_info, url, ptype=ptype)
        elif ptype == "api_token":
            return apitoken_fetch(name, session_info, url)
        return ints_fetch(name, session_info, url)

    def safe_login(ptype, pname, provider, note=""):
        try:
            info = do_login(
                ptype, pname, provider.username,
                provider.password, provider.api_token, provider.url
            )
            log_poll(pname, ptype, 'LOGIN', 'success',
                     f"logged in OK{(' — ' + note) if note else ''}")
            return info
        except Exception as e:
            log_poll(pname, ptype, 'LOGIN', 'fail', str(e))
            raise

    results = {}
    providers = Provider.query.filter(
        Provider.is_active == True, Provider.ptype != 'webhook'
    ).all()
    for provider in providers:
        pname = provider.name
        ptype = provider.ptype
        try:
            session_info = deserialize_session(provider.session_data)
            relogged_in = False

            if session_info is None:
                session_info = safe_login(ptype, pname, provider, note="no saved session")
                relogged_in = True

            try:
                rows = do_fetch(ptype, pname, session_info, provider.url)
            except Exception as e:
                rows = None
                if not relogged_in:
                    log_poll(pname, ptype, 'FETCH', 'fail', f"session expired mid-fetch ({e}) — re-logging in")
                    session_info = safe_login(ptype, pname, provider, note="re-login after fetch error")
                    rows = do_fetch(ptype, pname, session_info, provider.url)
                else:
                    raise e

            if rows is None and not relogged_in:
                log_poll(pname, ptype, 'FETCH', 'fail', 'session expired (empty response) — re-logging in')
                session_info = safe_login(ptype, pname, provider, note="re-login after empty fetch")
                rows = do_fetch(ptype, pname, session_info, provider.url)

            saved = 0
            for row in (rows or []):
                if isinstance(row, list):
                    number  = str(row[2]) if len(row) > 2 else ""
                    sender  = str(row[3]) if len(row) > 3 else ""
                    message = str(row[5]) if len(row) > 5 else ""
                elif isinstance(row, dict):
                    number  = str(row.get("number", ""))
                    sender  = str(row.get("cli", ""))
                    message = str(row.get("sms", ""))
                else:
                    continue
                if not number:
                    continue
                otp = _detect_otp(message)
                if not otp:
                    continue
                _save_otp(current_app._get_current_object(), provider.id, number, otp, sender, message)
                saved += 1

            provider.session_data = serialize_session(session_info)
            provider.last_polled_at = _dt2.utcnow()
            _db3.session.commit()
            results[pname] = {'status': 'ok', 'rows': len(rows or []), 'saved': saved}
            log_poll(pname, ptype, 'FETCH', 'success',
                     f"{len(rows or [])} row(s) fetched, {saved} OTP(s) parsed & saved")
        except Exception as e:
            _db3.session.rollback()
            results[pname] = {'status': 'error', 'error': str(e)}
            log_poll(pname, ptype, 'CYCLE', 'fail', str(e))
    penalty_result = None
    try:
        from app.scheduler_jobs import apply_inactivity_penalties
        penalty_result = apply_inactivity_penalties(current_app._get_current_object())
    except Exception as e:
        penalty_result = {'error': str(e)}

    return jsonify({
        'polled': len(providers),
        'results': results,
        'inactivity_penalty': penalty_result,
    })