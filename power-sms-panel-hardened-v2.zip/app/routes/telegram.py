"""
app/routes/telegram.py
Public webhook endpoint that Telegram itself calls. Deliberately kept
separate from admin.py's @admin_required routes since this one must be
reachable *without* a logged-in panel session — Telegram is the caller,
not a browser. It's still protected by the random URL segment (the
per-install webhook_secret) plus Telegram's own X-Telegram-Bot-Api-
Secret-Token header, so nobody else can feed it fake updates.
"""
from flask import Blueprint, request, jsonify, current_app

from app.models.telegram import TelegramSettings
from app.security import secure_equals
from app.telegram_bot import handle_update

telegram_bp = Blueprint('telegram_webhook', __name__)


@telegram_bp.route('/telegram/webhook/<secret>', methods=['POST'])
def webhook(secret):
    settings = TelegramSettings.query.filter_by(webhook_secret=secret).first()
    if not settings or not settings.is_active or not settings.bot_token:
        # Always 404 rather than 403 here so a leaked/guessed URL can't be
        # used to fingerprint whether the bot is merely disabled vs.
        # never configured at all.
        return jsonify({'ok': False}), 404

    # The bot registers its webhook with this secret (see admin.py set_webhook),
    # so Telegram always sends the header. A request without it, or with the
    # wrong one, is refused. The old check skipped the header when it was absent.
    header_secret = request.headers.get('X-Telegram-Bot-Api-Secret-Token', '')
    if not secure_equals(header_secret, settings.webhook_secret):
        return jsonify({'ok': False}), 403

    update = request.get_json(silent=True) or {}
    try:
        handle_update(settings, update)
    except Exception:
        current_app.logger.exception('Telegram webhook handling failed')

    # Always 200 — Telegram retries aggressively on non-2xx responses,
    # and a bug in one update shouldn't cause a retry storm.
    return jsonify({'ok': True})
