from datetime import datetime
from functools import wraps
from flask import Blueprint, render_template, request, jsonify, redirect, url_for, flash, current_app
from flask_login import login_required, current_user
from app import db
from app.models.activity import ActivityLog, ApiRequestLog
from app.models.user import User

monitor_bp = Blueprint('monitor', __name__, url_prefix='/monitor')


def admin_required(f):
    @wraps(f)
    def d(*a, **kw):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash('Admin access required.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*a, **kw)
    return d

@monitor_bp.route('/api-live')
@login_required
@admin_required
def api_live():
    from sqlalchemy.exc import OperationalError, ProgrammingError
    today = datetime.utcnow().date()
    try:
        q = ApiRequestLog.query
        total = q.count()
        today_total = q.filter(db.func.date(ApiRequestLog.created_at) == today).count()
        today_success = q.filter(
            db.func.date(ApiRequestLog.created_at) == today,
            ApiRequestLog.status == 'success'
        ).count()
        today_fail = q.filter(
            db.func.date(ApiRequestLog.created_at) == today,
            ApiRequestLog.status == 'fail'
        ).count()
        recent = q.order_by(ApiRequestLog.created_at.desc()).limit(60).all()
        accounts = User.query.order_by(User.username).all()
    except (OperationalError, ProgrammingError):
        db.session.rollback()
        db.create_all()
        total = today_total = today_success = today_fail = 0
        recent = []
        accounts = User.query.order_by(User.username).all()
    return render_template('admin/api_monitor.html',
                           recent=recent, total=total,
                           today_total=today_total, today_success=today_success,
                           today_fail=today_fail, accounts=accounts)


@monitor_bp.route('/api-live/data')
@login_required
@admin_required
def api_live_data():
    from sqlalchemy.exc import OperationalError, ProgrammingError
    limit = min(request.args.get('limit', 60, type=int), 300)
    status = request.args.get('status', '').strip()
    account = request.args.get('account', '').strip()
    number = request.args.get('number', '').strip()
    source = request.args.get('source', '').strip()

    try:
        q = ApiRequestLog.query
        if status in ('success', 'fail'):
            q = q.filter(ApiRequestLog.status == status)
        if account:
            q = q.filter(ApiRequestLog.username.like(f'%{account}%'))
        if number:
            q = q.filter(ApiRequestLog.number.like(f'%{number}%'))
        if source == 'provider':
            q = q.filter(ApiRequestLog.endpoint == 'provider.poll')
        elif source == 'client':
            q = q.filter(ApiRequestLog.endpoint != 'provider.poll')

        records = q.order_by(ApiRequestLog.created_at.desc()).limit(limit).all()

        today = datetime.utcnow().date()
        today_total = ApiRequestLog.query.filter(
            db.func.date(ApiRequestLog.created_at) == today).count()
        today_success = ApiRequestLog.query.filter(
            db.func.date(ApiRequestLog.created_at) == today,
            ApiRequestLog.status == 'success').count()
        today_fail = ApiRequestLog.query.filter(
            db.func.date(ApiRequestLog.created_at) == today,
            ApiRequestLog.status == 'fail').count()

        return jsonify({
            'success': True,
            'logs': [r.to_dict() for r in records],
            'today_total': today_total,
            'today_success': today_success,
            'today_fail': today_fail,
            'total': ApiRequestLog.query.count(),
        })
    except (OperationalError, ProgrammingError) as e:
        db.session.rollback()
        db.create_all()
        current_app.logger.warning(f"api_live_data self-healed after DB error: {e}")
        return jsonify({
            'success': True, 'logs': [],
            'today_total': 0, 'today_success': 0, 'today_fail': 0, 'total': 0,
        })


@monitor_bp.route('/api-live/clear', methods=['POST'])
@login_required
@admin_required
def api_live_clear():
    count = ApiRequestLog.query.delete()
    db.session.commit()
    ActivityLog.log(current_user.id, 'clear_api_log',
                    f'Cleared {count} API log entries',
                    ip_address=request.remote_addr)
    return jsonify({'success': True, 'cleared': count})