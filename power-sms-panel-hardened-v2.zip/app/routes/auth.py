from flask import Blueprint, render_template, redirect, url_for, request, flash, session, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app import db, bcrypt
from app.models.user import User, Role
from app.models.activity import ActivityLog
from app.security import limiter, is_safe_relative_path, new_token
from app.utils import get_client_ip
from datetime import datetime, timedelta
from functools import wraps
import random
import re
import secrets

auth_bp = Blueprint('auth', __name__)

# Single-device session enforcement for client accounts (Test123 exempt).
# If no heartbeat is seen from the active device for this long, its session
# is considered dead and a new login is allowed through normally.
SESSION_STALE_MINUTES = 20
# Cooldown enforced after a same-account login collision is detected,
# including right after the original device logs out.
CONCURRENT_LOCK_MINUTES = 5

# Account lockout after repeated wrong passwords (database-backed).
ACCOUNT_LOCK_THRESHOLD = 5
ACCOUNT_LOCK_MINUTES = 15

MIN_PASSWORD_LENGTH = 8

_dummy_hash = None


def _dummy_password_hash():
    """A real bcrypt hash used when the username does not exist, so a wrong
    username takes as long to reject as a wrong password (no user oracle)."""
    global _dummy_hash
    if _dummy_hash is None:
        _dummy_hash = bcrypt.generate_password_hash(secrets.token_urlsafe(16)).decode('utf-8')
    return _dummy_hash


def _new_captcha():
    session['captcha_num1'] = random.randint(1, 9)
    session['captcha_num2'] = random.randint(1, 9)
    session['captcha_answer'] = session['captcha_num1'] + session['captcha_num2']


def _verify_turnstile():
    """Returns True when Turnstile is not configured or the token verifies."""
    secret = current_app.config.get('TURNSTILE_SECRET_KEY', '')
    if not secret:
        return True
    token = request.form.get('cf-turnstile-response', '')
    if not token:
        flash('Please complete the security check.', 'danger')
        return False
    try:
        import requests as _requests
        resp = _requests.post(
            'https://challenges.cloudflare.com/turnstile/v0/siteverify',
            data={'secret': secret, 'response': token, 'remoteip': get_client_ip(request)},
            timeout=8,
        )
        ok = bool(resp.json().get('success', False))
    except Exception:
        current_app.logger.exception('Turnstile siteverify request failed')
        ok = False
    if not ok:
        flash('Security check failed. Please try again.', 'danger')
    return ok


@auth_bp.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return redirect(url_for('auth.login'))


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    if request.method == 'GET':
        _new_captcha()
        return render_template('auth/login.html')

    cfg = current_app.config
    window = cfg['LOGIN_WINDOW_SECONDS']
    ip = get_client_ip(request)
    username = request.form.get('username', '').strip()[:80]
    password = request.form.get('password', '')
    captcha = request.form.get('capt', '')
    user_key = username.lower()

    ip_key = f'login-ip:{ip}'
    user_limit_key = f'login-user:{user_key}'
    if (limiter.count(ip_key, window) >= cfg['LOGIN_IP_LIMIT']
            or (user_key and limiter.count(user_limit_key, window) >= cfg['LOGIN_USER_LIMIT'])):
        flash('Too many failed login attempts. Please wait 15 minutes and try again.', 'danger')
        return render_template('auth/login.html'), 429

    if not username or not password:
        flash('Please enter username and password.', 'danger')
        _new_captcha()
        return render_template('auth/login.html')

    if not _verify_turnstile():
        _new_captcha()
        return render_template('auth/login.html')

    # Simple arithmetic captcha (kept from the original design).
    try:
        captcha_ok = int(captcha) == int(session.get('captcha_answer', -1))
    except (TypeError, ValueError):
        captcha_ok = False
    if not captcha_ok:
        flash('Incorrect captcha answer. Please try again.', 'danger')
        _new_captcha()
        limiter.record(ip_key, window)
        return render_template('auth/login.html')

    user = User.query.filter_by(username=username).first()
    if user is None:
        user_password_ok = False
        bcrypt.check_password_hash(_dummy_password_hash(), password)  # equalise timing
    else:
        user_password_ok = user.check_password(password)

    if not user_password_ok:
        limiter.record(ip_key, window)
        limiter.record(user_limit_key, window)
        if user is not None:
            user.login_attempts = (user.login_attempts or 0) + 1
            if user.login_attempts >= ACCOUNT_LOCK_THRESHOLD:
                user.locked_until = datetime.utcnow() + timedelta(minutes=ACCOUNT_LOCK_MINUTES)
                user.login_attempts = 0
            db.session.commit()
        # Same message whether the user exists or not.
        flash('Invalid username or password.', 'danger')
        _new_captcha()
        return render_template('auth/login.html')

    # ── Password is correct from here on ────────────────────────────────
    if not user.is_active:
        flash('Your account has been deactivated.', 'warning')
        _new_captcha()
        return render_template('auth/login.html')

    if user.locked_until and user.locked_until > datetime.utcnow():
        flash('Your account is temporarily locked. Please try again later.', 'danger')
        _new_captcha()
        return render_template('auth/login.html')

    now = datetime.utcnow()
    if user.is_client() and not user.is_test_account():
        if user.concurrent_lock_until and user.concurrent_lock_until > now:
            remaining = max(1, int((user.concurrent_lock_until - now).total_seconds() // 60) + 1)
            flash(f'This account is already in use on another device. Try again in {remaining} minute(s).', 'danger')
            _new_captcha()
            return render_template('auth/login.html')

        session_is_live = (
            user.active_session_token and user.active_session_last_seen and
            (now - user.active_session_last_seen) < timedelta(minutes=SESSION_STALE_MINUTES)
        )
        if session_is_live:
            user.concurrent_lock_until = now + timedelta(minutes=CONCURRENT_LOCK_MINUTES)
            db.session.commit()
            flash(f'This account is already logged in on another device. Try again in {CONCURRENT_LOCK_MINUTES} minutes.', 'danger')
            _new_captcha()
            return render_template('auth/login.html')

    if not user.api_token and not user.is_test_account():
        user.generate_api_token()

    user.login_attempts = 0
    user.locked_until = None
    user.last_login = now
    db.session.commit()

    ActivityLog.log(user.id, 'login', 'User logged in',
                    ip_address=ip, user_agent=request.user_agent.string)

    # Rotate the session: drop anything from before the login (captcha, etc.).
    session.clear()

    if user.is_client() and not user.is_test_account():
        device_token = secrets.token_urlsafe(32)
        user.active_session_token = device_token
        user.active_session_last_seen = datetime.utcnow()
        user.concurrent_lock_until = None
        db.session.commit()
        session['device_token'] = device_token

    login_user(user, remember=False)
    session.permanent = False
    session['play_welcome_voice'] = True

    flash(f'Welcome {user.username}!', 'success')

    next_page = request.args.get('next')
    if is_safe_relative_path(next_page):
        return redirect(next_page)
    return redirect(url_for('main.dashboard'))


@auth_bp.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    user_id = current_user.id

    # Release this device's claim on the account's single active session.
    # A collision cooldown (concurrent_lock_until) must survive logout.
    if current_user.is_client() and not current_user.is_test_account():
        if current_user.active_session_token and current_user.active_session_token == session.get('device_token'):
            current_user.active_session_token = None
            current_user.active_session_last_seen = None
            db.session.commit()

    logout_user()
    session.clear()

    try:
        ActivityLog.log(user_id, 'logout', 'User logged out', ip_address=get_client_ip(request))
    except Exception:
        db.session.rollback()

    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))

    if request.method == 'POST':
        cfg = current_app.config
        ip = get_client_ip(request)
        reg_key = f'register:{ip}'
        if limiter.count(reg_key, cfg['REGISTER_WINDOW_SECONDS']) >= cfg['REGISTER_IP_LIMIT']:
            flash('Too many sign-up attempts from this network. Please try again later.', 'danger')
            return render_template('auth/register.html'), 429

        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        password_confirm = request.form.get('password_confirm', '')

        errors = []
        if len(username) < 6 or len(username) > 40:
            errors.append('Username must be between 6 and 40 characters.')
        if not re.match(r'^[A-Za-z0-9_]+$', username):
            errors.append('Username can only contain letters, numbers, and underscores.')
        if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email) or len(email) > 120:
            errors.append('Please enter a valid email address.')
        if len(password) < MIN_PASSWORD_LENGTH:
            errors.append(f'Password must be at least {MIN_PASSWORD_LENGTH} characters.')
        if password != password_confirm:
            errors.append('Passwords do not match.')
        if User.query.filter_by(username=username).first():
            errors.append('Username already exists.')
        if User.query.filter_by(email=email).first():
            errors.append('Email already registered.')

        if errors:
            for error in errors:
                flash(error, 'danger')
            return render_template('auth/register.html')

        client_role = Role.query.filter_by(name='client').first()
        if not client_role:
            client_role = Role(name='client', display_name='Client', permissions='[]')
            db.session.add(client_role)
            db.session.commit()

        user = User(username=username, email=email, role_id=client_role.id, is_active=True)
        user.set_password(password)
        user.generate_api_token()
        db.session.add(user)
        db.session.commit()
        limiter.record(reg_key, cfg['REGISTER_WINDOW_SECONDS'])

        ActivityLog.log(user.id, 'register', 'New user registered', ip_address=ip)

        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html')


# Error handlers
@auth_bp.app_errorhandler(401)
def unauthorized(e):
    flash('Please log in to access this page.', 'warning')
    return redirect(url_for('auth.login', next=request.path))


@auth_bp.app_errorhandler(403)
def forbidden(e):
    flash('You do not have permission to access this page.', 'danger')
    return redirect(url_for('main.dashboard'))


@auth_bp.app_errorhandler(404)
def not_found(e):
    return render_template('errors/404.html'), 404


@auth_bp.app_errorhandler(500)
def server_error(e):
    # Log the real traceback. Render an error page instead of redirecting to
    # the dashboard: if the dashboard is what is failing, a redirect loops.
    current_app.logger.exception(f"Unhandled 500 error on {request.path}: {e}")
    db.session.rollback()
    return render_template('errors/500.html'), 500
