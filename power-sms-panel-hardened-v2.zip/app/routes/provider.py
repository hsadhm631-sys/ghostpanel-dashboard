from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, Response, current_app
from flask_login import login_required, current_user
from app import db
from app.models.provider import Provider, OTPLog
from app.models.sms import SMDRange, SMSNumber
from app.fetcher import start_provider, stop_provider, is_running, _save_otp
from functools import wraps
from datetime import datetime, timedelta
from sqlalchemy import func
import re
import io
import csv
import secrets

provider_bp = Blueprint('provider', __name__)

def _unique_provider_name(base):
    """Return `base` if free, otherwise base2, base3, ... — lets the same
    builtin panel be linked over and over without ever colliding."""
    base = (base or 'Provider').strip()
    if not Provider.query.filter_by(name=base).first():
        return base
    i = 2
    while Provider.query.filter_by(name=f'{base}{i}').first():
        i += 1
    return f'{base}{i}'

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_admin():
            flash('Access denied!', 'danger')
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated

BUILTIN_PANELS = {
    "ChoiceSMS":   {"url": "http://51.77.52.79/ints",         "ptype": "ints"},
    "FlynSMS":     {"url": "http://91.232.105.47/ints",       "ptype": "ints"},
    "Gaza":        {"url": "http://144.217.71.192/ints",      "ptype": "ints"},
    "GoatPanel":   {"url": "http://167.114.117.67/ints",      "ptype": "ints"},
    "ImsPanel":    {"url": "https://www.imssms.org",          "ptype": "ims"},
    "KmSms":       {"url": "http://54.36.173.235/ints",       "ptype": "ints"},
    "KonektaPanel":{"url": "https://www.konektapremium.net",  "ptype": "konekta"},
    "MsiSMS":      {"url": "http://145.239.130.45/ints",      "ptype": "ints"},
    "ProofSMS":    {"url": "http://217.182.195.194/ints",     "ptype": "proofsms"},
    "PurplePanel": {"url": "http://85.195.94.50/sms",         "ptype": "standard"},
    "Seven1Tel":   {"url": "http://147.135.212.197/crapi/s1t/viewstats", "ptype": "api_token"},
    "SharkSMS":    {"url": "http://93.190.143.157/ints",      "ptype": "ints"},
    "TrueSMS":     {"url": "https://truesms.net",             "ptype": "standard"},
    "VoiceGate":   {"url": "http://51.89.7.175/sms",          "ptype": "voicegate"},
    "Wolf":        {"url": "http://213.32.24.208/ints",       "ptype": "ints"},
    "GreenSMS":    {"url": "http://139.99.9.4/ints",          "ptype": "ints"},
    "FireSMS":     {"url": "http://54.39.104.241/ints",       "ptype": "ints"},
    "SniperPanel": {"url": "http://135.125.222.224/ints",     "ptype": "ints"},
    "MAIT":        {"url": "http://168.119.13.175/ints",      "ptype": "ints"},
    "TimeSMS":     {"url": "http://147.135.212.197/crapi/time/viewstats", "ptype": "api_token"},
    # ── Added from FLASH-SMS-BOT.py so the panel uses the exact same
    #    panel list, login logic, and equation as the bot ──
    "XapSMS":      {"url": "http://147.135.212.148/ints",     "ptype": "ints"},
    "Num44":       {"url": "http://185.177.124.145/ints",     "ptype": "ints"},
    "LamixSMS":    {"url": "http://139.99.208.63/ints",       "ptype": "ints"},
    "GroupSMS":    {"url": "http://139.99.63.204/ints",       "ptype": "ints"},
    "ProtonSMS":   {"url": "http://109.236.84.81/ints",       "ptype": "ints"},
    "BoltSMS":     {"url": "http://93.190.143.35/ints",       "ptype": "ints"},
    "SquadSMS":    {"url": "http://51.77.221.209/ints",       "ptype": "ints"},
    "DGroupSMS":   {"url": "http://51.77.216.195/crapi/dgroup/viewstats", "ptype": "api_token"},
    "NumberPanel": {"url": "http://147.135.212.197/crapi/st/viewstats",  "ptype": "api_token"},
    "RoxySMS":     {"url": "http://51.77.216.195/crapi/rx/viewstats",   "ptype": "api_token"},
    "KonektaAPI":  {"url": "http://51.77.216.195/crapi/konek/viewstats", "ptype": "api_token"},
    "PcCall":      {"url": "http://pscall.net/restapi/smsreport",       "ptype": "api_token"},
    "HadiSMS":     {"url": "http://147.135.212.197/crapi/had/viewstats", "ptype": "api_token"},
    "Basha":       {"url": "https://basha.cc",                          "ptype": "basha"},
}

# Every ptype above (and every ptype known to fetcher.py/cron.py) works by
# this panel LOGGING IN to the provider's own site and scraping/pulling the
# codes out — i.e. "poll" providers. None of them have a "webhook URL"
# field on their own side, so they can never be the one calling into
# /api/provider/receive-code. Only ptype == 'webhook' (added manually, no
# login needed) is genuinely push-capable and belongs in the Webhook Route
# "pick a provider" list.
POLL_PTYPES = {
    'ints', 'ims', 'konekta', 'standard', 'timesms', 'basha',
    'roxy', 'voicegate', 'numberpanel', 'proofsms', 'api_token',
}

@provider_bp.route('/admin/providers')
@login_required
@admin_required
def providers():
    all_providers = Provider.query.order_by(Provider.created_at.desc()).all()

    today = datetime.utcnow().date()
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    provider_stats = {
        'total': len(all_providers),
        'active': sum(1 for p in all_providers if p.is_active),
        'webhook_enabled': sum(1 for p in all_providers if p.webhook_secret),
        'otp_today': OTPLog.query.filter(OTPLog.received_at >= today_start).count(),
    }

    # The one provider (if any) currently holding the plain no-token
    # webhook slot — surfaced as a summary widget. Providers with their
    # own tokenized link don't need to be singled out here since each
    # already shows its own status on the Webhook Route / Provider
    # Monitor pages.
    webhook_provider = next((p for p in all_providers if p.webhook_no_auth), None)

    return render_template('admin/providers.html',
        providers=all_providers,
        builtin_panels=BUILTIN_PANELS,
        is_running=is_running,
        provider_stats=provider_stats,
        webhook_provider=webhook_provider
    )

@provider_bp.route('/admin/webhook-route')
@login_required
@admin_required
def webhook_route_status():
    all_providers = Provider.query.order_by(Provider.created_at.desc()).all()
    webhook_capable = [p for p in all_providers if p.ptype not in POLL_PTYPES]
    default_provider = next((p for p in webhook_capable if p.webhook_no_auth), None)
    return render_template('admin/webhook_route.html',
        providers=webhook_capable,
        default_provider=default_provider
    )

@provider_bp.route('/admin/providers/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_provider():
    if request.method == 'POST':
        name           = request.form.get('name')
        url            = request.form.get('url')
        ptype          = request.form.get('ptype')
        username       = request.form.get('username') or ''
        password       = request.form.get('password') or ''
        api_token      = request.form.get('api_token') or ''
        fetch_interval = int(request.form.get('fetch_interval', 10))

        if ptype == 'webhook':
            # Push-only provider: no login, no panel URL to log into —
            # it just sits there waiting to be "Enabled" on the Webhook
            # Route page. `url` has no real meaning here but the column
            # is NOT NULL, so store a placeholder instead of asking the
            # admin to type one in.
            url = url or 'webhook (push-only, no URL needed)'
            username = ''
            password = ''
            api_token = ''

        if Provider.query.filter_by(name=name).first():
            old_name = name
            name = _unique_provider_name(name)
            flash(f'"{old_name}" was already taken, so this account was added as "{name}" instead.', 'success')

        p = Provider(
            name=name,
            url=url,
            ptype=ptype,
            username=username,
            password=password,
            api_token=api_token,
            fetch_interval=fetch_interval,
            is_active=True
        )
        db.session.add(p)
        db.session.commit()

        from flask import current_app
        start_provider(current_app._get_current_object(), p.id)
        flash(f'Provider {name} added and started!', 'success')
        return redirect(url_for('provider.providers'))

    builtin_name = request.args.get('builtin', '')
    builtin_data = BUILTIN_PANELS.get(builtin_name, {})
    suggested_name = _unique_provider_name(builtin_name) if builtin_name else ''
    return render_template('admin/provider_add.html',
        builtin_name=suggested_name,
        builtin_data=builtin_data,
        builtin_panels=BUILTIN_PANELS
    )

@provider_bp.route('/admin/providers/<int:provider_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_provider(provider_id):
    p = Provider.query.get_or_404(provider_id)
    if request.method == 'POST':
        if 'username' in request.form:
            p.username = request.form.get('username') or ''
        if 'password' in request.form:
            p.password = request.form.get('password') or ''
        if 'api_token' in request.form:
            p.api_token = request.form.get('api_token') or ''
        if 'fetch_interval' in request.form:
            p.fetch_interval = int(request.form.get('fetch_interval') or 10)
        if 'ip_whitelist' in request.form:
            p.ip_whitelist = request.form.get('ip_whitelist') or ''
        if 'cli_field' in request.form:
            p.cli_field = (request.form.get('cli_field') or 'cli').strip() or 'cli'
        if 'message_field' in request.form:
            p.message_field = (request.form.get('message_field') or 'message').strip() or 'message'
        if 'uuid_field' in request.form:
            p.uuid_field = (request.form.get('uuid_field') or 'uuid').strip() or 'uuid'
        db.session.commit()

        if is_running(provider_id):
            stop_provider(provider_id)
            from flask import current_app
            start_provider(current_app._get_current_object(), provider_id)

        flash(f'Provider {p.name} updated!', 'success')
        return redirect(url_for('provider.providers'))

    return render_template('admin/provider_edit.html', provider=p)

@provider_bp.route('/admin/providers/<int:provider_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_provider(provider_id):
    p = Provider.query.get_or_404(provider_id)
    stop_provider(provider_id)
    OTPLog.query.filter_by(provider_id=provider_id).delete()
    db.session.delete(p)
    db.session.commit()
    flash(f'Provider {p.name} deleted!', 'success')
    return redirect(url_for('provider.providers'))

@provider_bp.route('/admin/providers/<int:provider_id>/webhook/generate', methods=['POST'])
@login_required
@admin_required
def generate_webhook_key(provider_id):
    """Turn this provider's OWN link on. Each provider keeps its own
    unique token (webhook_secret), so this no longer touches any other
    provider — multiple providers can be enabled and receiving at the
    same time, each on their own distinct URL."""
    p = Provider.query.get_or_404(provider_id)
    if p.ptype != 'webhook':
        return jsonify({'success': False, 'error': 'This provider is not a webhook provider'}), 400
    if not p.webhook_secret:
        p.webhook_secret = secrets.token_hex(8)
    p.is_active = True
    db.session.commit()
    return jsonify({
        'success': True,
        'webhook_url': url_for('provider.receive_code_by_token', token=p.webhook_secret, _external=True)
    })


@provider_bp.route('/admin/providers/<int:provider_id>/webhook/regenerate', methods=['POST'])
@login_required
@admin_required
def regenerate_webhook_key(provider_id):
    """Invalidate this provider's current link and issue a new one —
    for when the old link may have leaked. Old link stops working the
    instant this runs, so the new one has to be re-pasted into the
    provider's own settings afterward."""
    p = Provider.query.get_or_404(provider_id)
    if p.ptype != 'webhook':
        return jsonify({'success': False, 'error': 'This provider is not a webhook provider'}), 400
    p.webhook_secret = secrets.token_hex(8)
    db.session.commit()
    return jsonify({
        'success': True,
        'webhook_url': url_for('provider.receive_code_by_token', token=p.webhook_secret, _external=True)
    })


@provider_bp.route('/admin/providers/<int:provider_id>/webhook/set-default', methods=['POST'])
@login_required
@admin_required
def set_default_webhook_provider(provider_id):
    """Mark this provider as the single receiver on the plain, no-token
    link (/api/provider/receive-code) — for providers whose OWN webhook
    settings are a fixed URL field with nowhere to paste a per-provider
    token. Only one provider may hold this slot at a time since the
    plain link is shared; this clears it on any other provider first.
    The provider keeps its own tokenized link regardless."""
    p = Provider.query.get_or_404(provider_id)
    if p.ptype != 'webhook':
        return jsonify({'success': False, 'error': 'This provider is not a webhook provider'}), 400
    Provider.query.filter(Provider.id != p.id).update(
        {Provider.webhook_no_auth: False}, synchronize_session=False)
    if not p.webhook_secret:
        p.webhook_secret = secrets.token_hex(8)
    p.webhook_no_auth = True
    p.is_active = True
    db.session.commit()
    return jsonify({'success': True})


@provider_bp.route('/admin/providers/<int:provider_id>/webhook/unset-default', methods=['POST'])
@login_required
@admin_required
def unset_default_webhook_provider(provider_id):
    """Free up the plain no-token link without disabling this provider's
    own tokenized link."""
    p = Provider.query.get_or_404(provider_id)
    p.webhook_no_auth = False
    db.session.commit()
    return jsonify({'success': True})


@provider_bp.route('/admin/providers/<int:provider_id>/webhook/revoke', methods=['POST'])
@login_required
@admin_required
def revoke_webhook_key(provider_id):
    """Pause this provider's link — the token/URL is kept as-is (so
    re-enabling later doesn't change the address the provider is
    already configured to push to), but incoming calls to it are
    rejected while paused. Also frees up the no-token default slot if
    this provider was holding it."""
    p = Provider.query.get_or_404(provider_id)
    p.is_active = False
    p.webhook_no_auth = False
    db.session.commit()
    return jsonify({'success': True})


@provider_bp.route('/admin/providers/<int:provider_id>/check', methods=['POST'])
@login_required
@admin_required
def check_provider_connection(provider_id):
    """Single combined action for the 'Check Connection & Stats' button:
    confirms this provider's link is active AND returns its live OTP
    stats in one response. Push (webhook) providers only — panel/poll
    providers like Basha have no webhook link to check; they're
    monitored separately on the API Monitor page instead."""
    p = Provider.query.get_or_404(provider_id)
    if p.ptype != 'webhook':
        return jsonify({'success': False, 'error': 'This provider is not a webhook provider'}), 400

    connected = bool(p.webhook_secret) and p.is_active
    if connected:
        p.last_webhook_test_at = datetime.utcnow()
        db.session.commit()

    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    total_count = OTPLog.query.filter_by(provider_id=p.id).count()
    today_count = OTPLog.query.filter(
        OTPLog.provider_id == p.id, OTPLog.received_at >= today_start
    ).count()
    last_log = OTPLog.query.filter_by(provider_id=p.id) \
        .order_by(OTPLog.received_at.desc()).first()

    return jsonify({
        'success': True,
        'connected': connected,
        'tested_at': p.last_webhook_test_at.strftime('%Y-%m-%d %H:%M:%S') if p.last_webhook_test_at else None,
        'webhook_status': p.webhook_status(),
        'webhook_receive_count': p.webhook_receive_count or 0,
        'webhook_last_received_at': p.webhook_last_received_at.strftime('%Y-%m-%d %H:%M:%S') if p.webhook_last_received_at else None,
        'stats': {
            'total_received': total_count,
            'today_received': today_count,
            'last_received_at': last_log.received_at.strftime('%Y-%m-%d %H:%M:%S') if last_log else None,
            'last_country': last_log.country if last_log else None,
        }
    })


@provider_bp.route('/admin/providers/<int:provider_id>/toggle', methods=['POST'])
@login_required
@admin_required
def toggle_provider(provider_id):
    p = Provider.query.get_or_404(provider_id)
    if is_running(provider_id):
        stop_provider(provider_id)
        p.is_active = False
        db.session.commit()
        return jsonify({'status': 'stopped'})
    else:
        p.is_active = True
        db.session.commit()
        from flask import current_app
        start_provider(current_app._get_current_object(), provider_id)
        return jsonify({'status': 'started'})

@provider_bp.route('/admin/otp-logs')
@login_required
@admin_required
def otp_logs():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)

    fdate1 = request.args.get('fdate1', '')
    fdate2 = request.args.get('fdate2', '')
    fprovider = request.args.get('fprovider', '')
    frange = request.args.get('frange', '')
    fnum = request.args.get('fnum', '')

    def parse_date(date_str):
        try:
            return datetime.strptime(date_str, '%Y-%m-%d')
        except (ValueError, TypeError):
            return None

    logs_query = OTPLog.query

    date1 = parse_date(fdate1)
    if date1:
        logs_query = logs_query.filter(OTPLog.received_at >= date1)
    date2 = parse_date(fdate2)
    if date2:
        logs_query = logs_query.filter(OTPLog.received_at <= date2.replace(hour=23, minute=59, second=59))

    if fprovider:
        logs_query = logs_query.filter_by(provider_id=fprovider)

    if frange:
        logs_query = logs_query.join(SMSNumber, OTPLog.number_id == SMSNumber.id).filter(SMSNumber.range_id == frange)

    if fnum:
        logs_query = logs_query.filter(OTPLog.number.like(f'%{fnum}%'))

    logs_query = logs_query.order_by(OTPLog.received_at.desc())

    if request.args.get('export'):
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['Date', 'Range', 'Number', 'OTP', 'Sender', 'Client', 'SMS', 'Provider'])
        for l in logs_query.all():
            range_label = ''
            if l.sms_number and l.sms_number.sms_range:
                range_label = l.sms_number.sms_range.name if l.sms_number.sms_range.name else l.sms_number.sms_range.country
            writer.writerow([
                l.received_at.strftime('%Y-%m-%d %H:%M:%S') if l.received_at else '',
                range_label,
                l.number,
                l.otp,
                l.sender or '',
                l.user.username if l.user else '',
                l.message or '',
                l.provider.name if l.provider else ''
            ])
        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype='text/csv',
            headers={'Content-Disposition': 'attachment; filename=otp_logs.csv'}
        )

    logs = logs_query.paginate(page=page, per_page=per_page, error_out=False)
    providers = Provider.query.all()
    ranges = SMDRange.query.filter_by(is_active=True).all()

    now = datetime.utcnow()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    week_start = today_start - timedelta(days=7)
    live_start = now - timedelta(minutes=5)

    stats = {
        'today': OTPLog.query.filter(OTPLog.received_at >= today_start).count(),
        'week': OTPLog.query.filter(OTPLog.received_at >= week_start).count(),
        'live': OTPLog.query.filter(OTPLog.received_at >= live_start).count(),
        'total': OTPLog.query.count(),
        'active_providers': Provider.query.filter_by(is_active=True).count(),
        'total_providers': Provider.query.count(),
    }

    return render_template('admin/otp_logs.html', logs=logs, providers=providers, ranges=ranges, stats=stats)

@provider_bp.route('/agent/otp-inbox')
@login_required
def otp_inbox():
    page = request.args.get('page', 1, type=int)
    if current_user.is_admin():
        logs = OTPLog.query.order_by(OTPLog.received_at.desc()).paginate(
            page=page, per_page=50, error_out=False
        )
    else:
        logs = OTPLog.query.filter_by(user_id=current_user.id).order_by(
            OTPLog.received_at.desc()
        ).paginate(page=page, per_page=50, error_out=False)
    return render_template('main/otp_inbox.html', logs=logs)

def _extract_otp_from_text(text):
    """Best-effort OTP pull from a raw SMS body, for providers that only
    send one combined 'message' field instead of a separate otp/code
    field. Prefers a standalone 4-8 digit run (typical OTP length);
    falls back to the first digit run of any length if nothing that
    size is found."""
    if not text:
        return None
    m = re.search(r'(?<!\d)\d{4,8}(?!\d)', text)
    if m:
        return m.group(0)
    m = re.search(r'\d+', text)
    return m.group(0) if m else None


def _handle_incoming_code(provider):
    """Shared body for both webhook entry points below: validate the
    source IP, validate fields, save the OTP against THIS specific
    provider, update its counters, and log the attempt. `provider` has
    already been identified by the caller (by token, or as the no-key
    default) before this runs."""
    from app.utils import get_client_ip

    client_ip = get_client_ip(request)

    allowed_method = (getattr(provider, 'http_method', None) or 'ANY').upper()
    if allowed_method in ('GET', 'POST') and request.method != allowed_method:
        provider.webhook_fail_count = (provider.webhook_fail_count or 0) + 1
        db.session.commit()
        try:
            from app.models.activity import ApiRequestLog
            ApiRequestLog.log(
                user_id=None, username=provider.name, endpoint='provider.webhook',
                method=request.method, number=None, status='fail', status_code=403,
                message=f'Blocked 🚫 — method {request.method} not allowed (this provider only accepts {allowed_method})',
                ip_address=client_ip
            )
        except Exception:
            pass
        return jsonify({'success': False, 'error': f'Blocked 🚫 — this provider only accepts {allowed_method} requests'}), 403

    if not provider.is_ip_allowed(client_ip):
        provider.webhook_fail_count = (provider.webhook_fail_count or 0) + 1
        db.session.commit()
        try:
            from app.models.activity import ApiRequestLog
            ApiRequestLog.log(
                user_id=None, username=provider.name, endpoint='provider.webhook',
                method=request.method, number=None, status='fail', status_code=403,
                message=f'Blocked 🚫 — IP not whitelisted: {client_ip}', ip_address=client_ip
            )
        except Exception:
            pass
        return jsonify({'success': False, 'error': f'Blocked 🚫 — IP {client_ip} is not whitelisted for this provider'}), 403

    args = request.args
    body = request.get_json(silent=True) or {}

    def field(*names):
        for n in names:
            v = args.get(n)
            if v:
                return v
        for n in names:
            v = body.get(n)
            if v:
                return v
        return None

    # Provider-specific field-name mapping (falls back to the built-in
    # generic aliases when a provider hasn't customized these, so
    # existing providers keep behaving exactly as before).
    cli_field     = (provider.cli_field or 'cli').strip() or 'cli'
    message_field = (provider.message_field or 'message').strip() or 'message'
    uuid_field    = (provider.uuid_field or 'uuid').strip() or 'uuid'

    order_id = field('order_id', 'orderId', 'order', uuid_field)
    phone    = field('phone', 'number', 'phone_number', 'msisdn', cli_field)
    service  = field('service', 'service_name', 'app', 'application')
    otp      = field('otp', 'code', 'pin')
    country  = field('country', 'country_name')
    raw_message = field(message_field, 'message', 'text', 'sms', 'content')

    # No separate otp/code/pin field? Pull the code out of the raw SMS
    # text instead — needed for providers that only forward one combined
    # message field (mapped via message_field) rather than a pre-parsed
    # OTP field.
    if not otp and raw_message:
        otp = _extract_otp_from_text(raw_message)

    if not phone or not otp:
        provider.webhook_fail_count = (provider.webhook_fail_count or 0) + 1
        db.session.commit()
        try:
            from app.models.activity import ApiRequestLog
            ApiRequestLog.log(
                user_id=None, username=provider.name, endpoint='provider.webhook',
                method=request.method, number=phone, status='fail', status_code=400,
                message=f'{cli_field}/otp missing', ip_address=client_ip
            )
        except Exception:
            pass
        return jsonify({'success': False, 'error': f'"{cli_field}" and an OTP/code field are required'}), 400

    result = _save_otp(
        current_app._get_current_object(),
        provider.id,
        phone,
        str(otp),
        sender=service or provider.name,
        message=raw_message or (f'Order {order_id}: {otp}' if order_id else str(otp)),
        order_id=order_id,
        service_name=service,
        source='webhook',
        country_hint=country
    ) or {}

    now = datetime.utcnow()
    provider.last_polled_at = now
    # Push-route-specific connection status: last_polled_at above is
    # shared with the polling fetcher, so it can't tell you on its own
    # whether THIS provider's webhook is actually alive. These two are
    # only ever touched here.
    provider.webhook_last_received_at = now
    if not result.get('duplicate'):
        provider.webhook_receive_count = (provider.webhook_receive_count or 0) + 1
    db.session.commit()

    try:
        from app.models.activity import ApiRequestLog
        ApiRequestLog.log(
            user_id=None, username=provider.name, endpoint='provider.webhook',
            method=request.method, number=phone, status='success',
            status_code=200, message=f'otp={otp}', ip_address=client_ip
        )
    except Exception:
        pass

    return jsonify({
        'success': True,
        'message': 'تم استلام الكود بنجاح' if not result.get('duplicate') else 'الكود مستلم مسبقًا',
        'order_id': order_id,
        'phone': phone,
        'country': result.get('country'),
        'status': 'duplicate' if result.get('duplicate') else 'code_received',
        'matched_number': bool(result.get('matched_number'))
    })


@provider_bp.route('/api/provider/receive-code/<token>', methods=['GET', 'POST'])
def receive_code_by_token(token):
    """This provider's OWN dedicated link. Each webhook-type provider
    gets a unique token, so multiple providers can push to this panel
    at the same time — the token in the URL is what tells them apart,
    not "whichever one is currently enabled" like the old single
    shared link did.
      - GET  .../receive-code/<token>?phone=201012345678&otp=123456
      - POST same fields as JSON body
    """
    provider = Provider.query.filter_by(webhook_secret=token).first()
    if not provider:
        return jsonify({'success': False, 'error': 'Unknown or invalid webhook link'}), 404
    if not provider.is_active:
        return jsonify({'success': False, 'error': 'This provider is currently disabled'}), 403
    return _handle_incoming_code(provider)


@provider_bp.route('/api/provider/receive-code', methods=['GET', 'POST'])
def receive_code():
    """The single PLAIN link with no token in it — only for a provider
    whose own webhook config is a fixed URL field with nowhere to paste
    a per-provider token/path. Only one provider may be set as this
    "no-key default" at a time (see set_default_webhook_provider), since
    there's no token here to tell providers apart. Everyone else should
    use their own /api/provider/receive-code/<token> link instead."""
    provider = Provider.query.filter_by(webhook_no_auth=True).first()
    if not provider:
        return jsonify({'success': False, 'error': 'No default (no-key) provider is set'}), 404
    if not provider.is_active:
        return jsonify({'success': False, 'error': 'This provider is currently disabled'}), 403
    return _handle_incoming_code(provider)


@provider_bp.route('/api/otp-inbox')
@login_required
def otp_inbox_api():
    if current_user.is_admin():
        logs = OTPLog.query.order_by(OTPLog.received_at.desc()).limit(50).all()
    else:
        logs = OTPLog.query.filter_by(user_id=current_user.id).order_by(
            OTPLog.received_at.desc()
        ).limit(50).all()
    return jsonify([{
        'id':          l.id,
        'number':      l.number,
        'otp':         l.otp,
        'sender':      l.sender,
        'message':     l.message,
        'country':     l.country,
        'source':      l.source or 'poll',
        'received_at': l.received_at.strftime('%Y-%m-%d %H:%M:%S')
    } for l in logs])


# ============ PROVIDER CONNECTION MONITOR (status + live stats) ============

def _provider_avg_interval(provider_id, sample=20):
    """Average seconds between consecutive OTP codes for this provider,
    over the last `sample` codes. Returns None if fewer than 2 codes."""
    rows = OTPLog.query.filter_by(provider_id=provider_id) \
        .order_by(OTPLog.received_at.desc()).limit(sample).all()
    times = sorted([r.received_at for r in rows if r.received_at])
    if len(times) < 2:
        return None
    diffs = [(times[i+1] - times[i]).total_seconds() for i in range(len(times) - 1)]
    return sum(diffs) / len(diffs) if diffs else None


def _fmt_duration(seconds):
    if seconds is None:
        return None
    seconds = int(seconds)
    if seconds < 60:
        return f'{seconds}s'
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f'{minutes}m {sec}s'
    hours, minutes = divmod(minutes, 60)
    return f'{hours}h {minutes}m'


def _provider_stats_dict(p, today_start):
    total_codes = OTPLog.query.filter_by(provider_id=p.id).count()
    today_codes = OTPLog.query.filter(
        OTPLog.provider_id == p.id, OTPLog.received_at >= today_start
    ).count()
    last_log = OTPLog.query.filter_by(provider_id=p.id) \
        .order_by(OTPLog.received_at.desc()).first()

    # Success/fail counts: push providers use the dedicated webhook
    # counters; poll providers derive it from their poll-cycle log
    # (ApiRequestLog rows written each cron tick in cron.py/fetcher.py).
    if p.ptype == 'webhook':
        success_count = p.webhook_receive_count or 0
        fail_count = p.webhook_fail_count or 0
    else:
        from app.models.activity import ApiRequestLog
        success_count = ApiRequestLog.query.filter_by(
            username=p.name, endpoint='provider.poll', status='success').count()
        fail_count = ApiRequestLog.query.filter_by(
            username=p.name, endpoint='provider.poll', status='fail').count()

    total_requests = success_count + fail_count
    success_rate = round((success_count / total_requests) * 100, 1) if total_requests else None
    last_seen = p.last_activity_at()
    status = p.connection_status()

    return {
        'id': p.id,
        'name': p.name,
        'ptype': p.ptype,
        'status': status,
        'last_seen': last_seen.strftime('%Y-%m-%d %H:%M:%S') if last_seen else None,
        'total_codes': total_codes,
        'today_codes': today_codes,
        'success_count': success_count,
        'fail_count': fail_count,
        'success_rate': success_rate,
        'avg_interval_seconds': _provider_avg_interval(p.id),
        'avg_interval_label': _fmt_duration(_provider_avg_interval(p.id)),
        'last_code': {
            'number': last_log.number,
            'otp': last_log.otp,
            'sender': last_log.sender,
            'received_at': last_log.received_at.strftime('%Y-%m-%d %H:%M:%S')
        } if last_log else None,
    }


@provider_bp.route('/admin/provider-monitor')
@login_required
@admin_required
def provider_monitor():
    """Live connection-status + stats dashboard for PUSH (webhook)
    providers only — Basha, Ints, API Token and every other
    login/poll-based panel belong to a completely different system
    (they already have their own monitoring at /monitor/api-live) and
    have no place here. This page only ever shows ptype == 'webhook'
    providers, each Online/Idle/Offline right now, plus per-provider
    totals, success rate, and hourly/daily/top-services/top-providers
    charts built ONLY from webhook-sourced codes. The page renders
    once; live numbers refresh via /api/admin/provider-monitor-data."""
    webhook_providers = Provider.query.filter_by(ptype='webhook').order_by(Provider.name.asc()).all()
    return render_template('admin/provider_monitor.html', providers=webhook_providers)


@provider_bp.route('/api/admin/provider-monitor-data')
@login_required
@admin_required
def provider_monitor_data():
    # Everything on this page is scoped to push (webhook) providers only.
    # Panel/poll providers like Basha, Ints, API Token, etc. are a
    # different system entirely — they're already monitored separately
    # at /monitor/api-live (login/fetch cycles) — so they must never
    # appear in these cards or charts.
    webhook_providers = Provider.query.filter_by(ptype='webhook').order_by(Provider.name.asc()).all()
    webhook_provider_ids = [p.id for p in webhook_providers]
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)

    providers_out = [_provider_stats_dict(p, today_start) for p in webhook_providers]

    if not webhook_provider_ids:
        empty_chart = {'labels': [], 'values': []}
        return jsonify({
            'providers': [], 'hourly_chart': empty_chart, 'daily_chart': empty_chart,
            'top_services': empty_chart, 'top_providers': empty_chart,
            'server_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        })

    otp_scope = OTPLog.provider_id.in_(webhook_provider_ids)

    # ── Codes per hour (last 24h) ──
    day_ago = datetime.utcnow() - timedelta(hours=24)
    hourly_rows = db.session.query(
        func.strftime('%Y-%m-%d %H:00', OTPLog.received_at), func.count(OTPLog.id)
    ).filter(otp_scope, OTPLog.received_at >= day_ago).group_by(
        func.strftime('%Y-%m-%d %H:00', OTPLog.received_at)
    ).all() if db.engine.url.get_backend_name() == 'sqlite' else db.session.query(
        func.date_trunc('hour', OTPLog.received_at), func.count(OTPLog.id)
    ).filter(otp_scope, OTPLog.received_at >= day_ago).group_by(
        func.date_trunc('hour', OTPLog.received_at)
    ).all()
    hourly_map = {}
    for ts, cnt in hourly_rows:
        key = ts.strftime('%H:00') if hasattr(ts, 'strftime') else str(ts)[11:16]
        hourly_map[key] = cnt
    hourly_chart = {'labels': [], 'values': []}
    for i in range(23, -1, -1):
        d = datetime.utcnow() - timedelta(hours=i)
        label = d.strftime('%H:00')
        hourly_chart['labels'].append(label)
        hourly_chart['values'].append(hourly_map.get(label, 0))

    # ── Codes per day (last 14 days) ──
    two_weeks_ago = today_start - timedelta(days=13)
    daily_rows = db.session.query(
        func.date(OTPLog.received_at), func.count(OTPLog.id)
    ).filter(otp_scope, OTPLog.received_at >= two_weeks_ago).group_by(
        func.date(OTPLog.received_at)
    ).all()
    daily_map = {str(d): c for d, c in daily_rows}
    daily_chart = {'labels': [], 'values': []}
    for i in range(13, -1, -1):
        d = (today_start - timedelta(days=i)).date()
        daily_chart['labels'].append(d.strftime('%m-%d'))
        daily_chart['values'].append(daily_map.get(str(d), 0))

    # ── Top services (last 30 days) ──
    month_ago = today_start - timedelta(days=30)
    top_services_rows = db.session.query(
        func.coalesce(OTPLog.service_name, OTPLog.sender, 'Unknown'),
        func.count(OTPLog.id)
    ).filter(otp_scope, OTPLog.received_at >= month_ago).group_by(
        func.coalesce(OTPLog.service_name, OTPLog.sender, 'Unknown')
    ).order_by(func.count(OTPLog.id).desc()).limit(8).all()
    top_services = {'labels': [r[0] for r in top_services_rows], 'values': [r[1] for r in top_services_rows]}

    # ── Most active WEBHOOK providers (last 30 days) ──
    top_providers_rows = db.session.query(
        Provider.name, func.count(OTPLog.id)
    ).join(OTPLog, OTPLog.provider_id == Provider.id).filter(
        otp_scope, OTPLog.received_at >= month_ago
    ).group_by(Provider.name).order_by(func.count(OTPLog.id).desc()).limit(8).all()
    top_providers = {'labels': [r[0] for r in top_providers_rows], 'values': [r[1] for r in top_providers_rows]}

    return jsonify({
        'providers': providers_out,
        'hourly_chart': hourly_chart,
        'daily_chart': daily_chart,
        'top_services': top_services,
        'top_providers': top_providers,
        'server_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
    })