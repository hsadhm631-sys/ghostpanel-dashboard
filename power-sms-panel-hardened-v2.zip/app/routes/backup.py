"""
app/routes/backup.py
Export database as SQL and send to Telegram on a schedule (e.g. every 10 min via cron-job.org)
"""
import os
import io
import requests
from datetime import datetime
from flask import Blueprint, jsonify
from sqlalchemy import text, inspect

backup_bp = Blueprint('backup', __name__, url_prefix='/api/backup')


@backup_bp.route('/export-to-telegram', methods=['GET', 'POST'])
def export_to_telegram():
    """Export database schema + data as SQL, zip it, send to Telegram.
    Secured with CRON_SECRET env var (same as daily cron jobs).
    Can be called by external services like cron-job.org on a schedule
    (e.g. every 10 minutes) without needing Vercel's paid tier."""

    from flask import request
    from app import db

    # Same fail-closed CRON_SECRET check as /api/cron/* (the old version
    # exported the whole database to Telegram when CRON_SECRET was unset).
    from app.routes.cron import _cron_auth_error
    auth_error = _cron_auth_error()
    if auth_error is not None:
        return auth_error

    from app.models.telegram import TelegramSettings
    tg_settings = TelegramSettings.get()
    bot_token = tg_settings.bot_token or os.environ.get('TELEGRAM_BOT_TOKEN')
    chat_id = tg_settings.backup_chat_id or os.environ.get('TELEGRAM_CHAT_ID')

    if not bot_token or not chat_id:
        return jsonify({
            'error': 'Bot token / backup chat id not configured. '
                     'Set them on the admin Telegram Bot page (Backup Chat ID field), '
                     'or set TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID env vars as a fallback.'
        }), 500

    try:
        # Generate SQL dump
        sql_lines = []
        sql_lines.append('-- FLASH SMS Panel Database Backup')
        sql_lines.append(f'-- Generated: {datetime.utcnow().isoformat()}')
        sql_lines.append('-- Database exported from Vercel deployment')
        sql_lines.append('BEGIN;')
        sql_lines.append('')

        inspector = inspect(db.engine)
        table_names = inspector.get_table_names()

        for table_name in sorted(table_names):
            # Skip internal/migration tables if any
            if table_name.startswith('_'):
                continue

            result = db.session.execute(text(f'SELECT * FROM "{table_name}"'))
            rows = result.fetchall()
            col_names = result.keys()

            if not rows:
                continue

            col_list = ', '.join(f'"{c}"' for c in col_names)
            sql_lines.append(f'-- Table: {table_name} ({len(rows)} rows)')

            for row in rows:
                values = []
                for col in col_names:
                    val = row[col]
                    if val is None:
                        values.append('NULL')
                    elif isinstance(val, bool):
                        values.append('TRUE' if val else 'FALSE')
                    elif isinstance(val, (int, float)):
                        values.append(str(val))
                    else:
                        # Escape single quotes in strings
                        s = str(val).replace("'", "''")
                        values.append(f"'{s}'")

                sql_lines.append(f'INSERT INTO "{table_name}" ({col_list}) VALUES ({", ".join(values)});')

            sql_lines.append('')

        sql_lines.append('COMMIT;')
        sql_content = '\n'.join(sql_lines)

        # Send to Telegram as a file
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        filename = f'flash_sms_backup_{timestamp}.sql'

        files = {
            'document': (filename, io.BytesIO(sql_content.encode('utf-8')), 'text/plain')
        }
        data = {
            'chat_id': chat_id,
            'caption': f'💾 Database Backup\nTime: {datetime.utcnow().isoformat()}\nTables: {len([t for t in table_names if not t.startswith("_")])}'
        }

        response = requests.post(
            f'https://api.telegram.org/bot{bot_token}/sendDocument',
            files=files,
            data=data,
            timeout=30
        )

        if response.status_code == 200:
            return jsonify({
                'status': 'success',
                'message': f'Backup sent to Telegram ({len(sql_content)} bytes)',
                'file': filename,
                'tables': len(table_names)
            })
        else:
            return jsonify({
                'status': 'error',
                'message': f'Telegram API error: {response.text}'
            }), 500

    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500
