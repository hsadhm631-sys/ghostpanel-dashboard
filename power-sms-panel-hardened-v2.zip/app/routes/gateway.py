import json
import os
import secrets
import time as time_module
from datetime import datetime
from functools import wraps

from flask import Blueprint, render_template, request, jsonify, current_app, url_for
from flask_login import login_required, current_user

from app import db
from app.models.gateway import (
    HttpIncomingLog, DlrMessage, SmsGatewayProvider, SmppSentMessage, HttpEndpoint,
)
from app.models.provider import Provider, OTPLog
from app.models.activity import ApiRequestLog, ActivityLog
from app.utils import get_client_ip, ip_matches_whitelist
from app.security import limiter, secure_equals, is_public_http_url, new_token
from app.smpp_protocol import SmppError, normalize_destination, drop_bound_session

gateway_bp = Blueprint('gateway', __name__)


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        from flask import redirect, url_for, flash
        if not current_user.is_authenticated:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login'))
        if not current_user.is_admin():
            flash('Admin access required.', 'danger')
            return redirect(url_for('main.dashboard'))
        return f(*args, **kwargs)
    return decorated


def _field(data, *names):
    for n in names:
        if n in data and data[n] not in (None, ''):
            return data[n]
    return None


def _request_payload():
    payload = {}
    try:
        if request.is_json:
            payload.update(request.get_json(silent=True) or {})
    except Exception:
        pass
    if request.form:
        payload.update(request.form.to_dict())
    if not payload and request.data:
        try:
            payload.update(json.loads(request.data.decode('utf-8') or '{}'))
        except Exception:
            pass
    for k, v in request.args.to_dict().items():
        payload.setdefault(k, v)
    return payload


def _http_endpoint_ip_status(client_ip, ip_whitelist):
    text = (ip_whitelist or '').strip()
    if not text:
        return False, 'blocked'
    if text.lower() in ('all', '*'):
        return True, 'all'
    return ip_matches_whitelist(client_ip, text), 'restricted'


@gateway_bp.route('/admin/http-incoming')
@login_required
@admin_required
def http_incoming():
    return render_template('admin/http_incoming.html')


@gateway_bp.route('/admin/api-connections')
@login_required
@admin_required
def api_connections():
    return render_template('admin/api_connections.html')


@gateway_bp.route('/admin/http-connection')
@login_required
@admin_required
def http_connection():
    endpoint = HttpEndpoint.query.order_by(HttpEndpoint.id.asc()).first()
    if not endpoint:
        endpoint = HttpEndpoint(
            name='HTTP Incoming Gateway',
            slug='incoming-' + secrets.token_hex(8),
            method='ANY',
            ip_whitelist='all',
            api_token=new_token(24),
        )
        db.session.add(endpoint)
        db.session.commit()
    elif not endpoint.api_token:
        endpoint.api_token = new_token(24)
        db.session.commit()
    # The admin's method and IP rules are shown as configured. They are no
    # longer reset to "open" on every page load.
    return render_template('admin/http_connection.html', endpoint=endpoint)


def _provider_to_hi_dict(p):
    return {
        'id': p.id,
        'name': p.name,
        'ipAddresses': p.ip_whitelist or '',
        'httpMethod': (p.http_method or 'ANY').upper(),
        'cliField': p.cli_field or 'cli',
        'messageField': p.message_field or 'message',
        'uniqueIdField': p.uuid_field or 'uuid',
        'isActive': bool(p.is_active),
        'totalReceived': p.webhook_receive_count or 0,
        'lastReceivedAt': p.webhook_last_received_at.isoformat() if p.webhook_last_received_at else None,
        'webhookUrl': (url_for('provider.receive_code_by_token', token=p.webhook_secret, _external=True)
                       if p.webhook_secret else None),
    }


@gateway_bp.route('/api/admin/http-incoming-providers', methods=['GET', 'POST'])
@login_required
@admin_required
def http_incoming_providers():
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        name = str(data.get('name') or '').strip()
        if not name:
            return jsonify({'error': 'Provider name is required'}), 400
        if Provider.query.filter_by(name=name).first():
            return jsonify({'error': f'A provider named "{name}" already exists'}), 400
        method = (data.get('httpMethod') or 'ANY').upper()
        if method not in ('GET', 'POST', 'ANY'):
            method = 'ANY'
        p = Provider(
            name=name,
            url='webhook (push-only, no URL needed)',
            ptype='webhook',
            is_active=True,
            webhook_secret=secrets.token_hex(8),
            ip_whitelist=data.get('ipAddresses') or '',
            http_method=method,
            cli_field=(data.get('cliField') or 'cli').strip() or 'cli',
            message_field=(data.get('messageField') or 'message').strip() or 'message',
            uuid_field=(data.get('uniqueIdField') or 'uuid').strip() or 'uuid',
        )
        db.session.add(p)
        db.session.commit()
        return jsonify(_provider_to_hi_dict(p))

    providers = Provider.query.filter_by(ptype='webhook').order_by(Provider.id.desc()).all()
    return jsonify([_provider_to_hi_dict(p) for p in providers])


@gateway_bp.route('/api/admin/http-incoming-providers/<int:pid>', methods=['PUT', 'DELETE'])
@login_required
@admin_required
def http_incoming_provider_detail(pid):
    p = Provider.query.filter_by(id=pid, ptype='webhook').first_or_404()
    if request.method == 'DELETE':
        OTPLog.query.filter_by(provider_id=pid).delete()
        db.session.delete(p)
        db.session.commit()
        return jsonify({'success': True})

    data = request.get_json(silent=True) or {}
    if 'name' in data and data['name']:
        p.name = str(data['name']).strip() or p.name
    if 'ipAddresses' in data:
        p.ip_whitelist = data['ipAddresses'] or ''
    if 'httpMethod' in data:
        m = (data['httpMethod'] or 'ANY').upper()
        p.http_method = m if m in ('GET', 'POST', 'ANY') else 'ANY'
    if 'cliField' in data:
        p.cli_field = (data['cliField'] or 'cli').strip() or 'cli'
    if 'messageField' in data:
        p.message_field = (data['messageField'] or 'message').strip() or 'message'
    if 'uniqueIdField' in data:
        p.uuid_field = (data['uniqueIdField'] or 'uuid').strip() or 'uuid'
    if 'isActive' in data:
        p.is_active = bool(data['isActive'])
    db.session.commit()
    return jsonify(_provider_to_hi_dict(p))


@gateway_bp.route('/api/admin/http-incoming-providers/<int:pid>/regenerate', methods=['POST'])
@login_required
@admin_required
def http_incoming_provider_regenerate(pid):
    p = Provider.query.filter_by(id=pid, ptype='webhook').first_or_404()
    p.webhook_secret = secrets.token_hex(8)
    db.session.commit()
    return jsonify(_provider_to_hi_dict(p))


@gateway_bp.route('/api/admin/http-incoming-providers/<int:pid>/check-ip')
@login_required
@admin_required
def check_ip(pid):
    p = Provider.query.filter_by(id=pid, ptype='webhook').first_or_404()
    recent_logs = (ApiRequestLog.query
                   .filter_by(endpoint='provider.webhook', username=p.name)
                   .order_by(ApiRequestLog.id.desc())
                   .limit(10).all())
    last_msg = (OTPLog.query
                .filter_by(provider_id=p.id, source='webhook')
                .order_by(OTPLog.id.desc())
                .first())
    return jsonify({
        'hasTraffic': (p.webhook_receive_count or 0) > 0,
        'lastIp': recent_logs[0].ip_address if recent_logs else None,
        'lastReceivedAt': p.webhook_last_received_at.isoformat() if p.webhook_last_received_at else None,
        'totalReceived': p.webhook_receive_count or 0,
        'lastMessageContent': last_msg.message if last_msg else None,
        'lastMessageCli': last_msg.number if last_msg else None,
        'recentLogs': [
            {'status': 'SUCCESS' if l.status == 'success' else 'FAILED', 'ip': l.ip_address,
             'time': l.created_at.isoformat() if l.created_at else None,
             'error': l.message or ''}
            for l in recent_logs
        ],
    })


@gateway_bp.route('/api/admin/http-incoming-providers/<int:pid>/test-connection')
@login_required
@admin_required
def test_connection(pid):
    p = Provider.query.filter_by(id=pid, ptype='webhook').first_or_404()
    if not p.is_active:
        return jsonify({'status': 'disconnected'})
    if not p.webhook_last_received_at:
        return jsonify({'status': 'disconnected'})
    age = (datetime.utcnow() - p.webhook_last_received_at).total_seconds()
    status = 'connected' if age <= 900 else 'disconnected'
    return jsonify({'status': status})


@gateway_bp.route('/api/admin/http-test', methods=['POST'])
@login_required
@admin_required
def http_incoming_test():
    data = request.get_json(silent=True) or {}
    method = (data.get('method') or 'POST').upper()
    if method not in ('GET', 'POST'):
        method = 'POST'

    try:
        provider_id = int(data.get('providerId'))
    except (TypeError, ValueError):
        provider_id = None
    provider = Provider.query.filter_by(id=provider_id, ptype='webhook').first() if provider_id else None
    if not provider:
        return jsonify({'success': False, 'error': 'Select a provider first'}), 400
    if not provider.webhook_secret:
        return jsonify({'success': False, 'error': 'This provider has no link yet'}), 400

    body = data.get('body')
    if isinstance(body, str):
        try:
            body = json.loads(body or '{}')
        except Exception:
            return jsonify({'success': False, 'error': 'Request body must be valid JSON'}), 400
    if not isinstance(body, dict):
        body = {}

    path = f"/api/provider/receive-code/{provider.webhook_secret}"
    before_count = provider.webhook_receive_count or 0

    start = time_module.time()
    try:
        client = current_app.test_client()
        if method == 'GET':
            resp = client.get(path, query_string=body)
        else:
            resp = client.post(path, json=body)
        latency_ms = round((time_module.time() - start) * 1000)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e),
                         'latencyMs': round((time_module.time() - start) * 1000)})

    resp_json = resp.get_json(silent=True)
    db.session.refresh(provider)
    registered = (provider.webhook_receive_count or 0) > before_count

    return jsonify({
        'success': True,
        'requestMethod': method,
        'requestUrl': path,
        'requestBody': body,
        'statusCode': resp.status_code,
        'latencyMs': latency_ms,
        'responseBody': resp_json if resp_json is not None else resp.get_data(as_text=True),
        'registeredIncoming': registered,
    })

@gateway_bp.route('/api/admin/http-incoming-messages')
@login_required
@admin_required
def http_incoming_messages():
    q = OTPLog.query.filter_by(source='webhook')
    provider_id = request.args.get('providerId')
    if provider_id and provider_id != 'all' and provider_id.isdigit():
        q = q.filter_by(provider_id=int(provider_id))
    logs = q.order_by(OTPLog.id.desc()).limit(200).all()
    return jsonify([{
        'id': l.id,
        'providerId': l.provider_id,
        'providerName': l.provider.name if l.provider else '',
        'senderIp': '',
        'cli': l.number or '',
        'messageContent': l.message or '',
        'uniqueId': l.order_id or '',
        'isDuplicate': False,
        'createdAt': l.received_at.isoformat() if l.received_at else None,
    } for l in logs])


@gateway_bp.route('/api/admin/provider-webhook-logs', methods=['GET', 'DELETE'])
@login_required
@admin_required
def provider_webhook_logs():
    """Request Logs tab for HTTP Incoming's Providers — kept separate
    from /api/http-incoming-logs (which HTTP Connection's own Logs tab
    still uses for its unrelated /http/incoming/<slug> traffic)."""
    if request.method == 'DELETE':
        q = ApiRequestLog.query.filter_by(endpoint='provider.webhook')
        endpoint_id = request.args.get('endpointId')
        if endpoint_id:
            q = q.filter_by(username=endpoint_id)
        q.delete()
        db.session.commit()
        return jsonify({'success': True})

    q = ApiRequestLog.query.filter_by(endpoint='provider.webhook')
    endpoint_name = request.args.get('endpointName')
    status = request.args.get('status')  # SUCCESS / FAILED (UI-facing)
    ip = request.args.get('ip')
    search = request.args.get('search')
    if endpoint_name:
        q = q.filter_by(username=endpoint_name)
    if status == 'SUCCESS':
        q = q.filter_by(status='success')
    elif status == 'FAILED':
        q = q.filter_by(status='fail')
    if ip:
        q = q.filter(ApiRequestLog.ip_address.ilike(f'%{ip}%'))
    if search:
        like = f'%{search}%'
        q = q.filter(db.or_(ApiRequestLog.message.ilike(like), ApiRequestLog.number.ilike(like)))
    logs = q.order_by(ApiRequestLog.id.desc()).limit(300).all()
    return jsonify([{
        'id': l.id,
        'endpointName': l.username or '',
        'ipAddress': l.ip_address or '',
        'status': 'SUCCESS' if l.status == 'success' else 'FAILED',
        'statusCode': l.status_code or 0,
        'errorMessage': (l.message or '') if l.status != 'success' else '',
        'createdAt': l.created_at.isoformat() if l.created_at else None,
    } for l in logs])


@gateway_bp.route('/api/http-incoming-logs', methods=['GET', 'DELETE'])
@login_required
@admin_required
def http_incoming_logs():
    if request.method == 'DELETE':
        q = HttpIncomingLog.query
        endpoint_id = request.args.get('endpointId')
        if endpoint_id:
            q = q.filter_by(endpoint_name=endpoint_id)
        q.delete()
        db.session.commit()
        return jsonify({'success': True})

    q = HttpIncomingLog.query
    endpoint_name = request.args.get('endpointName')
    status = request.args.get('status')
    ip = request.args.get('ip')
    search = request.args.get('search')
    if endpoint_name:
        q = q.filter_by(endpoint_name=endpoint_name)
    if status:
        q = q.filter_by(status=status)
    if ip:
        q = q.filter(HttpIncomingLog.ip_address.ilike(f'%{ip}%'))
    if search:
        like = f'%{search}%'
        q = q.filter(db.or_(HttpIncomingLog.body.ilike(like), HttpIncomingLog.error_message.ilike(like)))
    logs = q.order_by(HttpIncomingLog.id.desc()).limit(300).all()
    return jsonify([l.to_dict() for l in logs])

DLR_DELIVERED = {'DELIVRD', 'DELIVERED'}
DLR_FAILED = {'UNDELIV', 'FAILED', 'REJECTD', 'EXPIRED', 'DELETED'}


def _map_dlr_status(raw_status):
    s = (raw_status or '').strip().upper()
    if s in DLR_DELIVERED:
        return 'delivered'
    if s in DLR_FAILED:
        return 'failed'
    return 'pending'


@gateway_bp.route('/dlr', methods=['GET', 'POST'])
def dlr_intake():
    """Delivery-report intake: GET/POST /dlr?msgid=X&status=DELIVRD&to=Y&message=Z&time=T.

    Rate-limited per IP. When the DLR_TOKEN environment variable is set, the
    caller must send it as the X-DLR-Token header or a 'token' parameter."""
    client_ip = get_client_ip(request)
    if not limiter.consume(f'dlr:{client_ip}', limit=600, window=60):
        return jsonify({'success': False, 'error': 'Too many requests'}), 429
    payload = _request_payload()
    dlr_token = (os.environ.get('DLR_TOKEN') or '').strip()
    if dlr_token:
        supplied = request.headers.get('X-DLR-Token') or str(payload.get('token') or '')
        if not secure_equals(supplied, dlr_token):
            return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    msgid = _field(payload, 'msgid', 'id', 'messageid')
    raw_status = _field(payload, 'status', 'dlr_status', 'stat')
    number = _field(payload, 'to', 'number', 'msisdn')
    message = _field(payload, 'message', 'text', 'msg')
    time_val = _field(payload, 'time', 'donedate', 'submit_date')

    rec = DlrMessage(
        msgid=msgid or '', number=number or '', message=message or '',
        status=_map_dlr_status(raw_status), raw_status=raw_status or '',
        time=time_val or '', sender_ip=get_client_ip(request),
    )
    db.session.add(rec)
    db.session.commit()
    return jsonify({'success': True, 'status': rec.status})


@gateway_bp.route('/api/admin/dlr-messages', methods=['GET', 'DELETE'])
@login_required
@admin_required
def dlr_messages():
    if request.method == 'DELETE':
        DlrMessage.query.delete()
        db.session.commit()
        return jsonify({'success': True})

    q = DlrMessage.query
    status = request.args.get('status')
    if status and status != 'all':
        q = q.filter_by(status=status)
    msgs = q.order_by(DlrMessage.id.desc()).limit(300).all()
    return jsonify([m.to_dict() for m in msgs])


@gateway_bp.route('/api/admin/dlr-messages/pull-url', methods=['POST'])
@login_required
@admin_required
def dlr_pull_url():
    data = request.get_json(silent=True) or {}
    url = (data.get('url') or '').strip()
    method = (data.get('method') or 'GET').upper()
    if not url:
        return jsonify({'error': 'url is required'}), 400

    try:
        import requests
    except ImportError:
        return jsonify({'imported': 0, 'total': 0, 'httpStatus': 0,
                         'rawPreview': '', 'errors': ['requests library not available']})

    safe, reason = is_public_http_url(url)
    if not safe:
        return jsonify({'imported': 0, 'total': 0, 'httpStatus': 0,
                        'rawPreview': '', 'errors': [reason]}), 400
    if method not in ('GET', 'POST'):
        method = 'GET'
    try:
        # Redirects are refused: a public URL must not bounce us to an internal one.
        resp = requests.request(method, url, timeout=10, allow_redirects=False)
    except Exception as e:
        return jsonify({'imported': 0, 'total': 0, 'httpStatus': 0,
                         'rawPreview': '', 'errors': [str(e)]})

    raw_preview = (resp.text or '')[:400]
    errors = []
    records = []
    try:
        parsed = resp.json()
        records = parsed if isinstance(parsed, list) else [parsed]
    except Exception:
        errors.append('Response was not valid JSON — nothing auto-imported')

    imported = 0
    for r in records:
        if not isinstance(r, dict):
            continue
        msgid = _field(r, 'msgid', 'id', 'messageid')
        raw_status = _field(r, 'status', 'dlr_status', 'stat')
        if not msgid and not raw_status:
            continue
        rec = DlrMessage(
            msgid=msgid or '', number=_field(r, 'to', 'number', 'msisdn') or '',
            message=_field(r, 'message', 'text', 'msg') or '',
            status=_map_dlr_status(raw_status), raw_status=raw_status or '',
            time=_field(r, 'time', 'donedate', 'submit_date') or '',
            sender_ip=url,
        )
        db.session.add(rec)
        imported += 1
    db.session.commit()

    return jsonify({
        'imported': imported, 'total': len(records), 'httpStatus': resp.status_code,
        'rawPreview': raw_preview, 'errors': errors,
    })


SENSITIVE_FIELDS = frozenset({'key', 'api_key', 'apikey', 'token', 'password', 'secret'})
MAX_MESSAGE_LENGTH = 1000


def _redact(values):
    """Copy of a request payload with credential-like fields masked for logs."""
    return {str(k): ('***' if str(k).lower() in SENSITIVE_FIELDS else v)
            for k, v in dict(values).items()}


def _endpoint_key_from_request(payload):
    header = (request.headers.get('X-API-Key') or '').strip()
    if header:
        return header
    auth = request.headers.get('Authorization') or ''
    if auth.lower().startswith('bearer '):
        return auth[7:].strip()
    return str(request.args.get('key') or payload.get('key') or '').strip()


def _bump(obj, field):
    setattr(obj, field, (getattr(obj, field) or 0) + 1)


def _active_smpp_provider():
    return (SmsGatewayProvider.query
            .filter_by(is_active=True)
            .filter(SmsGatewayProvider.smpp_host != '', SmsGatewayProvider.smpp_host.isnot(None))
            .filter(SmsGatewayProvider.system_id != '', SmsGatewayProvider.system_id.isnot(None))
            .order_by(SmsGatewayProvider.id.asc())
            .first())


def _apply_smpp_receipt(app, provider_id, receipt):
    """Runs on the SMPP reader thread when an SMSC delivery receipt arrives.
    A multi-part message is 'delivered' only after every part is."""
    msg_id = str(receipt.get('message_id') or '')
    raw_status = str(receipt.get('stat') or '')
    status = _map_dlr_status(raw_status)
    with app.app_context():
        db.session.add(DlrMessage(
            msgid=msg_id, number='', message=str(receipt.get('raw') or ''),
            status=status, raw_status=raw_status, time='', sender_ip='smpp',
        ))
        if msg_id:
            candidates = (SmppSentMessage.query
                          .filter_by(provider_id=provider_id)
                          .filter(SmppSentMessage.smpp_message_id.like(f'%{msg_id}%'))
                          .order_by(SmppSentMessage.id.desc())
                          .limit(50).all())
            for row in candidates:
                if msg_id not in (row.smpp_message_id or '').split(','):
                    continue
                if row.smpp_status in ('delivered', 'failed'):
                    break
                if status == 'failed':
                    row.smpp_status = 'failed'
                elif status == 'delivered':
                    row.parts_delivered = (row.parts_delivered or 0) + 1
                    if row.parts_delivered >= (row.parts or 1):
                        row.smpp_status = 'delivered'
                break
        db.session.commit()


def _send_via_provider(provider, source, destination, text):
    """Send through the provider's persistent SMPP session.

    Returns {ok, ids, parts, encoding, error}. Expected failures (bad input,
    SMSC rejection, unreachable link) come back as ok=False, never as raised
    exceptions, so callers can record them."""
    from app.smpp_protocol import get_bound_session

    if not provider.smpp_host or not provider.system_id:
        return {'ok': False, 'ids': [], 'parts': 0, 'encoding': None,
                'error': f'Provider "{provider.provider_name}" has no SMPP host / System ID configured'}

    app = current_app._get_current_object()
    provider_id = provider.id
    try:
        session = get_bound_session(
            provider_id,
            host=provider.smpp_host,
            port=provider.smpp_port or 2775,
            system_id=provider.system_id,
            password=provider.smsc_password or '',
            bind_type=provider.bind_mode or 'transceiver',
            on_receipt=lambda receipt: _apply_smpp_receipt(app, provider_id, receipt),
            log=lambda line: app.logger.info('[smpp] %s', line),
        )
        result = session.submit(source, destination, text)
    except ValueError as e:
        return {'ok': False, 'ids': [], 'parts': 0, 'encoding': None, 'error': str(e)}
    except SmppError as e:
        link_down = e.code in ('timeout', 'refused', 'dns', 'oserror', 'closed')
        provider.bind_status = 'failed' if link_down else 'connected'
        return {'ok': False, 'ids': list(e.partial_ids), 'parts': 0, 'encoding': None,
                'error': str(e)}

    provider.bind_status = 'connected'
    provider.last_bind_at = datetime.utcnow()
    return {'ok': True, 'ids': result['messageIds'], 'parts': result['parts'],
            'encoding': result['encoding'], 'error': ''}


def _record_sent(provider, sender, destination, text, result):
    rec = SmppSentMessage(
        provider_id=provider.id if provider else None,
        provider_name=provider.provider_name if provider else 'No active provider',
        source_addr=sender, dest_addr=destination, message_content=text,
        encoding=result.get('encoding') or 'GSM',
        smpp_status='submitted' if result.get('ok') else 'failed',
        smpp_message_id=','.join(result.get('ids') or []),
        parts=result.get('parts') or 1,
        parts_delivered=0,
    )
    db.session.add(rec)
    return rec


@gateway_bp.route('/http/incoming/<slug>', methods=['GET', 'POST'])
def http_connection_intake(slug):
    """HTTP -> SMS gateway.

    Authentication: the endpoint's API key, sent as the X-API-Key header,
    as 'Authorization: Bearer <key>', or as a 'key' parameter.
    Fields: msg (required, max 1000 chars); to (optional; when present the
    message is sent through the active SMPP provider); from (optional sender ID).
    """
    client_ip = get_client_ip(request)
    if not limiter.consume(f'http-intake:{client_ip}', limit=300, window=60):
        return jsonify({'success': False, 'error': 'Too many requests'}), 429

    endpoint = HttpEndpoint.query.filter_by(slug=slug).first()
    payload = _request_payload()
    user_agent = (request.headers.get('User-Agent') or '')[:255]
    body_log = json.dumps(_redact(payload), ensure_ascii=False, default=str)
    query_log = json.dumps(_redact(request.args), ensure_ascii=False)

    def _log(status, code, error='', response=None):
        db.session.add(HttpIncomingLog(
            endpoint_name=slug[:100], ip_address=client_ip, method=request.method,
            status=status, status_code=code, error_message=error,
            body=body_log, query_params=query_log,
            response_body=json.dumps(response, default=str) if response is not None else '',
            user_agent=user_agent,
        ))

    if not endpoint or not endpoint.is_active:
        _log('FAILED', 404, 'Endpoint not found or disabled')
        db.session.commit()
        return jsonify({'success': False, 'error': 'Endpoint not found or disabled'}), 404

    _bump(endpoint, 'total_requests')

    if not secure_equals(_endpoint_key_from_request(payload), endpoint.api_token):
        _bump(endpoint, 'total_failed')
        _log('BLOCKED', 401, 'Missing or invalid API key')
        db.session.commit()
        return jsonify({'success': False, 'error': 'Unauthorized: missing or invalid API key'}), 401

    configured = (endpoint.method or 'ANY').upper()
    if configured in ('GET', 'POST') and request.method != configured:
        _bump(endpoint, 'total_failed')
        _log('BLOCKED', 405, f'Method {request.method} not allowed - endpoint only accepts {configured}')
        db.session.commit()
        return jsonify({'success': False,
                        'error': f'Method not allowed - this endpoint only accepts {configured}'}), 405

    ip_allowed, ip_rule = _http_endpoint_ip_status(client_ip, endpoint.ip_whitelist)
    if not ip_allowed:
        reason = ('no IP rule is set - choose "all" or add IPs in the endpoint settings'
                  if ip_rule == 'blocked' else f'IP {client_ip} is not in the allowed list')
        _bump(endpoint, 'total_failed')
        _log('BLOCKED', 403, reason)
        db.session.commit()
        return jsonify({'success': False, 'error': f'Forbidden - {reason}'}), 403

    msg = _field(payload, 'msg', 'message', 'text')
    if msg is None:
        _bump(endpoint, 'total_failed')
        _log('FAILED', 400, '"msg" field is required')
        db.session.commit()
        return jsonify({'success': False, 'error': '"msg" field is required'}), 400
    msg = str(msg)
    if len(msg) > MAX_MESSAGE_LENGTH:
        _bump(endpoint, 'total_failed')
        _log('FAILED', 400, f'"msg" is too long (maximum {MAX_MESSAGE_LENGTH} characters)')
        db.session.commit()
        return jsonify({'success': False,
                        'error': f'"msg" is too long (maximum {MAX_MESSAGE_LENGTH} characters)'}), 400

    destination = None
    destination_raw = _field(payload, 'to', 'number', 'msisdn')
    if destination_raw is not None:
        try:
            destination = normalize_destination(destination_raw)
        except ValueError as e:
            _bump(endpoint, 'total_failed')
            _log('FAILED', 400, str(e))
            db.session.commit()
            return jsonify({'success': False, 'error': str(e)}), 400

    sender = str(_field(payload, 'from', 'sender', 'source') or 'HTTP-GW').strip()[:20] or 'HTTP-GW'

    if destination is None:
        _bump(endpoint, 'total_success')
        _log('SUCCESS', 200, response={'success': True, 'forwarded': False})
        db.session.commit()
        return jsonify({'success': True, 'forwarded': False})

    provider = _active_smpp_provider()
    if provider is None:
        _bump(endpoint, 'total_failed')
        _record_sent(None, sender, destination, msg,
                     {'ok': False, 'ids': [], 'parts': 0, 'encoding': None})
        _log('FAILED', 503, 'No active SMPP provider configured')
        db.session.commit()
        return jsonify({'success': False, 'error': 'No active SMPP provider configured'}), 503

    result = _send_via_provider(provider, sender, destination, msg)
    _record_sent(provider, sender, destination, msg, result)
    if result['ok']:
        _bump(endpoint, 'total_success')
        body = {'success': True, 'forwarded': True, 'status': 'submitted',
                'parts': result['parts'], 'messageIds': result['ids']}
        _log('SUCCESS', 200, response=body)
        db.session.commit()
        return jsonify(body)

    _bump(endpoint, 'total_failed')
    body = {'success': False, 'forwarded': False, 'error': result['error'],
            'messageIds': result['ids']}
    _log('FAILED', 502, result['error'], response=body)
    db.session.commit()
    return jsonify(body), 502


@gateway_bp.route('/api/admin/http-endpoint', methods=['GET'])
@login_required
@admin_required
def http_endpoint_settings():
    endpoint = HttpEndpoint.query.order_by(HttpEndpoint.id.asc()).first()
    if not endpoint:
        return jsonify({'error': 'No endpoint found'}), 404
    return jsonify(endpoint.to_dict())


@gateway_bp.route('/api/admin/http-endpoint/regenerate-key', methods=['POST'])
@login_required
@admin_required
def http_endpoint_regenerate_key():
    endpoint = HttpEndpoint.query.order_by(HttpEndpoint.id.asc()).first()
    if not endpoint:
        return jsonify({'error': 'No endpoint found'}), 404
    endpoint.api_token = new_token(24)
    db.session.commit()
    ActivityLog.log(current_user.id, 'http_endpoint_key_regenerated',
                    'HTTP Connection API key regenerated', ip_address=get_client_ip(request))
    return jsonify(endpoint.to_dict())


@gateway_bp.route('/api/admin/http-endpoint/test', methods=['POST'])
@login_required
@admin_required
def http_endpoint_test():
    from app.smpp_protocol import test_bind as smpp_test_bind

    endpoint = HttpEndpoint.query.order_by(HttpEndpoint.id.asc()).first()
    if not endpoint:
        return jsonify({'success': False, 'error': 'No endpoint found'}), 404

    admin_ip = get_client_ip(request)
    report = {'success': True}

    # 1) Endpoint state
    report['endpoint'] = {
        'active': bool(endpoint.is_active), 'slug': endpoint.slug,
        'method': endpoint.method or 'ANY', 'name': endpoint.name,
    }
    if not endpoint.is_active:
        report['success'] = False
    ip_allowed, ip_rule = _http_endpoint_ip_status(admin_ip, endpoint.ip_whitelist)
    report['ipCheck'] = {
        'yourIp': admin_ip, 'allowed': ip_allowed, 'rule': ip_rule,
        'message': (
            'No IP whitelist set — every request is currently blocked. Set it to "all" or add specific IPs in Settings.'
            if ip_rule == 'blocked' else
            'Open to any IP.' if ip_rule == 'all' else
            (f'Your IP ({admin_ip}) is on the allowed list.' if ip_allowed else f'Your IP ({admin_ip}) is NOT on the allowed list — it would be blocked.')
        ),
    }
    if ip_rule == 'blocked':
        report['success'] = False
    report['methodCheck'] = {
        'configured': endpoint.method or 'ANY',
        'getAllowed': (endpoint.method or 'ANY').upper() in ('GET', 'ANY'),
        'postAllowed': (endpoint.method or 'ANY').upper() in ('POST', 'ANY'),
    }
    try:
        client = current_app.test_client()
        resp = client.post(
            f'/http/incoming/{endpoint.slug}',
            json={'msg': 'FLASH SMS system test - safe to ignore'},
            headers={'X-API-Key': endpoint.api_token or ''},
            # The test runs as this admin's IP, without trusting any header.
            environ_base={'REMOTE_ADDR': admin_ip},
        )
        sim_ok = resp.status_code == 200
        report['simulatedRequest'] = {
            'success': sim_ok, 'statusCode': resp.status_code,
            'message': (resp.get_json() or {}).get('error') if not sim_ok else 'Endpoint accepted a test request successfully.',
        }
        if not sim_ok:
            report['success'] = False
    except Exception as e:
        report['simulatedRequest'] = {'success': False, 'statusCode': 0, 'message': str(e)}
        report['success'] = False
    provider = SmsGatewayProvider.query.filter_by(is_active=True).filter(
        SmsGatewayProvider.smpp_host != '', SmsGatewayProvider.smpp_host.isnot(None)
    ).first()
    if not provider:
        report['smpp'] = {'tested': False, 'success': False,
                           'message': 'No active SMPP provider configured yet — add one in API Connections so forwarded messages ("to" field) have somewhere to go.'}
    else:
        result = smpp_test_bind(
            host=provider.smpp_host, port=provider.smpp_port or 2775,
            system_id=provider.system_id, password=provider.smsc_password or '',
            bind_type=provider.bind_mode or 'transceiver',
        )
        sock = result.pop('_socket', None)
        if sock:
            try:
                sock.close()
            except Exception:
                pass
        provider.bind_status = 'connected' if result['success'] else 'failed'
        if result['success']:
            provider.last_bind_at = datetime.utcnow()
            provider.last_bind_ms = result['details'].get('bindTime') or result['details'].get('connectTime')
        db.session.commit()
        report['smpp'] = {
            'tested': True, 'success': result['success'], 'providerName': provider.provider_name,
            'message': result['message'], 'details': result.get('details', {}),
        }
        if not result['success']:
            report['success'] = False

    return jsonify(report)


# ─────────────────────────── SMPP Providers (API Connections) ───────────────────────────

@gateway_bp.route('/api/sms-providers', methods=['GET', 'POST'])
@login_required
@admin_required
def sms_providers():
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        if not str(data.get('providerName') or '').strip():
            return jsonify({'error': 'Provider name is required'}), 400
        p = SmsGatewayProvider(
            provider_name=str(data['providerName']).strip(),
            email=data.get('email') or '', ip_addresses=data.get('ipAddresses') or '',
            esme_username=(data.get('esmeUsername') or '')[:8],
            esme_password=data.get('esmePassword') or '',
            number_field=data.get('numberField') or 'number',
            cli_field=data.get('cliField') or 'cli',
            message_field=data.get('messageField') or 'message',
            unique_id_field=data.get('uniqueIdField') or 'uuid',
            return_value=data.get('returnValue') or 'OK-#uuid',
            smpp_host=data.get('smppHost') or '', smpp_port=data.get('smppPort') or '2775',
            system_id=data.get('systemId') or '', smsc_password=data.get('smscPassword') or '',
            bind_mode=data.get('bindMode') or '',
            connection_allowed_ip=data.get('connectionAllowedIp') or '',
        )
        db.session.add(p)
        db.session.commit()
        return jsonify(p.to_dict())

    providers = SmsGatewayProvider.query.order_by(SmsGatewayProvider.id.desc()).all()
    return jsonify([p.to_dict() for p in providers])


@gateway_bp.route('/api/sms-providers/<int:pid>', methods=['PATCH', 'DELETE'])
@login_required
@admin_required
def sms_provider_detail(pid):
    p = SmsGatewayProvider.query.get_or_404(pid)
    if request.method == 'DELETE':
        drop_bound_session(pid)
        db.session.delete(p)
        db.session.commit()
        return jsonify({'success': True})

    data = request.get_json(silent=True) or {}
    field_map = {
        'providerName': 'provider_name', 'email': 'email', 'ipAddresses': 'ip_addresses',
        'esmeUsername': 'esme_username', 'esmePassword': 'esme_password',
        'numberField': 'number_field', 'cliField': 'cli_field', 'messageField': 'message_field',
        'uniqueIdField': 'unique_id_field', 'returnValue': 'return_value',
        'smppHost': 'smpp_host', 'smppPort': 'smpp_port', 'systemId': 'system_id',
        'smscPassword': 'smsc_password', 'bindMode': 'bind_mode',
        'connectionAllowedIp': 'connection_allowed_ip',
    }
    for key, attr in field_map.items():
        if key in data:
            setattr(p, attr, data[key])
    db.session.commit()
    return jsonify(p.to_dict())


@gateway_bp.route('/api/sms-providers/<int:pid>/test-bind', methods=['POST'])
@login_required
@admin_required
def test_bind(pid):
    from app.smpp_protocol import test_bind as smpp_test_bind

    p = SmsGatewayProvider.query.get_or_404(pid)
    if not p.smpp_host or not p.system_id:
        return jsonify({'success': False, 'status': 'failed',
                         'message': 'SMPP host and System ID are required',
                         'details': {'errorMessage': 'Missing host/systemId'}}), 200

    p.bind_status = 'connecting'
    db.session.commit()

    result = smpp_test_bind(
        host=p.smpp_host, port=p.smpp_port or 2775,
        system_id=p.system_id, password=p.smsc_password or '',
        bind_type=p.bind_mode or 'transceiver',
    )
    sock = result.pop('_socket', None)
    if sock:
        try:
            sock.close()
        except Exception:
            pass

    if result['success']:
        p.bind_status = 'connected'
        p.last_bind_at = datetime.utcnow()
        p.last_bind_ms = result['details'].get('bindTime') or result['details'].get('connectTime')
    else:
        p.bind_status = 'failed'
    db.session.commit()
    return jsonify(result)


@gateway_bp.route('/api/sms-providers/<int:pid>/test-sms', methods=['POST'])
@login_required
@admin_required
def test_sms(pid):
    p = SmsGatewayProvider.query.get_or_404(pid)
    data = request.get_json(silent=True) or {}
    destination = str(data.get('destination') or '').strip()
    message = str(data.get('message') or '').strip()
    sender = str(data.get('senderId') or p.provider_name or 'TEST').strip()[:20] or 'TEST'
    if not p.smpp_host or not p.system_id:
        return jsonify({'success': False, 'status': 'failed',
                        'message': 'SMPP host and System ID are required'}), 200
    if not destination or not message:
        return jsonify({'success': False, 'status': 'failed',
                        'message': 'Destination and message are required'}), 200
    try:
        normalize_destination(destination)
    except ValueError as e:
        return jsonify({'success': False, 'status': 'failed', 'message': str(e)}), 200

    result = _send_via_provider(p, sender, destination, message)
    _record_sent(p, sender, destination, message, result)
    db.session.commit()
    if result['ok']:
        return jsonify({
            'success': True, 'status': 'submitted',
            'message': f"SMS submitted to {destination} ({result['encoding']}, {result['parts']} part(s))",
            'messageId': result['ids'][0],
            'messageIds': result['ids'],
        })
    return jsonify({'success': False, 'status': 'failed', 'message': result['error']})


@gateway_bp.route('/api/sms-providers/<int:pid>/disconnect', methods=['POST'])
@login_required
@admin_required
def disconnect_provider(pid):
    p = SmsGatewayProvider.query.get_or_404(pid)
    drop_bound_session(pid)
    p.bind_status = 'disconnected'
    db.session.commit()
    return jsonify({'success': True})


@gateway_bp.route('/api/http-smpp-send', methods=['POST'])
@login_required
@admin_required
def http_smpp_send():
    data = request.get_json(silent=True) or {}
    try:
        provider = SmsGatewayProvider.query.get(int(data.get('providerId')))
    except (TypeError, ValueError):
        provider = None
    destination = str(data.get('destination') or '').strip()
    message = str(data.get('message') or '').strip()
    if not provider or not destination or not message:
        return jsonify({'success': False, 'message': 'Provider, destination and message are required'})
    try:
        normalize_destination(destination)
    except ValueError as e:
        return jsonify({'success': False, 'message': str(e)})
    if not provider.smpp_host or not provider.system_id:
        return jsonify({'success': False, 'message':
                         f'Provider "{provider.provider_name}" has no SMPP host/System ID configured'})

    sender = str(data.get('senderId') or 'HTTP-GW').strip()[:20] or 'HTTP-GW'
    result = _send_via_provider(provider, sender, destination, message)
    _record_sent(provider, sender, destination, message, result)
    db.session.commit()
    if result['ok']:
        return jsonify({'success': True,
                        'message': f"SMS submitted to {destination} ({result['encoding']}, {result['parts']} part(s))"})
    return jsonify({'success': False, 'message': result['error']})


@gateway_bp.route('/api/http-smpp-messages')
@login_required
@admin_required
def http_smpp_messages():
    msgs = SmppSentMessage.query.order_by(SmppSentMessage.id.desc()).limit(200).all()
    return jsonify([m.to_dict() for m in msgs])