#!/bin/bash
# سكربت التثبيت الأول. آمن لإعادة التشغيل: لا يكتب فوق .env موجود.
set -e

APP_DIR=$(cd "$(dirname "$0")" && pwd)
cd "$APP_DIR"

echo "==> إنشاء virtual environment"
python3 -m venv venv
source venv/bin/activate

echo "==> تثبيت المكتبات"
pip install --upgrade pip
pip install -r requirements.txt

echo "==> إنشاء فولدرات اللوجات والبيانات"
mkdir -p logs instance

if [ ! -f .env ]; then
    echo "==> إنشاء ملف .env من القالب"
    cp .env.example .env
    chmod 600 .env
fi

# ولّد SECRET_KEY إذا كان فارغًا (مفتاح واحد ثابت لكل تثبيت)
if grep -q '^SECRET_KEY=$' .env; then
    SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
    sed -i "s|^SECRET_KEY=$|SECRET_KEY=${SECRET}|" .env
    echo "==> تم توليد SECRET_KEY"
fi

# ولّد DATA_ENCRYPTION_KEY إذا كان فارغًا (يشفّر كلمات مرور SMPP في قاعدة البيانات)
if grep -q '^DATA_ENCRYPTION_KEY=$' .env; then
    DATA_KEY=$(python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
    sed -i "s|^DATA_ENCRYPTION_KEY=$|DATA_ENCRYPTION_KEY=${DATA_KEY}|" .env
    echo "==> تم توليد DATA_ENCRYPTION_KEY (انسخ ملف .env في مكان آمن)"
fi

echo "==> تشغيل الاختبارات"
python3 -m unittest discover -s tests

echo ""
echo "==> خلصت التثبيت."
echo "!! راجع ملف .env قبل التشغيل، وبالأخص:"
echo "   PORT، ADMIN_PASSWORD (وإلا يُولَّد في instance/initial_admin_password.txt)،"
echo "   TRUST_PROXY_HOPS=1 خلف nginx، CRON_SECRET، SMS_RECEIVE_SECRET."
echo ""
echo "شغّل السيرفر يدويًا للتجربة:"
echo "  source venv/bin/activate && gunicorn -c gunicorn_conf.py run:app"
