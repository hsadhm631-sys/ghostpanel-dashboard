import os, re, json, logging, html as _html
from datetime import datetime, timedelta
import time, random
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

_BASE_HEADERS = {
    "User-Agent":      _UA,
    "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate",
    "Connection":      "keep-alive",
}

_AJAX_HEADERS = {
    "User-Agent":       _UA,
    "Accept":           "application/json, text/javascript, */*; q=0.01",
    "Accept-Language":  "en-US,en;q=0.9",
    "Accept-Encoding":  "gzip, deflate",
    "X-Requested-With": "XMLHttpRequest",
    "Connection":       "keep-alive",
}

_LOGIN_PAGE_SIGNALS = [
    "sign in", "signin", "please sign",
    "log in", "please login",
    "authentication required", "session expired",
    "unauthorized", "access denied",
]


def _dates():
    today     = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    return f"{yesterday} 00:00:00", f"{today} 23:59:59"


def _session():
    import requests as rq
    s = rq.Session()
    s.headers.update(_BASE_HEADERS)
    return s


def serialize_session(session_info):
    """Turn a (requests.Session, extra, url) tuple — the shape every
    *_login() function in this file returns — into a JSON string that can
    be stored in Provider.session_data. Vercel has no long-lived process
    to keep the Session object in memory between polls, so this is how a
    login survives from one stateless cron tick to the next.
    """
    if not session_info:
        return None
    try:
        s, extra, url = session_info
        import requests as _rq
        return json.dumps({
            'cookies': _rq.utils.dict_from_cookiejar(s.cookies),
            'extra': extra,
            'url': url,
        })
    except Exception:
        logger.exception("serialize_session failed")
        return None


def deserialize_session(data):
    """Rebuild the (requests.Session, extra, url) tuple that serialize_session()
    saved. Returns None if there's nothing stored yet or it fails to parse,
    which the caller treats the same as "not logged in — please log in"."""
    if not data:
        return None
    try:
        import requests as _rq
        d = json.loads(data)
        s = _session()
        s.cookies = _rq.utils.cookiejar_from_dict(d.get('cookies') or {})
        return (s, d.get('extra'), d.get('url'))
    except Exception:
        logger.exception("deserialize_session failed")
        return None


def _solve_captcha(html_text: str) -> str:
    for pat in [
        r'What is\s*(\d+)\s*\+\s*(\d+)',
        r'(\d+)\s*\+\s*(\d+)\s*=',
        r'captcha[^>]*>\s*(\d+)\s*\+\s*(\d+)',
        r'>(\d+)\s*\+\s*(\d+)<',
        r'(\d+)\s*\+\s*(\d+)',
    ]:
        m = re.search(pat, html_text, re.I)
        if m:
            return str(int(m.group(1)) + int(m.group(2)))
    for pat in [
        r'What is\s*(\d+)\s*-\s*(\d+)',
        r'(\d+)\s*-\s*(\d+)\s*=',
    ]:
        m = re.search(pat, html_text, re.I)
        if m:
            result = int(m.group(1)) - int(m.group(2))
            return str(max(0, result))
    try:
        from bs4 import BeautifulSoup
        plain = BeautifulSoup(html_text, "html.parser").get_text()
        for pat in [r'(\d+)\s*\+\s*(\d+)', r'(\d+)\s*-\s*(\d+)']:
            m = re.search(pat, plain)
            if m:
                a, b = int(m.group(1)), int(m.group(2))
                if "+" in pat:
                    return str(a + b)
                return str(max(0, a - b))
    except ImportError:
        pass
    logger.warning("Captcha not found — sending 0")
    return "0"


def _captcha(html: str) -> int:
    return int(_solve_captcha(html) or "0")


def _is_session_expired(resp) -> bool:
    if resp.status_code in (401, 403):
        return True
    final_url = str(resp.url).lower()
    if any(x in final_url for x in ["/login", "/signin", "/sign-in", "/auth/login"]):
        return True
    if resp.history:
        last_url = str(resp.history[-1].url).lower()
        if (any(x in last_url for x in ["/login", "/signin", "/sign-in"])
                and "json" not in resp.headers.get("Content-Type", "").lower()):
            page = resp.text[:1500].lower()
            if "<html" in page and any(w in page for w in ["sign in", "please login", "signin"]):
                return True
    ct = resp.headers.get("Content-Type", "").lower()
    if "json" not in ct:
        text_low = resp.text[:3000].lower()
        if ("<html" in text_low or "<form" in text_low):
            if any(w in text_low for w in _LOGIN_PAGE_SIGNALS):
                return True
    return False


def _classify(resp) -> str:
    if _is_session_expired(resp):
        return "login_page"
    ct   = resp.headers.get("Content-Type", "").lower()
    text = resp.text.strip()
    if not text:
        return "empty"
    if "json" in ct or text.startswith("[") or text.startswith("{"):
        return "json"
    return "html_other"


def _parse(text: str, mask_only=False) -> list:
    text = text.strip()
    if not text or text.startswith("<"):
        return []
    try:
        js = json.loads(text)
    except Exception:
        cut = text.rfind("]")
        if cut > 0:
            try:
                js = json.loads(text[:cut + 1])
            except Exception:
                return []
        else:
            return []

    if isinstance(js, dict):
        rows = js.get("aaData") or js.get("data") or []
    elif isinstance(js, list):
        rows = js
    else:
        return []

    INVALID = {"None", "", "null", "—", "****", "***", "**", "*", "N/A", "$"}
    out = []

    for row in rows:
        if isinstance(row, list):
            if len(row) < 4:
                continue
            if str(row[0]).startswith("0,"):
                continue
            num = str(row[2]).strip().lstrip("+")
            if not num.isdigit() or num == "0":
                continue
            sms = ""
            for col in [5, 4, 6]:
                v = str(row[col]).strip() if len(row) > col else ""
                if v and v not in INVALID and not re.match(r'^\*+$', v):
                    sms = _html.unescape(v)
                    break
            if mask_only and not sms:
                continue
            out.append([str(row[0]), str(row[1]), num, str(row[3]), None, sms])
        elif isinstance(row, dict):
            num = str(row.get("number", row.get("num", row.get("msisdn", "")))).strip().lstrip("+")
            if not num.isdigit() or num == "0":
                continue
            sms = str(row.get("sms", row.get("message", row.get("text", "")))).strip()
            if sms in INVALID or re.match(r'^\*+$', sms):
                sms = ""
            if mask_only and not sms:
                continue
            sms = _html.unescape(sms)
            cli = str(row.get("cli", row.get("service", row.get("sender", "")))).strip()
            dt  = str(row.get("date", row.get("dt", row.get("time", "")))).strip()
            rid = str(row.get("id", row.get("rowid", ""))).strip()
            out.append([dt, rid, num, cli, None, sms])

    return out


def _core_fetch(s, url: str, path: str):
    d1, d2 = _dates()
    paths_to_try = list(dict.fromkeys([path, "agent", "client", "reseller"]))

    for p in paths_to_try:
        base_params = {
            "fdate1": d1, "fdate2": d2,
            "frange": "", "fclient": "", "fnum": "", "fcli": "",
            "fgdate": "", "fgmonth": "", "fgrange": "",
            "fgclient": "", "fgnumber": "", "fgcli": "",
            "fg": "0",
        }

        for ep in [
            f"{url}/{p}/res/data_smscdr.php",
            f"{url}/{p}/res/data_smscdrreports.php",
        ]:
            try:
                r = s.get(ep, params=base_params,
                          headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/SMSCDRStats"},
                          timeout=20, allow_redirects=True)
                if _is_session_expired(r):
                    return None
                if _classify(r) == "json":
                    rows = _parse(r.text)
                    if rows:
                        return rows
            except Exception as e:
                err = str(e)
                if any(x in err for x in ["NewConnection", "ConnectionError",
                                           "Failed to establish", "Max retries"]):
                    break
                continue

        sesskey = ""
        for stats_ep in [
            f"{url}/{p}/SMSCDRStats",
            f"{url}/{p}/SMSCDRReports",
        ]:
            if sesskey:
                break
            try:
                rs = s.get(stats_ep,
                           headers={**_BASE_HEADERS, "Referer": f"{url}/{p}/SMSDashboard"},
                           timeout=15, allow_redirects=True)
                if _is_session_expired(rs):
                    return None
                m = re.search(r'sesskey=([A-Za-z0-9+/=_-]+)', rs.text)
                if m:
                    sesskey = m.group(1)
            except Exception:
                continue

        if sesskey:
            for ep in [
                f"{url}/{p}/res/data_smscdr.php",
                f"{url}/{p}/res/data_smscdrreports.php",
            ]:
                try:
                    r = s.get(ep, params={**base_params, "sesskey": sesskey},
                              headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/SMSCDRStats"},
                              timeout=20, allow_redirects=True)
                    if _is_session_expired(r):
                        return None
                    if _classify(r) == "json":
                        rows = _parse(r.text)
                        if rows:
                            return rows
                except Exception:
                    pass

        try:
            r = s.get(f"{url}/{p}/res/data_testsmscdr.php",
                      params={"fdate1": d1, "fdate2": d2, "fg": "0"},
                      headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/SMSTestPanel"},
                      timeout=15, allow_redirects=True)
            if _is_session_expired(r):
                return None
            if _classify(r) == "json":
                rows = _parse(r.text)
                if rows:
                    return rows
        except Exception:
            pass

    return []



# ─────────────────────────────────────────────────────────────
# API-token panels (Seven1Tel, D-Group, Konekta API, PC CALL, ...)
# Same logic/equation as FLASH-SMS-BOT: no username/password login,
# just a GET request to the crapi "viewstats" endpoint with the token.
# ─────────────────────────────────────────────────────────────
def apitoken_login(bn, api_token, url=""):
    """API-token panels don't need a real login — mirrors login_for_dashboard()
    in FLASH-SMS-BOT.py where dash['is_logged_in'] is just set to True."""
    s = _session()
    return (s, api_token, url)


def apitoken_fetch(bn, session_info, url=""):
    """Mirrors fetch_api_token_rows() + parse_api_token_row() from FLASH-SMS-BOT.py."""
    if isinstance(session_info, tuple) and len(session_info) == 3:
        s, token, _url = session_info
        url = _url or url
    else:
        s = _session()
        token = session_info

    if not url or not token:
        return []

    headers = {**_BASE_HEADERS, "Accept": "application/json, text/plain, */*"}
    today = datetime.now()
    params = {
        "token":   token,
        "records": 50,
        "dt1": (today - timedelta(days=1)).strftime("%Y-%m-%d 00:00:00"),
        "dt2":  today.strftime("%Y-%m-%d 23:59:59"),
    }
    try:
        r = s.get(url, params=params, headers=headers, timeout=15)
        if r.status_code == 403:
            r = s.get(url, params=params, headers={**headers, "Authorization": f"Bearer {token}"}, timeout=15)
        if r.status_code != 200:
            logger.warning(f"{bn} · api_token HTTP {r.status_code}")
            return []
        raw = r.text.strip()
        if not raw:
            return []
        try:
            j = r.json()
        except Exception:
            return []
    except Exception as e:
        logger.error(f"{bn} · api_token fetch error: {e}")
        return None

    rows = []
    if isinstance(j, dict):
        if j.get("status") == "success" and j.get("data"):
            rows = j["data"]
        else:
            for key in ("data", "aaData", "rows", "result"):
                if key in j and isinstance(j[key], list):
                    rows = j[key]
                    break
    elif isinstance(j, list):
        rows = j

    out = []
    for row in rows:
        if isinstance(row, dict):
            num = str(row.get("num", row.get("number", row.get("msisdn", "")))).strip().lstrip("+")
            if not num.isdigit() or num == "0":
                continue
            sms = str(row.get("message", row.get("sms", row.get("text", "")))).strip()
            if not sms:
                continue
            cli = str(row.get("cli", row.get("service", row.get("sender", "")))).strip()
            dt = str(row.get("dt", row.get("date", row.get("time", "")))).strip()
            out.append([dt, "", num, cli, None, _html.unescape(sms)])
        elif isinstance(row, (list, tuple)):
            # NumberPanel ("Numper Panel" in the bot) returns array rows with a
            # DIFFERENT index layout than the other list-style panels:
            # idx_date=3, idx_number=1, idx_sms=2, no cli/service field at all.
            # Mirrors row_to_tuple()/parse_api_token_row() exactly for this dash.
            if "/crapi/st/" in (url or ""):
                if len(row) <= 1:
                    continue
                num = str(row[1]).strip().lstrip("+") if len(row) > 1 else ""
                sms = str(row[2]).strip() if len(row) > 2 else ""
                dt  = str(row[3]).strip() if len(row) > 3 else ""
                if not num.isdigit() or num == "0" or not sms:
                    continue
                out.append([dt, "", num, "", None, _html.unescape(sms)])
                continue
            if len(row) < 4:
                continue
            num = str(row[1]).strip().lstrip("+")
            if not num.isdigit() or num == "0":
                continue
            out.append([str(row[0]), "", num, str(row[3]) if len(row) > 3 else "", None, str(row[2]) if len(row) > 2 else ""])

    return out


def _extract_hidden_fields(html_text: str) -> dict:
    """Same helper as _extract_hidden_fields() in FLASH-SMS-BOT.py: grabs every
    hidden <input> on the login page (CSRF tokens, crlf, etc.) so nothing the
    server expects back is missing from the login POST."""
    fields = {}
    for m in re.finditer(
        r'<input[^>]+type=["\']hidden["\'][^>]*>', html_text, re.IGNORECASE
    ):
        tag = m.group(0)
        name_m = re.search(r'name=["\']([^"\']+)["\']', tag)
        value_m = re.search(r'value=["\']([^"\']*)["\']', tag)
        if name_m:
            fields[name_m.group(1)] = value_m.group(1) if value_m else ""
    return fields


def _login_success_equation(resp, login_page_url: str) -> bool:
    """Exact same multi-signal 'equation' FLASH-SMS-BOT.py uses in
    login_for_dashboard() to decide whether a login actually worked, instead
    of only trusting one session-cookie name (which caused false 'login
    failed' on panels using a different cookie)."""
    resp_url_lower = resp.url.lower()
    resp_text_lower = resp.text.lower()
    return (
        "agent" in resp_url_lower or
        "dashboard" in resp_url_lower or
        "reports" in resp_url_lower or
        "smscdr" in resp_text_lower or
        "logout" in resp_text_lower or
        "signout" in resp_text_lower or
        "/ints/agent" in resp.url or
        "/ints/client" in resp.url or
        ("/agent" in resp.url and "login" not in resp_url_lower) or
        (resp.url != login_page_url and "signin" not in resp_url_lower
         and "login" not in resp_url_lower and "sign-in" not in resp_url_lower) or
        (resp.status_code == 200 and "sign-in" not in resp_url_lower
         and "login" not in resp_url_lower and "signin" not in resp_url_lower
         and not bool(re.search(r'<input[^>]+type=["\']password["\']', resp.text, re.IGNORECASE))
         and len(resp.text) > 2000)
    )


def ints_login(bn, email, pw, url="", forced_path=None):
    s = _session()
    # Bolt SMS is the one "ints"-style panel in FLASH-SMS-BOT.py whose
    # login_page is capitalized ("/Login" not "/login") — everything else
    # in PANEL_SITES/STATIC_DASHBOARDS uses lowercase. Match it exactly.
    login_path = "/Login" if "93.190.143.35" in url else "/login"
    login_page_url = f"{url}{login_path}"
    try:
        r = s.get(login_page_url, timeout=25, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    low = r.text.lower()
    if r.status_code in (403, 401) or "not in allowlist" in low or "not allowed" in low:
        raise Exception(f"{bn} · IP blocked (HTTP {r.status_code})")

    capt = _solve_captcha(r.text)

    # Same equation as FLASH-SMS-BOT.py's do_login(): start from every
    # hidden field on the page (covers _token / csrf-token / crlf / any
    # other server-generated field), then layer username/password/capt.
    post_data = _extract_hidden_fields(r.text)
    post_data.update({
        "username": email, "password": pw,
        "capt": capt, "g-recaptcha-response": "",
    })
    crlf_match = re.search(r"name=['\"]crlf['\"].*?value=['\"]([^'\"]+)['\"]", r.text, re.DOTALL)
    if not crlf_match:
        crlf_match = re.search(r"value=['\"]([^'\"]+)['\"].*?name=['\"]crlf['\"]", r.text, re.DOTALL)
    if crlf_match:
        post_data["crlf"] = crlf_match.group(1)

    try:
        r2 = s.post(
            f"{url}/signin",
            data=post_data,
            headers={**_BASE_HEADERS,
                     "Referer": login_page_url,
                     "Content-Type": "application/x-www-form-urlencoded",
                     "Origin": url},
            allow_redirects=True, timeout=20,
        )
    except Exception as e:
        raise Exception(f"{bn} · signin POST failed: {e}")

    login_success = _login_success_equation(r2, login_page_url)

    # Same fallback as the bot: if the equation above is inconclusive,
    # try hitting the report pages directly — some panels set the cookie
    # fine but redirect the signin POST somewhere ambiguous.
    if not login_success:
        for sp in ["/agent/SMSCDRReports", "/client/SMSCDRReports",
                   "/agent/SMSCDRStats", "/client/SMSCDRStats"]:
            try:
                tr = s.get(url + sp, timeout=8)
                if tr.status_code == 200 and "login" not in tr.url.lower() and "signin" not in tr.url.lower():
                    login_success = True
                    r2 = tr
                    break
            except Exception:
                pass

    if not login_success:
        raise Exception(f"{bn} · login failed — redirected back to login (URL: {r2.url})")

    if forced_path in ("agent", "client", "reseller"):
        path = forced_path
    elif "client" in str(r2.url):
        path = "client"
    elif "reseller" in str(r2.url):
        path = "reseller"
    else:
        path = "agent"

    logger.info(f"✅ ints_login {bn} {email} · path:{path}")
    return s, path, url


def ints_fetch(bn, session_info, url=""):
    if (isinstance(session_info, tuple) and len(session_info) == 3
            and hasattr(session_info[0], "cookies")):
        s, path, _url = session_info
        url = _url or url
    else:
        s = _session()
        path = "agent"

    result = _core_fetch(s, url, path)
    if result is None:
        logger.warning(f"ints_fetch {bn} · session expired")
    return result


def hadi_login(email, pw, url=""): return ints_login("HADI_SMS", email, pw, url)
def hadi_fetch(cookie_file, url=""): return ints_fetch("HADI_SMS", cookie_file, url)


def panel_login(bn, email, pw, url):
    s = _session()
    if "/sms" in url:
        lp, sp = "SignIn", "signmein"
    else:
        lp, sp = "login", "signin"

    try:
        r = s.get(f"{url}/{lp}", timeout=25, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    low = r.text.lower()
    if r.status_code in (403, 401) or "not in allowlist" in low:
        raise Exception(f"{bn} · IP blocked (HTTP {r.status_code})")

    capt = _solve_captcha(r.text)
    csrf = ""
    m = re.search(r'name=["\']_token["\'][^>]+value=["\']([^"\']+)["\']', r.text)
    if m:
        csrf = m.group(1)

    post_data = {"username": email, "password": pw,
                 "capt": capt, "g-recaptcha-response": ""}
    if csrf:
        post_data["_token"] = csrf

    r2 = s.post(f"{url}/{sp}", data=post_data,
                headers={**_BASE_HEADERS,
                         "Referer": f"{url}/{lp}",
                         "Content-Type": "application/x-www-form-urlencoded",
                         "Origin": url},
                allow_redirects=True, timeout=20)

    sid = (s.cookies.get("PHPSESSID") or s.cookies.get("session")
           or s.cookies.get("laravel_session"))
    if not sid:
        raise Exception(f"{bn} · no session cookie after login")

    final_url = str(r2.url).lower()
    if f"/{lp.lower()}" in final_url or f"/{sp.lower()}" in final_url:
        raise Exception(f"{bn} · login failed — redirected back to login page")

    rurl = str(r2.url)
    if "reseller" in rurl:
        path = "reseller"
    elif "client" in rurl:
        path = "client"
    else:
        path = "agent"

    logger.info(f"✅ panel_login {bn} {email} · path:{path}")
    return s, path, url


def panel_fetch(session_info, url):
    if (isinstance(session_info, tuple) and len(session_info) == 3
            and hasattr(session_info[0], "cookies")):
        s, path, _url = session_info
        url = _url or url
    else:
        s = _session()
        path = "agent"
    return _core_fetch(s, url, path)


def reseller_fetch(sid, url):
    return panel_fetch(sid, url)


def _ims_make_session():
    import requests as rq
    s = rq.Session()
    adapter = HTTPAdapter(max_retries=Retry(total=3, backoff_factor=2))
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    s.headers.update({
        "User-Agent": _UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "keep-alive",
    })
    return s


def _ims_human_delay(a=2, b=5):
    t = random.uniform(a, b)
    time.sleep(t)


def _ims_get_etkk(html):
    for pat in [
        r"name=['\"]etkk['\"][^>]+value=['\"]([^'\"]+)['\"]",
        r"value=['\"]([^'\"]+)['\"][^>]+name=['\"]etkk['\"]"
    ]:
        m = re.search(pat, html)
        if m:
            return m.group(1)
    return ""


def _ims_try_login(s, url, email, pw, etkk, capt):
    import requests as rq
    try:
        r = s.post(
            f"{url}/signin",
            data={"username": email, "password": pw, "capt": capt, "etkk": etkk},
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": url,
                "Referer": f"{url}/login",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-User": "?1",
                "Cache-Control": "max-age=0",
                "Upgrade-Insecure-Requests": "1",
            },
            allow_redirects=True,
            timeout=30
        )
        return r
    except rq.exceptions.ConnectionError:
        logger.warning("ImsPanel · connection dropped, retrying in 8s...")
        time.sleep(8)
        return None


def ims_login(email, pw, url):
    s = _ims_make_session()
    try:
        s.get(url, timeout=20)
    except Exception:
        pass
    _ims_human_delay(2, 3)

    max_attempts = 5
    for attempt in range(1, max_attempts + 1):
        logger.info(f"ImsPanel · login attempt {attempt}/{max_attempts} — {email}")

        try:
            r = s.get(f"{url}/login", timeout=20, allow_redirects=True)
        except Exception as e:
            raise Exception(f"ImsPanel · server unreachable: {e}")

        etkk = _ims_get_etkk(r.text)
        capt = _solve_captcha(r.text)
        _ims_human_delay(3, 6)

        r2 = _ims_try_login(s, url, email, pw, etkk, capt)
        if r2 is None:
            _ims_human_delay(5, 8)
            continue

        final_url = str(r2.url).lower()
        success = not any(x in final_url for x in ["/login", "/signin"])
        # Same extra signals as _do_ims_login() in FLASH-SMS-BOT.py, in case
        # the panel redirects somewhere that doesn't say /login or /signin
        # but also doesn't obviously look like a logged-in page either.
        if not success:
            success = ("agent/sms" in final_url or "dashboard" in final_url
                       or "logout" in r2.text.lower())
        if success:
            for role in ["reseller", "agent", "admin", "client"]:
                if role in final_url:
                    logger.info(f"✅ ImsPanel · {email} · role: {role}")
                    return s, role, url
            return s, "client", url

        new_etkk = _ims_get_etkk(r2.text)
        new_capt = _solve_captcha(r2.text)
        if new_etkk and new_etkk != etkk:
            _ims_human_delay(2, 4)
            r3 = _ims_try_login(s, url, email, pw, new_etkk, new_capt)
            if r3 and not any(x in str(r3.url).lower() for x in ["/login", "/signin"]):
                for role in ["reseller", "agent", "admin", "client"]:
                    if role in str(r3.url).lower():
                        return s, role, url
                return s, "client", url

        logger.warning(f"ImsPanel · attempt {attempt} failed.")
        _ims_human_delay(5, 10)

    raise Exception(f"ImsPanel · all {max_attempts} login attempts failed for {email}")


def ims_fetch(session_info, url):
    if (isinstance(session_info, tuple) and len(session_info) == 3
            and hasattr(session_info[0], "cookies")):
        s, path, _url = session_info
        url = _url or url
    else:
        s = session_info
        path = "client"

    try:
        _ims_human_delay(2, 3)
        s.get(f"{url}/{path}/SMSDashboard", timeout=15)
        _ims_human_delay(1, 2)
    except Exception:
        pass

    sesskey = ""
    try:
        rs = s.get(f"{url}/{path}/SMSCDRStats", timeout=15, allow_redirects=True)
        if _is_session_expired(rs):
            return None
        m = re.search(r'sesskey=([A-Za-z0-9+/=_-]+)', rs.text)
        if m:
            sesskey = m.group(1)
    except Exception:
        pass

    _ims_human_delay(1, 2)

    today     = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

    params = {
        "fdate1": f"{yesterday} 00:00:00",
        "fdate2": f"{today} 23:59:59",
        "frange": "", "fclient": "", "fnum": "", "fcli": "",
        "fgdate": "", "fgmonth": "", "fgrange": "",
        "fgclient": "", "fgnumber": "", "fgcli": "", "fg": "0"
    }
    if sesskey:
        params["sesskey"] = sesskey

    try:
        r = s.get(
            f"{url}/{path}/res/data_smscdr.php",
            params=params,
            headers={
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": f"{url}/{path}/SMSCDRStats",
            },
            timeout=20, allow_redirects=True
        )
        if _is_session_expired(r):
            return None
        rows = _parse(r.text)
        return rows
    except Exception as e:
        logger.warning(f"ims_fetch · fetch error: {e}")
        return []


def konekta_login(email, pw, url="https://www.konektapremium.net"):
    url = (url or "https://www.konektapremium.net").rstrip("/")
    s = _session()
    try:
        r = s.get(f"{url}/sign-in", timeout=15, allow_redirects=True)
    except Exception as e:
        raise Exception(f"Konekta · server unreachable: {e}")

    capt = _solve_captcha(r.text)
    r2 = s.post(f"{url}/signin",
                data={"username": email, "password": pw, "capt": capt},
                headers={**_BASE_HEADERS,
                         "Referer": f"{url}/sign-in",
                         "Content-Type": "application/x-www-form-urlencoded"},
                allow_redirects=True, timeout=15)

    final = str(r2.url).lower()
    success_signals = ["dashboard", "agent", "client", "reseller", "smscdr", "sms"]
    if not any(x in final for x in success_signals):
        raise Exception(f"Konekta · login failed — unexpected URL: {r2.url}")

    sid = s.cookies.get("PHPSESSID") or s.cookies.get("session")
    if not sid:
        raise Exception("Konekta · no session cookie after login")

    logger.info(f"✅ Konekta · {email}")
    return s, "agent", url


def konekta_fetch(session_info, url="https://www.konektapremium.net"):
    if (isinstance(session_info, tuple) and len(session_info) >= 2
            and hasattr(session_info[0], "cookies")):
        s = session_info[0]
        url = (session_info[2] if len(session_info) > 2 and session_info[2] else url) or "https://www.konektapremium.net"
        path = session_info[1] if len(session_info) > 1 else "agent"
    else:
        s = session_info
        path = "agent"
        url = "https://konektapremium.net"
    return _core_fetch(s, url, path)


def timesms_login(bn, email, pw, url="https://www.timesms.org"):
    s = _session()
    try:
        r = s.get(f"{url}/login", timeout=25, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    low = r.text.lower()
    if r.status_code in (403, 401) or "not in allowlist" in low:
        raise Exception(f"{bn} · IP blocked (HTTP {r.status_code})")

    capt = _solve_captcha(r.text)
    csrf = ""
    for pat in [
        r'name=["\']_token["\'][^>]+value=["\']([^"\']+)["\']',
        r'value=["\']([^"\']+)["\'][^>]+name=["\']_token["\']',
    ]:
        m = re.search(pat, r.text)
        if m:
            csrf = m.group(1)
            break

    post_data = {"username": email, "password": pw, "capt": capt}
    if csrf:
        post_data["_token"] = csrf

    try:
        r2 = s.post(f"{url}/signin", data=post_data,
                    headers={**_BASE_HEADERS,
                             "Referer": f"{url}/login",
                             "Content-Type": "application/x-www-form-urlencoded",
                             "Origin": url},
                    allow_redirects=True, timeout=20)
    except Exception as e:
        raise Exception(f"{bn} · signin POST failed: {e}")

    sid = (s.cookies.get("PHPSESSID") or s.cookies.get("session")
           or s.cookies.get("laravel_session"))
    if not sid:
        raise Exception(f"{bn} · no session cookie after login")

    final_url = str(r2.url).lower()
    if any(x in final_url for x in ["/login", "/signin", "/sign-in"]):
        raise Exception(f"{bn} · login failed — redirected back to login")

    if "client" in str(r2.url):
        path = "client"
    elif "reseller" in str(r2.url):
        path = "reseller"
    else:
        path = "agent"

    logger.info(f"✅ timesms_login {bn} {email} · path:{path}")
    return s, path, url


def timesms_fetch(bn, session_info, url="https://www.timesms.org"):
    if not (isinstance(session_info, tuple) and len(session_info) == 3
            and hasattr(session_info[0], "cookies")):
        return []

    s, path, _url = session_info
    url = _url or url
    d1, d2 = _dates()

    sesskey = ""
    for ep in [
        f"{url}/{path}/SMSCDRReports",
        f"{url}/{path}/SMSCDRStats",
    ]:
        try:
            rs = s.get(ep, timeout=15, allow_redirects=True,
                       headers={**_BASE_HEADERS, "Referer": f"{url}/{path}/SMSDashboard"})
            if _is_session_expired(rs):
                return None
            m = re.search(r'sesskey=([A-Za-z0-9+/=_-]+)', rs.text)
            if m:
                sesskey = m.group(1)
                break
        except Exception as e:
            err = str(e)
            if any(x in err for x in ["NewConnection", "ConnectionError", "Max retries"]):
                return []
            continue

    params = {
        "fdate1": d1, "fdate2": d2,
        "frange": "", "fclient": "", "fnum": "", "fcli": "",
        "fgdate": "", "fgmonth": "", "fgrange": "",
        "fgclient": "", "fgnumber": "", "fgcli": "",
        "fg": "0",
    }
    if sesskey:
        params["sesskey"] = sesskey

    try:
        r = s.get(f"{url}/{path}/res/data_smscdr.php", params=params,
                  headers={**_AJAX_HEADERS, "Referer": f"{url}/{path}/SMSCDRReports"},
                  timeout=20, allow_redirects=True)
        if _is_session_expired(r):
            return None
        if _classify(r) == "json":
            rows = _parse(r.text)
            return rows if rows is not None else []
    except Exception as e:
        err = str(e)
        if any(x in err for x in ["NewConnection", "ConnectionError", "Max retries"]):
            return []

    return []


# ─────────────────────────────────────────────────────────────
# Basha IPRN VAS (basha.cc) — Laravel-based panel, different shape than
# the "ints" family: login fields are email/password (not username),
# CSRF via Laravel's csrf-token meta + XSRF-TOKEN cookie, no captcha.
# Received SMS live at /my/messages in a DataTable with columns:
# Range Name | Destination Number | Source Number | Message Text.
# ─────────────────────────────────────────────────────────────
def basha_login(bn, email, pw, url="https://basha.cc"):
    url = (url or "https://basha.cc").rstrip("/")
    s = _session()
    try:
        r = s.get(f"{url}/login", timeout=25, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    if r.status_code in (403, 401):
        raise Exception(f"{bn} · IP blocked (HTTP {r.status_code})")

    csrf = ""
    m = re.search(r'name=["\']csrf-token["\'][^>]+content=["\']([^"\']+)["\']', r.text)
    if m:
        csrf = m.group(1)
    else:
        m = re.search(r'name=["\']_token["\'][^>]+value=["\']([^"\']+)["\']', r.text)
        if m:
            csrf = m.group(1)

    xsrf_cookie = s.cookies.get("XSRF-TOKEN")

    post_data = {"email": email, "password": pw, "remember": "on"}
    if csrf:
        post_data["_token"] = csrf

    headers = {**_BASE_HEADERS,
               "Referer": f"{url}/login",
               "Content-Type": "application/x-www-form-urlencoded",
               "Origin": url}
    if xsrf_cookie:
        try:
            from urllib.parse import unquote as _unquote
            headers["X-XSRF-TOKEN"] = _unquote(xsrf_cookie)
        except Exception:
            pass

    try:
        r2 = s.post(f"{url}/login", data=post_data, headers=headers,
                    allow_redirects=True, timeout=20)
    except Exception as e:
        raise Exception(f"{bn} · login POST failed: {e}")

    final_url = str(r2.url).lower()
    if "/login" in final_url:
        low = r2.text.lower()
        if "these credentials do not match" in low or "invalid" in low or "incorrect" in low:
            raise Exception(f"{bn} · login failed — invalid email/password")
        raise Exception(f"{bn} · login failed — redirected back to login page")

    # Laravel names its session cookie after APP_NAME (e.g.
    # "basha_iprn_vas_session"), not literally "laravel_session" — so
    # match ANY cookie ending in "_session", falling back to the common
    # fixed names, and only failing if there's truly no cookie at all
    # (the page redirect check above is already the real success signal).
    sid = None
    for name in s.cookies.keys():
        if name.lower().endswith("_session") or name.lower() in ("laravel_session", "session", "phpsessid"):
            sid = s.cookies.get(name)
            break
    if not sid and not s.cookies:
        raise Exception(f"{bn} · no session cookie after login")

    logger.info(f"✅ basha_login {bn} {email}")
    return s, "home", url


def _basha_find_ajax_url(html_text, base_url):
    """If /my/messages loads its rows via a DataTables ajax config instead
    of rendering them straight into <tbody>, pull that endpoint out."""
    m = re.search(r'ajax\s*:\s*[\'"]([^\'"]+)[\'"]', html_text)
    if not m:
        m = re.search(r'ajax\s*:\s*\{\s*url\s*:\s*[\'"]([^\'"]+)[\'"]', html_text)
    if not m:
        return None
    u = m.group(1)
    if u.startswith("http"):
        return u
    return base_url.rstrip("/") + "/" + u.lstrip("/")


def _basha_parse_table(html_text):
    """Parse the rendered Received SMS table on /my/messages. Matches
    columns by header text so it keeps working even if column order changes.

    Returns (rows, debug) where debug is a dict describing what was found —
    used by basha_fetch to tell "genuinely no messages" apart from "parsing
    is broken" instead of collapsing both into a silent rows:0."""
    debug = {"table_found": False, "headers": [], "tr_count": 0}
    try:
        from bs4 import BeautifulSoup
    except Exception:
        logger.warning("basha_fetch: BeautifulSoup not available, cannot parse table")
        debug["error"] = "beautifulsoup4 not installed"
        return None, debug

    soup = BeautifulSoup(html_text, "html.parser")
    table = None
    for t in soup.find_all("table"):
        thead = t.find("thead")
        head_txt = thead.get_text(" ", strip=True).lower() if thead else ""
        if "destination" in head_txt and "message" in head_txt:
            table = t
            break
    if table is None:
        return None, debug

    debug["table_found"] = True
    headers = []
    thead = table.find("thead")
    if thead:
        headers = [th.get_text(" ", strip=True).lower() for th in thead.find_all("th")]
    debug["headers"] = headers

    def _idx(*keywords):
        for i, h in enumerate(headers):
            if any(k in h for k in keywords):
                return i
        return None

    i_range = _idx("range")
    i_dest  = _idx("destination")
    i_src   = _idx("source")
    i_msg   = _idx("message")

    tbody = table.find("tbody") or table
    trs = tbody.find_all("tr")
    debug["tr_count"] = len(trs)

    out = []
    for tr in trs:
        cells = [td.get_text(" ", strip=True) for td in tr.find_all("td")]
        if not cells:
            continue
        number     = cells[i_dest]  if i_dest  is not None and i_dest  < len(cells) else ""
        sender     = cells[i_src]   if i_src   is not None and i_src   < len(cells) else ""
        message    = cells[i_msg]   if i_msg   is not None and i_msg   < len(cells) else ""
        range_name = cells[i_range] if i_range is not None and i_range < len(cells) else ""
        number = re.sub(r"\D", "", number)
        if not number or not message:
            continue
        out.append({
            "number": number,
            "cli": sender or range_name,
            "sms": _html.unescape(message),
        })
    return out, debug


def _basha_parse_json(text):
    """Parse the Yajra/DataTables JSON response for /my/messages. Rows can
    come back either as objects with named keys, or as plain arrays in the
    same left-to-right order as the visible columns:
    Range Name, Destination Number, Source Number, Message Text, ..."""
    try:
        js = json.loads(text)
    except Exception:
        return []
    rows = js.get("data") if isinstance(js, dict) else (js if isinstance(js, list) else [])
    out = []
    for row in rows or []:
        if isinstance(row, dict):
            number = re.sub(r"\D", "", str(
                row.get("destination_number") or row.get("destination") or
                row.get("number") or row.get("msisdn") or ""))
            sender = str(row.get("source_number") or row.get("source") or
                         row.get("sender") or row.get("cli") or "")
            message = str(row.get("message_text") or row.get("message") or
                          row.get("text") or row.get("sms") or "")
        elif isinstance(row, list) and len(row) >= 4:
            # Range Name, Destination Number, Source Number, Message Text, ...
            number = re.sub(r"\D", "", str(row[1]))
            sender = str(row[2])
            message = str(row[3])
        else:
            continue
        if not number or not message:
            continue
        out.append({"number": number, "cli": sender, "sms": _html.unescape(message)})
    return out


def basha_fetch(session_info, url="https://basha.cc"):
    if not (isinstance(session_info, tuple) and len(session_info) == 3
            and hasattr(session_info[0], "cookies")):
        return []
    s, _path, _url = session_info
    url = (_url or url or "https://basha.cc").rstrip("/")
    page_url = f"{url}/my/messages"

    try:
        r = s.get(page_url, timeout=20, allow_redirects=True,
                  headers={**_BASE_HEADERS, "Referer": f"{url}/home"})
    except Exception as e:
        err = str(e)
        if any(x in err for x in ["NewConnection", "ConnectionError", "Failed to establish", "Max retries"]):
            return []
        raise

    if str(r.url).lower().rstrip("/").endswith("/login"):
        return None  # session expired — caller will re-login

    rows, debug = _basha_parse_table(r.text)

    if not rows:
        found = _basha_resolve_messages(s, r.text, url, page_url)
        if found is not None:
            return found

        raise Exception(
            "Basha · logged in fine, but none of the known ways to read "
            "/my/messages (raw table, JS-bundle ajax URL, common Yajra "
            "endpoints, or the CSV export endpoint) returned any data. "
            "Set BASHA_DEBUG=1 in the environment to get the full dump again."
        )

    return rows or []


def _basha_resolve_messages(s, page_html, base_url, page_url):
    """Try every known way to actually get the Received-SMS rows for this
    account, in order of how likely each is to be the real mechanism:

    1. Scan the live JS bundle for a literal ajax path near the table id
       (works even if the path changes in a future deploy).
    2. Common Yajra/DataTables JSON endpoint name patterns.
    3. The CSV export button visible on the page — same data, different
       shape, and its date-range fields are visible in the raw HTML even
       though the button itself is wired up in JS.

    Returns a list of {"number","cli","sms"} dicts on success (empty list
    counts as a *confirmed* "no messages"), or None if nothing worked.
    """
    dt_params = {
        "draw": "1", "start": "0", "length": "100",
        "search[value]": "", "search[regex]": "false",
    }

    # 1. Scan the bundle for the real endpoint.
    bundle_srcs = re.findall(r'<script[^>]+src="([^"]+/build/assets/[^"]+\.js)"', page_html)
    for src in bundle_srcs[:3]:
        try:
            rb = s.get(src, timeout=15, headers={**_BASE_HEADERS, "Referer": page_url})
        except Exception:
            continue
        body = rb.text
        # Look for a path literal near any mention of the table/route.
        for m in re.finditer(r'["\'](/[a-zA-Z0-9_\-/]*messages?[a-zA-Z0-9_\-/]*)["\']', body):
            cand = m.group(1)
            if cand.rstrip("/") == "/my/messages":
                continue
            cand_url = cand if cand.startswith("http") else base_url.rstrip("/") + "/" + cand.lstrip("/")
            try:
                rj = s.get(cand_url, params=dt_params,
                           headers={**_AJAX_HEADERS, "Referer": page_url}, timeout=15)
            except Exception:
                continue
            if _classify(rj) == "json":
                out = _basha_parse_json(rj.text)
                if out:
                    return out

    # 2. Common Yajra/DataTables endpoint naming conventions.
    for suffix in ("/data", "-data", "/ajax", "/list", "/table", "/datatable", "/get"):
        cand_url = page_url + suffix
        try:
            rj = s.get(cand_url, params=dt_params,
                       headers={**_AJAX_HEADERS, "Referer": page_url}, timeout=15)
        except Exception:
            continue
        if _classify(rj) == "json":
            out = _basha_parse_json(rj.text)
            if out:
                return out

    # 3. The CSV export button on the same page — field names lifted
    # straight from the raw HTML (dl-from-date / dl-to-date / etc.), a
    # 31-day window ending today (the page's own stated max).
    today = datetime.utcnow().date()
    date_from = (today - timedelta(days=30)).isoformat()
    date_to = today.isoformat()
    csv_param_sets = [
        {"from": date_from, "to": date_to},
        {"date_from": date_from, "date_to": date_to},
        {"start_date": date_from, "end_date": date_to},
        {"from_date": date_from, "to_date": date_to},
    ]
    for suffix in ("/download", "/export", "/csv", "/export-csv", "/download-csv"):
        cand_url = page_url + suffix
        for params in csv_param_sets:
            try:
                rc = s.get(cand_url, params=params,
                           headers={**_BASE_HEADERS, "Referer": page_url}, timeout=15)
            except Exception:
                continue
            ctype = rc.headers.get("Content-Type", "").lower()
            text = rc.text.strip()
            if rc.status_code == 200 and text and ("," in text.splitlines()[0] if text.splitlines() else False) \
                    and ("csv" in ctype or "destination" in text.lower()[:400] or "range" in text.lower()[:400]):
                out = _basha_parse_csv(text)
                if out:
                    return out
            break  # first param-name shape that gave a 200 is enough per suffix

    return None


def _basha_parse_csv(text):
    """Parse the Download-Messages CSV export — same columns as the on-page
    table (Range Name, Destination Number, Source Number, Message Text, ...)."""
    import csv as _csv
    import io as _io
    out = []
    try:
        reader = _csv.reader(_io.StringIO(text))
        header = next(reader, None)
        if not header:
            return out
        head_low = [h.strip().lower() for h in header]
        def _idx(*keywords):
            for i, h in enumerate(head_low):
                if any(k in h for k in keywords):
                    return i
            return None
        i_dest = _idx("destination")
        i_src  = _idx("source")
        i_msg  = _idx("message")
        for row in reader:
            if not row:
                continue
            number  = re.sub(r"\D", "", row[i_dest]) if i_dest is not None and i_dest < len(row) else ""
            sender  = row[i_src] if i_src is not None and i_src < len(row) else ""
            message = row[i_msg] if i_msg is not None and i_msg < len(row) else ""
            if not number or not message:
                continue
            out.append({"number": number, "cli": sender, "sms": _html.unescape(message)})
    except Exception:
        return out
    return out


def _basha_try_ajax(s, ajax_url, referer, attempts=None):
    """POST then GET the Yajra-style DataTables ajax request for
    /my/messages. Returns a list (possibly empty) on a valid JSON reply,
    or None if the endpoint didn't answer with usable JSON at all.
    Appends {"method","url","status","ctype","snippet"} to `attempts`
    for every try, so callers can see exactly what came back."""
    dt_params = {
        "draw": "1", "start": "0", "length": "100",
        "search[value]": "", "search[regex]": "false",
        "order[0][column]": "7", "order[0][dir]": "desc",
    }
    for method in ("get", "post"):
        try:
            fn = getattr(s, method)
            kwargs = dict(headers={**_AJAX_HEADERS, "Referer": referer}, timeout=20)
            if method == "get":
                kwargs["params"] = dt_params
            else:
                kwargs["data"] = dt_params
            rj = fn(ajax_url, **kwargs)
        except Exception as e:
            if attempts is not None:
                attempts.append({"method": method, "url": ajax_url, "error": str(e)})
            continue
        if attempts is not None:
            attempts.append({
                "method": method, "url": ajax_url, "status": rj.status_code,
                "ctype": rj.headers.get("Content-Type", ""),
                "snippet": rj.text[:150],
            })
        if _classify(rj) == "json":
            rows = _basha_parse_json(rj.text)
            return rows  # even [] here is a *confirmed* "no messages"
    return None


def _roxysms_login(bn, email, pw, url=""):
    s = _session()
    try:
        r = s.get(f"{url}/Login", timeout=20, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    if r.status_code in (403, 401):
        raise Exception(f"{bn} · IP blocked (HTTP {r.status_code})")

    capt = _solve_captcha(r.text)
    r2 = s.post(f"{url}/signin",
                data={"username": email, "password": pw,
                      "capt": capt, "g-recaptcha-response": ""},
                headers={**_BASE_HEADERS,
                         "Referer": f"{url}/Login",
                         "Content-Type": "application/x-www-form-urlencoded"},
                allow_redirects=True, timeout=20)
    if not (s.cookies.get("PHPSESSID") or s.cookies.get("session")
            or s.cookies.get("laravel_session")):
        raise Exception(f"{bn} · no session cookie after login")
    _roxy_final = str(r2.url).lower()
    if any(x in _roxy_final for x in ["/login", "/signin", "/sign-in"]):
        raise Exception(f"{bn} · login failed — redirected back to login")
    path = "agent" if "agent" in str(r2.url) else "client"
    logger.info(f"✅ {bn} {email} · path:{path}")
    return s, path, url


def _roxysms_fetch(bn, session_info, url=""):
    if not isinstance(session_info, tuple):
        return []
    s, path, url = session_info
    d1, d2 = _dates()

    for p in [path, "agent", "client"]:
        sesskey = ""
        try:
            rs = s.get(f"{url}/{p}/SMSCDRReports", timeout=15, allow_redirects=True)
            if _is_session_expired(rs):
                return None
            m = re.search(r'sesskey=([A-Za-z0-9+/=]+)', rs.text)
            if m:
                sesskey = m.group(1)
        except Exception as e:
            err = str(e)
            if any(x in err for x in ["NewConnection", "ConnectionError", "Max retries"]):
                return []

        params = {"fdate1": d1, "fdate2": d2, "frange": "", "fclient": "",
                  "fnum": "", "fcli": "", "fgdate": "", "fgmonth": "",
                  "fgrange": "", "fgclient": "", "fgnumber": "", "fgcli": "", "fg": "0"}
        if sesskey:
            params["sesskey"] = sesskey

        try:
            r = s.get(f"{url}/{p}/res/data_smscdr.php", params=params,
                      headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/SMSCDRReports"},
                      timeout=20)
            if _is_session_expired(r):
                return None
            rows = _parse(r.text, mask_only=True)
            if rows:
                return rows
        except Exception as e:
            err = str(e)
            if any(x in err for x in ["NewConnection", "ConnectionError", "Max retries"]):
                return []

        try:
            r = s.get(f"{url}/{p}/res/data_testsmscdr.php",
                      params={"fdate1": d1, "fdate2": d2, "fg": "0"},
                      headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/SMSTestPanel"},
                      timeout=15)
            if _is_session_expired(r):
                return None
            rows = _parse(r.text, mask_only=True)
            if rows:
                return rows
        except Exception as e:
            err = str(e)
            if any(x in err for x in ["NewConnection", "ConnectionError", "Max retries"]):
                return []

    return []


def _voicegate_login(bn, email, pw, url=""):
    s = _session()
    try:
        r = s.get(f"{url}/SignIn", timeout=20, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    if r.status_code in (403, 401):
        raise Exception(f"{bn} · IP blocked (HTTP {r.status_code})")

    capt = _solve_captcha(r.text)
    _vg_data = {"username": email, "password": pw}
    if capt and capt != "0":
        _vg_data["capt"] = capt
    r2 = s.post(f"{url}/signmein",
                data=_vg_data,
                headers={**_BASE_HEADERS,
                         "Referer": f"{url}/SignIn",
                         "Content-Type": "application/x-www-form-urlencoded"},
                allow_redirects=True, timeout=20)
    if not (s.cookies.get("PHPSESSID") or s.cookies.get("session")
            or s.cookies.get("laravel_session")):
        raise Exception(f"{bn} · no session cookie after login")
    _vg_final = str(r2.url).lower()
    if any(x in _vg_final for x in ["/login", "/signin", "/sign-in"]):
        raise Exception(f"{bn} · login failed — redirected back to login")
    final = str(r2.url)
    path = "reseller" if "reseller" in final else ("agent" if "agent" in final else "client")
    logger.info(f"✅ {bn} {email} · path:{path}")
    return s, path, url


def _voicegate_fetch(bn, session_info, url=""):
    if not isinstance(session_info, tuple):
        return []
    s, path, url = session_info
    d1, d2 = _dates()
    params = {"fdate1": d1, "fdate2": d2, "ftermination": "", "fclient": "",
              "fnum": "", "fcli": "", "fgdate": "0", "fgtermination": "0",
              "fgclient": "0", "fgnumber": "0", "fgcli": "0", "fg": "0"}
    for p in [path, "reseller", "agent", "client"]:
        try:
            r = s.get(f"{url}/{p}/ajax/dt_reports.php", params=params,
                      headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/Reports"},
                      timeout=15)
            if _is_session_expired(r):
                return None
            rows = _parse(r.text)
            if rows:
                return rows
        except Exception:
            continue
    return []


def _numberpanel_login(bn, email, pw, url=""):
    s = _session()
    try:
        r = s.get(f"{url}/login", timeout=15, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    mc = re.search(r'What is (\d+)\s*\+\s*(\d+)', r.text, re.I)
    capt = int(mc.group(1)) + int(mc.group(2)) if mc else 0

    r2 = s.post(f"{url}/signin",
                data={"username": email, "password": pw, "capt": capt},
                headers={**_BASE_HEADERS,
                         "Referer": f"{url}/login",
                         "Content-Type": "application/x-www-form-urlencoded"},
                allow_redirects=True, timeout=15)

    if not s.cookies.get("PHPSESSID"):
        raise Exception(f"{bn} · login failed — no PHPSESSID")

    path = "agent" if "agent" in str(r2.url) else "client"
    logger.info(f"✅ {bn} {email} · path:{path}")
    return s, path, url


def _numberpanel_fetch(bn, session_info, url=""):
    if not isinstance(session_info, tuple):
        return []
    s, path, url = session_info
    d1, d2 = _dates()

    sesskey = ""
    try:
        rs = s.get(f"{url}/{path}/SMSCDRStats",
                   headers={**_BASE_HEADERS, "Referer": f"{url}/{path}/SMSDashboard"},
                   timeout=15, allow_redirects=True)
        if _is_session_expired(rs):
            return None
        sk = re.search(r'sesskey=([A-Za-z0-9+/=]+)', rs.text)
        if sk:
            sesskey = sk.group(1)
    except Exception:
        pass

    params = {"fdate1": d1, "fdate2": d2, "fg": "0"}
    if sesskey:
        params["sesskey"] = sesskey

    try:
        r = s.get(f"{url}/{path}/res/data_smscdr.php",
                  params=params,
                  headers={**_AJAX_HEADERS, "Referer": f"{url}/{path}/SMSCDRStats"},
                  timeout=15, allow_redirects=True)
        if _is_session_expired(r):
            return None
        return _parse(r.text)
    except Exception:
        return []


def proofsms_fetch(session_info, url=""):
    if not isinstance(session_info, tuple):
        return []
    s, path, _url = session_info
    url = _url or url
    d1, d2 = _dates()

    for p in ["agent", "client"]:
        sesskey = ""
        try:
            rs = s.get(f"{url}/{p}/SMSCDRStats", timeout=15, allow_redirects=True)
            if _is_session_expired(rs):
                return None
            m = re.search(r'sesskey=([A-Za-z0-9+/=_-]+)', rs.text)
            if m:
                sesskey = m.group(1)
        except Exception:
            pass

        if sesskey:
            try:
                params = {"fdate1": d1, "fdate2": d2, "fg": "0", "sesskey": sesskey}
                r = s.get(f"{url}/{p}/res/data_smscdr.php", params=params,
                          headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/SMSCDRStats"},
                          timeout=20, allow_redirects=True)
                if _is_session_expired(r):
                    return None
                rows = _parse(r.text)
                if rows:
                    return rows
            except Exception:
                pass

        try:
            r = s.get(f"{url}/{p}/res/data_testsmscdr.php",
                      params={"fdate1": d1, "fdate2": d2, "fg": "0"},
                      headers={**_AJAX_HEADERS, "Referer": f"{url}/{p}/SMSTestPanel"},
                      timeout=15, allow_redirects=True)
            if _is_session_expired(r):
                return None
            rows = _parse(r.text)
            if rows:
                return rows
        except Exception:
            pass

    return []


_proofsms_fetch = proofsms_fetch


def _sniper_login(bn, email, pw, url=""):
    s = _session()
    try:
        r = s.get(f"{url}/login", timeout=15, allow_redirects=True)
    except Exception as e:
        raise Exception(f"{bn} · server unreachable: {e}")

    if r.status_code in (403, 401):
        raise Exception(f"{bn} · IP blocked (HTTP {r.status_code})")

    capt = _solve_captcha(r.text)
    csrf = ""
    for pat in [
        r'name=["\']_token["\'][^>]+value=["\']([^"\']+)["\']',
        r'value=["\']([^"\']+)["\'][^>]+name=["\']_token["\']',
    ]:
        m = re.search(pat, r.text)
        if m:
            csrf = m.group(1)
            break

    post_data = {"username": email, "password": pw, "capt": capt}
    if csrf:
        post_data["_token"] = csrf

    r2 = s.post(f"{url}/signin",
                data=post_data,
                headers={**_BASE_HEADERS,
                         "Referer": f"{url}/login",
                         "Content-Type": "application/x-www-form-urlencoded"},
                allow_redirects=True, timeout=15)

    if not s.cookies.get("PHPSESSID"):
        raise Exception(f"{bn} · no PHPSESSID cookie")

    final_url = str(r2.url).lower()
    if any(x in final_url for x in ["/login", "/signin", "/sign-in"]):
        raise Exception(f"{bn} · login failed — redirected back to login")

    path = "agent"
    logger.info(f"✅ {bn} {email} · path:{path}")
    return s, path, url


def _sniper_fetch(bn, session_info, url=""):
    if not isinstance(session_info, tuple):
        return []
    s, path, url = session_info
    d1, d2 = _dates()

    for ep in [
        f"{url}/{path}/res/data_smscdr.php",
        f"{url}/{path}/res/data_smscdrreports.php",
    ]:
        sesskey = ""
        try:
            rs = s.get(f"{url}/{path}/SMSCDRReports",
                       headers={**_BASE_HEADERS, "Referer": f"{url}/{path}/SMSDashboard"},
                       timeout=15, allow_redirects=True)
            if _is_session_expired(rs):
                return None
            m = re.search(r'sesskey=([A-Za-z0-9+/=_-]+)', rs.text)
            if m:
                sesskey = m.group(1)
        except Exception:
            pass

        params = {
            "fdate1": d1, "fdate2": d2,
            "frange": "", "fclient": "", "fnum": "", "fcli": "",
            "fgdate": "", "fgmonth": "", "fgrange": "",
            "fgclient": "", "fgnumber": "", "fgcli": "",
            "fg": "0",
        }
        if sesskey:
            params["sesskey"] = sesskey

        try:
            r = s.get(ep, params=params,
                      headers={**_AJAX_HEADERS, "Referer": f"{url}/{path}/SMSCDRReports"},
                      timeout=15, allow_redirects=True)
            if _is_session_expired(r):
                return None
            if _classify(r) == "json":
                rows = _parse(r.text)
                if rows:
                    return rows
        except Exception as e:
            err = str(e)
            if any(x in err for x in ["NewConnection", "ConnectionError", "Max retries"]):
                return []

    return []


def new_panel_login(bn, email, pw, url="", ptype=None):
    if ptype == "roxy" or bn == "RoxySMS":
        return _roxysms_login(bn, email, pw, url)
    elif ptype == "voicegate" or bn == "VoiceGate":
        return _voicegate_login(bn, email, pw, url)
    elif ptype == "numberpanel" or bn == "NumberPanel":
        return _numberpanel_login(bn, email, pw, url)
    elif bn == "SniperPanel":
        return _sniper_login(bn, email, pw, url)
    else:
        return ints_login(bn, email, pw, url)


def new_panel_fetch(bn, session_info, url="", ptype=None):
    if ptype == "roxy" or bn == "RoxySMS":
        return _roxysms_fetch(bn, session_info, url)
    elif ptype == "voicegate" or bn == "VoiceGate":
        return _voicegate_fetch(bn, session_info, url)
    elif ptype == "numberpanel" or bn == "NumberPanel":
        return _numberpanel_fetch(bn, session_info, url)
    elif bn == "SniperPanel":
        return _sniper_fetch(bn, session_info, url)
    elif ptype == "proofsms" or bn == "ProofSMS":
        return proofsms_fetch(session_info, url)
    else:
        return ints_fetch(bn, session_info, url)