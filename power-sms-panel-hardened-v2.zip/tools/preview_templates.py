"""
Render panel templates without running the whole app, then take screenshots.

The stub context stands in for what Flask would inject (url_for, request,
session, current_user, panel_settings, ...), so layout and styling can be
reviewed quickly. Database-driven content is not real, so this checks
design and rendering, not data.

Usage:
    python3 tools/preview_templates.py auth/login.html admin/http_connection.html
    python3 tools/preview_templates.py --no-shots auth/login.html   # HTML only

Screenshots need Playwright with Chromium installed
(python -m playwright install chromium). Without it, HTML is still written.
"""

import argparse
import json
import os
import sys

import jinja2

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = os.path.join(HERE, '..', 'app', 'templates')
OUT = os.path.join(HERE, '..', 'preview')


class Anything:
    """Permissive stand-in for objects the templates read attributes from."""

    def __init__(self, **values):
        self.__dict__.update(values)

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(name)
        return Anything()

    def __call__(self, *args, **kwargs):
        return Anything()

    def __iter__(self):
        return iter(())

    def __bool__(self):
        return False

    def __str__(self):
        return ''

    def __int__(self):
        return 0

    def __float__(self):
        return 0.0


def _tojson(value):
    return jinja2.Markup(json.dumps(value)) if hasattr(jinja2, 'Markup') else json.dumps(value)


def build_env():
    env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(TEMPLATES),
        autoescape=jinja2.select_autoescape(['html', 'xml']),
        undefined=jinja2.Undefined,
    )
    # Stub objects and undefined values serialise as null, as a missing value would.
    env.filters['tojson'] = lambda v: __import__('markupsafe').Markup(
        json.dumps(v, default=lambda o: None))
    env.globals.update(
        url_for=lambda endpoint, **kw: '/' + endpoint.replace('.', '/') + (
            ('?' + '&'.join(f'{k}={v}' for k, v in kw.items())) if kw else ''),
        get_flashed_messages=lambda with_categories=False: [],
        csrf_token=lambda: 'preview-token',
        logo_url=lambda filename: '/static/img/flash-logo.png',
        turnstile_site_key='',
        server_now=None,
        panel_settings=None,
        request=Anything(
            url_root='http://localhost:5000', path='/', endpoint='preview',
            args={}, form={}, method='GET', is_secure=False, headers={},
            host='localhost:5000',
        ),
        session={'captcha_num1': 3, 'captcha_num2': 4, 'captcha_answer': 7},
        current_user=Anything(is_authenticated=True, username='admin', is_admin=lambda: True,
                              is_agent=lambda: False, is_client=lambda: False,
                              is_developer=lambda: True, is_test_account=lambda: False),
    )
    return env


# Demo data for templates that need route-supplied objects. Values are
# placeholders; nothing here is read from a database.
PREVIEW_CONTEXT = {
    'admin/http_connection.html': {
        'endpoint': Anything(
            id=1, name='HTTP Incoming Gateway', slug='incoming-9f2c41aa7d0b3e55',
            method='ANY', ip_whitelist='all', api_token='demo-key-preview-only-0000000000000000',
            is_active=True, total_requests=1280, total_success=1204, total_failed=76,
        ),
    },
}


def render(template_name, env):
    template = env.get_template(template_name)
    return template.render(**PREVIEW_CONTEXT.get(template_name, {}))


def screenshot(html_path, png_path, width, height):
    """Render the saved HTML in Chromium. /static/... is served from the real
    app/static folder, and external requests (Google Fonts) are blocked so the
    page does not wait for the network."""
    import mimetypes
    from playwright.sync_api import sync_playwright

    static_root = os.path.abspath(os.path.join(HERE, '..', 'app', 'static'))
    html_bytes = open(html_path, 'rb').read()

    def handle(route):
        url = route.request.url
        if url.startswith('http://preview.local/static/'):
            rel = url[len('http://preview.local/static/'):].split('?')[0]
            path = os.path.normpath(os.path.join(static_root, rel))
            if path.startswith(static_root) and os.path.isfile(path):
                ctype = mimetypes.guess_type(path)[0] or 'application/octet-stream'
                return route.fulfill(path=path, content_type=ctype)
            return route.abort()
        if url == 'http://preview.local/page':
            return route.fulfill(body=html_bytes, content_type='text/html')
        return route.abort()  # no external network

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={'width': width, 'height': height})
        page.route('**/*', handle)
        page.goto('http://preview.local/page', wait_until='load')
        page.wait_for_timeout(1800)  # let entrance animations finish
        page.screenshot(path=png_path, full_page=True)
        browser.close()


def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('templates', nargs='+')
    parser.add_argument('--no-shots', action='store_true')
    args = parser.parse_args(argv)

    os.makedirs(OUT, exist_ok=True)
    env = build_env()
    shots_possible = not args.no_shots
    for name in args.templates:
        base = name.replace('/', '_').replace('.html', '')
        html_path = os.path.join(OUT, base + '.html')
        with open(html_path, 'w', encoding='utf-8') as fh:
            fh.write(render(name, env))
        print(f'rendered {name} -> {html_path}')
        if not shots_possible:
            continue
        for label, (w, h) in {'desktop': (1366, 800), 'phone': (390, 844)}.items():
            png = os.path.join(OUT, f'{base}.{label}.png')
            try:
                screenshot(html_path, png, w, h)
                print(f'  screenshot {label} -> {png}')
            except Exception as e:  # Playwright or Chromium not installed
                print(f'  screenshot skipped ({label}): {str(e).splitlines()[0]}')
                shots_possible = False
                break
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
