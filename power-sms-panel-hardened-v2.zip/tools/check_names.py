"""
Static checks for the panel code base (no third-party tools needed).

1. Undefined names: a global name that is read somewhere but is neither
   defined at module level, imported, nor a builtin. These are the bugs that
   only show up as a NameError when that particular request path runs.
2. Bad local imports: `from app.x import a, b` where `a` or `b` does not exist
   in app/x.py (or the package). Catches typos and removed helpers.

Usage:  python3 tools/check_names.py [project_root]
Exit status is 1 when problems are found.
"""

import ast
import builtins
import os
import sys
import symtable


def module_level_names(path):
    """Names bound at module level: defs, classes, assignments, imports."""
    with open(path, encoding='utf-8') as fh:
        tree = ast.parse(fh.read(), filename=path)
    names = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                names.add((alias.asname or alias.name).split('.')[0])
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                for sub in ast.walk(target):
                    if isinstance(sub, ast.Name):
                        names.add(sub.id)
        elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
            if isinstance(node.target, ast.Name):
                names.add(node.target.id)
        elif isinstance(node, (ast.If, ast.Try, ast.With, ast.For, ast.While)):
            # names bound inside conditional/try blocks at module level
            for sub in ast.walk(node):
                if isinstance(sub, (ast.FunctionDef, ast.ClassDef)):
                    names.add(sub.name)
                elif isinstance(sub, ast.Name) and isinstance(sub.ctx, ast.Store):
                    names.add(sub.id)
                elif isinstance(sub, (ast.Import, ast.ImportFrom)):
                    for alias in sub.names:
                        names.add((alias.asname or alias.name).split('.')[0])
    return names


def check_undefined(path, problems):
    with open(path, encoding='utf-8') as fh:
        source = fh.read()
    try:
        top = symtable.symtable(source, path, 'exec')
    except SyntaxError as e:
        problems.append(f'{path}:{e.lineno}: syntax error: {e.msg}')
        return
    defined = module_level_names(path) | set(dir(builtins)) | {'__file__', '__name__', '__doc__'}

    def walk(table):
        for sym in table.get_symbols():
            if table.get_type() != 'module' and sym.is_referenced() and sym.is_global() \
                    and not sym.is_assigned() and not sym.is_imported():
                if sym.get_name() not in defined:
                    problems.append(f'{path}: name {sym.get_name()!r} is used in '
                                    f'{table.get_name()!r} but never defined')
        for child in table.get_children():
            walk(child)

    walk(top)


def check_local_imports(root, path, problems):
    with open(path, encoding='utf-8') as fh:
        tree = ast.parse(fh.read(), filename=path)
    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom) or not node.module or node.level:
            continue
        if not node.module.startswith('app') and not node.module.startswith('config'):
            continue
        parts = node.module.split('.')
        target = os.path.join(root, *parts) + '.py'
        if not os.path.exists(target):
            target = os.path.join(root, *parts, '__init__.py')
        if not os.path.exists(target):
            problems.append(f'{path}:{node.lineno}: module {node.module!r} not found')
            continue
        available = module_level_names(target)
        for alias in node.names:
            if alias.name == '*':
                continue
            if alias.name not in available and not os.path.exists(
                    os.path.join(root, *parts, alias.name + '.py')):
                problems.append(f'{path}:{node.lineno}: {alias.name!r} is not defined in {node.module}')


def main(root):
    problems = []
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ('__pycache__', 'venv', '.git')]
        for name in filenames:
            if name.endswith('.py'):
                files.append(os.path.join(dirpath, name))
    for path in sorted(files):
        check_undefined(path, problems)
        check_local_imports(root, path, problems)
    for line in problems:
        print(line)
    print(f'checked {len(files)} python files: {len(problems)} problem(s)')
    return 1 if problems else 0


if __name__ == '__main__':
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..')
    sys.exit(main(os.path.abspath(root)))
