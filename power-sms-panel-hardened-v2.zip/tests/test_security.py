"""
Tests for app/security.py, app/utils.py (IP handling) and proxy trust.

These load the modules directly from their files, so they run without the
Flask extensions installed. The proxy test uses Werkzeug, which Flask
always ships with.

Run:  python3 -m unittest discover -s tests -v
"""

import importlib.util
import os
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, '..', 'app')


def _load(name, filename):
    spec = importlib.util.spec_from_file_location(name, os.path.join(APP, filename))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


security = _load('security', 'security.py')
utils = _load('utils', 'utils.py')


class FakeRequest:
    """The bits of a Flask request that get_client_ip reads."""

    def __init__(self, remote_addr, headers=None):
        self.remote_addr = remote_addr
        self.headers = headers or {}


class RateLimiterTests(unittest.TestCase):

    def test_consume_allows_up_to_limit_then_blocks(self):
        lim = security.SlidingWindowLimiter()
        results = [lim.consume('k', limit=3, window=60) for _ in range(5)]
        self.assertEqual(results, [True, True, True, False, False])

    def test_blocked_attempts_are_not_counted(self):
        lim = security.SlidingWindowLimiter()
        for _ in range(10):
            lim.consume('k', limit=2, window=60)
        self.assertEqual(lim.count('k', 60), 2)

    def test_keys_are_independent(self):
        lim = security.SlidingWindowLimiter()
        lim.consume('a', limit=1, window=60)
        self.assertFalse(lim.consume('a', limit=1, window=60))
        self.assertTrue(lim.consume('b', limit=1, window=60))

    def test_window_expires(self):
        lim = security.SlidingWindowLimiter()
        lim.record('k', window=0.2)
        self.assertEqual(lim.count('k', 0.2), 1)
        time.sleep(0.3)
        self.assertEqual(lim.count('k', 0.2), 0)

    def test_record_counts_failures_for_count_checks(self):
        lim = security.SlidingWindowLimiter()
        for _ in range(4):
            lim.record('login', window=900)
        self.assertGreaterEqual(lim.count('login', 900), 4)


class SecretTests(unittest.TestCase):

    def test_secure_equals_matches_only_exact_value(self):
        self.assertTrue(security.secure_equals('abc123', 'abc123'))
        self.assertFalse(security.secure_equals('abc124', 'abc123'))
        self.assertFalse(security.secure_equals('', 'abc123'))
        self.assertFalse(security.secure_equals(None, 'abc123'))

    def test_empty_expected_never_matches(self):
        # An unconfigured secret must not accept an empty header.
        self.assertFalse(security.secure_equals('', ''))
        self.assertFalse(security.secure_equals('anything', ''))

    def test_load_or_create_secret_env_wins(self):
        with tempfile.TemporaryDirectory() as d:
            key, source = security.load_or_create_secret(os.path.join(d, 'k'), 'from-env')
            self.assertEqual((key, source), ('from-env', 'env'))

    def test_load_or_create_secret_generates_once_with_owner_only_file(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, 'sub', 'secret')
            key1, source1 = security.load_or_create_secret(path)
            self.assertEqual(source1, 'generated')
            self.assertGreaterEqual(len(key1), 60)
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)
            key2, source2 = security.load_or_create_secret(path)
            self.assertEqual((key2, source2), (key1, 'file'))

    def test_new_tokens_are_unique(self):
        self.assertNotEqual(security.new_token(), security.new_token())


class RedirectTests(unittest.TestCase):

    def test_same_site_paths_are_allowed(self):
        for ok in ('/dashboard', '/admin/users?page=2', '/'):
            self.assertTrue(security.is_safe_relative_path(ok), ok)

    def test_open_redirects_are_refused(self):
        bad = ['//evil.com', '/\\evil.com', 'https://evil.com', 'http://evil.com',
               'javascript:alert(1)', '', None, 'dashboard', '/ok\r\nSet-Cookie: x=1']
        for value in bad:
            self.assertFalse(security.is_safe_relative_path(value), repr(value))


class OutboundUrlTests(unittest.TestCase):
    """SSRF guard. IP literals are used so no DNS lookup is needed."""

    def test_internal_and_metadata_addresses_are_refused(self):
        for url in ('http://127.0.0.1/',
                    'http://169.254.169.254/latest/meta-data/',
                    'http://10.0.0.5/admin',
                    'http://192.168.1.1/',
                    'http://[::1]/',
                    'http://0.0.0.0/'):
            ok, reason = security.is_public_http_url(url)
            self.assertFalse(ok, url)
            self.assertTrue(reason)

    def test_non_http_schemes_are_refused(self):
        for url in ('file:///etc/passwd', 'ftp://8.8.8.8/', 'gopher://8.8.8.8/'):
            ok, _ = security.is_public_http_url(url)
            self.assertFalse(ok, url)

    def test_public_address_is_allowed(self):
        ok, reason = security.is_public_http_url('https://8.8.8.8/dlr')
        self.assertTrue(ok, reason)

    def test_garbage_is_refused(self):
        for url in ('', 'not a url', 'http://'):
            ok, _ = security.is_public_http_url(url)
            self.assertFalse(ok, url)


class ClientIpTests(unittest.TestCase):

    def test_spoofed_forwarded_header_is_ignored(self):
        # The attack: send an allowed IP in X-Forwarded-For to pass the whitelist.
        req = FakeRequest('198.51.100.7', {'X-Forwarded-For': '93.190.143.35'})
        self.assertEqual(utils.get_client_ip(req), '198.51.100.7')

    def test_real_ip_header_is_ignored_too(self):
        req = FakeRequest('198.51.100.7', {'X-Real-IP': '93.190.143.35'})
        self.assertEqual(utils.get_client_ip(req), '198.51.100.7')

    def test_missing_remote_addr_is_empty_string(self):
        self.assertEqual(utils.get_client_ip(FakeRequest(None)), '')


class WhitelistTests(unittest.TestCase):

    def test_empty_whitelist_means_no_restriction(self):
        self.assertTrue(utils.ip_matches_whitelist('203.0.113.9', ''))
        self.assertTrue(utils.ip_matches_whitelist('203.0.113.9', None))

    def test_exact_and_cidr_and_wildcard(self):
        rules = '93.190.143.35\n10.0.0.0/8\n# comment\n'
        self.assertTrue(utils.ip_matches_whitelist('93.190.143.35', rules))
        self.assertTrue(utils.ip_matches_whitelist('10.9.8.7', rules))
        self.assertFalse(utils.ip_matches_whitelist('93.190.143.36', rules))
        self.assertTrue(utils.ip_matches_whitelist('203.0.113.9', '*'))
        self.assertTrue(utils.ip_matches_whitelist('203.0.113.9', 'all'))

    def test_malformed_lines_do_not_lock_everyone_out(self):
        rules = 'not-an-ip\n10.0.0.0/8'
        self.assertTrue(utils.ip_matches_whitelist('10.1.1.1', rules))
        self.assertFalse(utils.ip_matches_whitelist('8.8.8.8', rules))

    def test_unparseable_client_ip_is_refused_when_rules_exist(self):
        self.assertFalse(utils.ip_matches_whitelist('', '10.0.0.0/8'))
        self.assertFalse(utils.ip_matches_whitelist('garbage', '10.0.0.0/8'))


class ProxyTrustTests(unittest.TestCase):
    """ProxyFix must honour X-Forwarded-For only for the configured hops."""

    def _client_ip_seen_by_app(self, hops, xff):
        try:
            from werkzeug.middleware.proxy_fix import ProxyFix
            from werkzeug.test import EnvironBuilder
        except ImportError:  # pragma: no cover
            self.skipTest('Werkzeug not installed')

        seen = {}

        def app(environ, start_response):
            seen['ip'] = environ['REMOTE_ADDR']
            start_response('200 OK', [])
            return [b'']

        wrapped = app if hops == 0 else ProxyFix(app, x_for=hops, x_proto=hops, x_host=0, x_port=0)
        headers = {'X-Forwarded-For': xff} if xff else {}
        env = EnvironBuilder(headers=headers, environ_base={'REMOTE_ADDR': '10.0.0.2'}).get_environ()
        wrapped(env, lambda status, headers: None)
        return seen['ip']

    def test_no_proxy_trust_by_default(self):
        self.assertEqual(self._client_ip_seen_by_app(0, '203.0.113.9'), '10.0.0.2')

    def test_one_trusted_proxy_yields_the_real_client(self):
        # nginx appends the client it saw: "<client-sent-value>, <real-client>"
        self.assertEqual(self._client_ip_seen_by_app(1, '1.2.3.4, 198.51.100.7'), '198.51.100.7')


if __name__ == '__main__':
    unittest.main()
