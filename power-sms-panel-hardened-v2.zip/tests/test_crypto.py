"""
Tests for app/crypto_box.py (encryption at rest for SMPP passwords).

Run:  python3 -m unittest discover -s tests -v
"""

import importlib.util
import io
import os
import contextlib
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location(
    'crypto_box', os.path.join(HERE, '..', 'app', 'crypto_box.py'))
cb = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cb)

from cryptography.fernet import Fernet  # noqa: E402  (dependency of the module)


def _quiet(fn, *args, **kwargs):
    """Call fn while swallowing the module's stderr warnings."""
    with contextlib.redirect_stderr(io.StringIO()):
        return fn(*args, **kwargs)


class RoundTripTests(unittest.TestCase):

    def setUp(self):
        _quiet(cb.init_key, tempfile.mkdtemp(), Fernet.generate_key().decode())

    def test_encrypt_then_decrypt_returns_original(self):
        for secret in ('smsc-pass-123', 'كلمة مرور', 'pässwörd 🔐', 'x' * 500):
            stored = cb.encrypt_value(secret)
            self.assertNotEqual(stored, secret)
            self.assertTrue(stored.startswith(cb.PREFIX))
            self.assertEqual(cb.decrypt_value(stored), secret)

    def test_ciphertext_is_not_deterministic(self):
        # Fernet adds a random IV: the same password never looks the same twice.
        self.assertNotEqual(cb.encrypt_value('same'), cb.encrypt_value('same'))

    def test_encrypting_twice_does_not_double_encrypt(self):
        once = cb.encrypt_value('secret')
        self.assertEqual(cb.encrypt_value(once), once)

    def test_empty_and_none_pass_through(self):
        self.assertIsNone(cb.encrypt_value(None))
        self.assertEqual(cb.encrypt_value(''), '')
        self.assertEqual(cb.decrypt_value(''), '')
        self.assertIsNone(cb.decrypt_value(None))

    def test_legacy_plaintext_is_readable_until_migrated(self):
        self.assertEqual(cb.decrypt_value('old-plain-password'), 'old-plain-password')
        self.assertFalse(cb.is_encrypted('old-plain-password'))


class KeyManagementTests(unittest.TestCase):

    def test_env_key_is_used(self):
        key = Fernet.generate_key().decode()
        source = _quiet(cb.init_key, tempfile.mkdtemp(), key)
        self.assertEqual(source, 'env')
        self.assertTrue(cb.is_enabled())

    def test_invalid_env_key_fails_loudly(self):
        with self.assertRaises(RuntimeError) as cm:
            _quiet(cb.init_key, tempfile.mkdtemp(), 'not-a-fernet-key')
        self.assertIn('DATA_ENCRYPTION_KEY', str(cm.exception))

    def test_generated_key_is_persisted_owner_only_and_reused(self):
        d = tempfile.mkdtemp()
        source1 = _quiet(cb.init_key, d, None)
        self.assertEqual(source1, 'generated')
        path = os.path.join(d, '.data_key')
        self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)
        stored = cb.encrypt_value('persist-me')

        source2 = _quiet(cb.init_key, d, None)
        self.assertEqual(source2, 'file')
        # A restart with the same instance folder can still read the secret.
        self.assertEqual(cb.decrypt_value(stored), 'persist-me')

    def test_wrong_key_returns_empty_instead_of_crashing(self):
        d1, d2 = tempfile.mkdtemp(), tempfile.mkdtemp()
        _quiet(cb.init_key, d1, None)
        stored = cb.encrypt_value('secret-from-key-1')
        _quiet(cb.init_key, d2, None)  # a different key now
        self.assertEqual(_quiet(cb.decrypt_value, stored), '')

    def test_no_writable_location_disables_encryption_not_data(self):
        # A path whose parent is a regular file cannot be created: simulates a
        # read-only serverless filesystem.
        with tempfile.NamedTemporaryFile() as blocker:
            impossible = os.path.join(blocker.name, 'instance')
            source = _quiet(cb.init_key, impossible, None)
        self.assertEqual(source, 'disabled')
        self.assertFalse(cb.is_enabled())
        # Values are stored as plaintext rather than lost behind an ephemeral key.
        self.assertEqual(cb.encrypt_value('still-here'), 'still-here')

    def test_encrypted_value_without_key_is_not_returned_as_ciphertext(self):
        d = tempfile.mkdtemp()
        _quiet(cb.init_key, d, None)
        stored = cb.encrypt_value('x')
        cb._fernet = None  # key unavailable
        self.assertEqual(_quiet(cb.decrypt_value, stored), '')


if __name__ == '__main__':
    unittest.main()
