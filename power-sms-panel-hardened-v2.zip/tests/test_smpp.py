"""
Tests for app/smpp_protocol.py against a mock SMSC running on localhost.

The mock speaks real SMPP v3.4 over TCP, so these exercise the same socket,
framing, threading and reconnect code that runs in production.

Run:  python3 -m unittest discover -s tests -v
"""

import importlib.util
import os
import socket
import struct
import threading
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location(
    'smpp_protocol', os.path.join(HERE, '..', 'app', 'smpp_protocol.py'))
smpp = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(smpp)


class MockSmsc:
    """Minimal SMSC: binds, accepts submit_sm, answers enquire_link, can send
    delivery receipts, throttle once, reject a destination and drop links."""

    def __init__(self, password='secret', throttle_first=False, dlr=True,
                 drop_after_submits=None):
        self.password = password
        self.throttle_first = throttle_first
        self.dlr = dlr
        self.drop_after_submits = drop_after_submits
        self.lock = threading.Lock()
        self.submits = []          # accepted submissions (parsed)
        self.raw_submit_count = 0  # every submit_sm received, including rejected
        self.connections = 0
        self.enquire_count = 0
        self.bind_count = 0
        self._counter = 0
        self._running = True

        self._srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._srv.bind(('127.0.0.1', 0))
        self._srv.listen(8)
        self.port = self._srv.getsockname()[1]
        threading.Thread(target=self._accept, daemon=True).start()

    def close(self):
        self._running = False
        try:
            self._srv.close()
        except OSError:
            pass

    def _next(self):
        with self.lock:
            self._counter += 1
            return self._counter

    def _accept(self):
        while self._running:
            try:
                self._srv.settimeout(0.2)
                conn, _ = self._srv.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            with self.lock:
                self.connections += 1
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    def _serve(self, conn):
        parser = smpp.PduParser()
        send_lock = threading.Lock()

        def send(cid, seq, body=b'', status=0):
            with send_lock:
                conn.sendall(smpp.build_pdu(cid, seq, body, status))

        drop = False
        try:
            while self._running and not drop:
                conn.settimeout(0.2)
                try:
                    data = conn.recv(4096)
                except socket.timeout:
                    continue
                if not data:
                    break
                for pdu in parser.feed(data):
                    cid, seq, body = pdu['command_id'], pdu['sequence_number'], pdu['body']
                    if cid in (smpp.CMD_BIND_TRANSCEIVER, smpp.CMD_BIND_TRANSMITTER,
                               smpp.CMD_BIND_RECEIVER):
                        with self.lock:
                            self.bind_count += 1
                        _sid, pos = smpp._read_cstr(body, 0)
                        pw, _ = smpp._read_cstr(body, pos)
                        if pw == self.password:
                            tlv = struct.pack('>HH', 0x0210, 1) + bytes([0x34])
                            send(cid | smpp.RESP_FLAG, seq,
                                 smpp._cstr('MOCKSMSC', 16) + tlv, 0)
                        else:
                            send(cid | smpp.RESP_FLAG, seq, b'', smpp.ESME_RINVPASWD)
                    elif cid == smpp.CMD_SUBMIT_SM:
                        with self.lock:
                            self.raw_submit_count += 1
                            attempt = self.raw_submit_count
                        fields = smpp.parse_message_body(body)
                        if fields['destination'].startswith('999'):
                            send(cid | smpp.RESP_FLAG, seq, b'', 0x0B)
                            continue
                        if self.throttle_first and attempt == 1:
                            send(cid | smpp.RESP_FLAG, seq, b'', smpp.ESME_RTHROTTLED)
                            continue
                        mid = f'M{self._next():06d}'
                        with self.lock:
                            self.submits.append(dict(fields, message_id=mid))
                        send(cid | smpp.RESP_FLAG, seq, smpp._cstr(mid, 65), 0)
                        if self.dlr and fields['registered_delivery']:
                            receipt = (f"id:{mid} sub:001 dlvrd:001 submit date:2601010000 "
                                       f"done date:2601010001 stat:DELIVRD err:000 text:")
                            dlr_body = smpp.build_submit_body(
                                'SMSC', fields['destination'], 0x04, 0,
                                receipt.encode('ascii'), registered_delivery=0)
                            send(smpp.CMD_DELIVER_SM, self._next(), dlr_body)
                        if self.drop_after_submits and len(self.submits) == self.drop_after_submits:
                            drop = True
                            break
                    elif cid == smpp.CMD_ENQUIRE_LINK:
                        with self.lock:
                            self.enquire_count += 1
                        send(cid | smpp.RESP_FLAG, seq)
                    elif cid == smpp.CMD_UNBIND:
                        send(cid | smpp.RESP_FLAG, seq)
                        drop = True
                        break
        except OSError:
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass


def _free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    return port


class PduCodecTests(unittest.TestCase):

    def test_bind_body_matches_spec_layout_exactly(self):
        body = smpp.build_bind_body('sys', 'pw', '')
        # 'sys\0' + 'pw\0' + '\0' + interface_version + ton + npi + '\0'
        self.assertEqual(body, b'sys\x00pw\x00\x00\x34\x00\x00\x00')

    def test_pdu_header_length_is_total_length(self):
        pdu = smpp.build_pdu(smpp.CMD_ENQUIRE_LINK, 7, b'')
        length, cid, status, seq = struct.unpack('>IIII', pdu)
        self.assertEqual((length, cid, status, seq), (16, 0x15, 0, 7))

    def test_submit_body_round_trips_through_parser(self):
        body = smpp.build_submit_body('HTTP-GW', '+201234567890', 0x00, 0x00, b'Hi')
        fields = smpp.parse_message_body(body)
        self.assertEqual(fields['source'], 'HTTP-GW')
        self.assertEqual(fields['destination'], '201234567890')
        self.assertEqual(fields['short_message'], b'Hi')
        self.assertEqual((fields['dest_ton'], fields['dest_npi']), (1, 1))
        self.assertEqual(fields['source_ton'], 5)
        self.assertEqual(fields['registered_delivery'], 1)

    def test_parser_waits_for_complete_frame(self):
        pdu = smpp.build_pdu(smpp.CMD_SUBMIT_SM, 3, b'abcdef')
        parser = smpp.PduParser()
        self.assertEqual(parser.feed(pdu[:5]), [])
        self.assertEqual(parser.feed(pdu[5:12]), [])
        out = parser.feed(pdu[12:])
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]['body'], b'abcdef')

    def test_parser_rejects_huge_length_without_allocating(self):
        parser = smpp.PduParser()
        with self.assertRaises(smpp.SmppProtocolError):
            parser.feed(struct.pack('>IIII', 2_000_000_000, 4, 0, 1))

    def test_parser_rejects_length_below_header(self):
        parser = smpp.PduParser()
        with self.assertRaises(smpp.SmppProtocolError):
            parser.feed(struct.pack('>IIII', 8, 4, 0, 1))

    def test_truncated_body_is_a_protocol_error_not_a_crash(self):
        with self.assertRaises(smpp.SmppError):
            smpp.parse_message_body(b'\x00\x00')


class EncodingTests(unittest.TestCase):

    def test_plain_ascii_uses_gsm_single_part(self):
        enc, segs = smpp.build_segments('Your code is 123456')
        self.assertEqual(enc, 'GSM')
        self.assertEqual(len(segs), 1)
        self.assertEqual(segs[0][1], 0x00)  # data_coding

    def test_gsm_extension_chars_fall_back_to_ucs2(self):
        enc, _ = smpp.build_segments('price [5] ~ ok')
        self.assertEqual(enc, 'UCS2')

    def test_arabic_is_ucs2_single_part(self):
        enc, segs = smpp.build_segments('مرحبا بك')
        self.assertEqual(enc, 'UCS2')
        self.assertEqual(len(segs), 1)
        self.assertEqual(segs[0][1], 0x08)
        self.assertEqual(segs[0][2].decode('utf-16-be'), 'مرحبا بك')

    def test_long_message_is_split_with_udh_and_reassembles(self):
        text = ('مرحبا بالعالم ' * 20).strip()
        enc, segs = smpp.build_segments(text)
        self.assertEqual(enc, 'UCS2')
        self.assertGreater(len(segs), 1)
        ref = segs[0][2][3]
        total = segs[0][2][4]
        self.assertEqual(total, len(segs))
        rebuilt = b''
        for idx, (esm, dc, payload) in enumerate(segs, start=1):
            self.assertEqual(esm, 0x40)
            self.assertEqual(payload[:3], b'\x05\x00\x03')
            self.assertEqual(payload[3], ref)
            self.assertEqual(payload[5], idx)
            self.assertLessEqual(len(payload), 140)
            rebuilt += payload[6:]
        self.assertEqual(rebuilt.decode('utf-16-be'), text)

    def test_emoji_is_never_split_in_half(self):
        text = '😀' * 80
        enc, segs = smpp.build_segments(text)
        rebuilt = b''.join(p[6:] for _, _, p in segs)
        self.assertEqual(rebuilt.decode('utf-16-be'), text)

    def test_too_many_parts_is_rejected(self):
        with self.assertRaises(ValueError):
            smpp.build_segments('ع' * 700)

    def test_empty_message_is_rejected(self):
        with self.assertRaises(ValueError):
            smpp.build_segments('   ')

    def test_lone_surrogate_does_not_crash(self):
        enc, segs = smpp.build_segments('ok \ud800 done')
        self.assertTrue(segs)

    def test_destination_validation(self):
        self.assertEqual(smpp.normalize_destination('+20 123-456-7890'), '201234567890')
        for bad in ('abc', '12', '', None, '12345678901234567890123'):
            with self.assertRaises(ValueError):
                smpp.normalize_destination(bad)


class ReceiptTests(unittest.TestCase):

    def test_parses_standard_receipt(self):
        r = smpp.parse_receipt(
            'id:0123ABC sub:001 dlvrd:001 submit date:2601010000 '
            'done date:2601010001 stat:DELIVRD err:000 text:Hi')
        self.assertEqual(r['message_id'], '0123ABC')
        self.assertEqual(r['stat'], 'DELIVRD')
        self.assertEqual(r['err'], '000')

    def test_non_receipt_text_is_ignored(self):
        self.assertIsNone(smpp.parse_receipt('just a normal message'))


class MockSmscTests(unittest.TestCase):

    def setUp(self):
        self.smsc = MockSmsc(password='secret')

    def tearDown(self):
        self.smsc.close()

    def _session(self, **kw):
        return smpp.SmppSession('127.0.0.1', self.smsc.port, 'esme1', kw.pop('password', 'secret'),
                                connect_timeout=3, response_timeout=3, **kw)

    def test_bind_success_reports_server_identity(self):
        result = smpp.test_bind('127.0.0.1', self.smsc.port, 'esme1', 'secret')
        self.assertTrue(result['success'], result)
        self.assertEqual(result['status'], 'connected')
        self.assertEqual(result['details']['serverSystemId'], 'MOCKSMSC')
        self.assertEqual(result['details']['scInterfaceVersion'], '3.4')

    def test_bind_wrong_password_reports_invalid_password(self):
        result = smpp.test_bind('127.0.0.1', self.smsc.port, 'esme1', 'wrong')
        self.assertFalse(result['success'])
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['details']['errorCode'], smpp.ESME_RINVPASWD)
        self.assertIn('Invalid password', result['message'])

    def test_connection_refused_is_reported_cleanly(self):
        result = smpp.test_bind('127.0.0.1', _free_port(), 'esme1', 'secret', timeout=2)
        self.assertFalse(result['success'])
        self.assertEqual(result['status'], 'error')
        self.assertIn('Connection refused', result['message'])

    def test_submit_gsm_message_reaches_smsc_intact(self):
        s = self._session()
        s.connect()
        try:
            out = s.submit('HTTP-GW', '+201234567890', 'Hello World')
        finally:
            s.close()
        self.assertEqual(out['encoding'], 'GSM')
        sub = self.smsc.submits[-1]
        self.assertEqual(sub['destination'], '201234567890')
        self.assertEqual(sub['source'], 'HTTP-GW')
        self.assertEqual(sub['short_message'], b'Hello World')
        self.assertEqual(sub['data_coding'], 0)

    def test_submit_arabic_is_sent_as_ucs2(self):
        s = self._session()
        s.connect()
        try:
            out = s.submit('SMSSVC', '201012345678', 'كود التحقق 482913')
        finally:
            s.close()
        self.assertEqual(out['encoding'], 'UCS2')
        sub = self.smsc.submits[-1]
        self.assertEqual(sub['data_coding'], 0x08)
        self.assertEqual(sub['short_message'].decode('utf-16-be'), 'كود التحقق 482913')

    def test_long_message_arrives_as_ordered_parts(self):
        text = 'رسالة طويلة ' * 30
        s = self._session()
        s.connect()
        try:
            out = s.submit('SMSSVC', '201012345678', text)
        finally:
            s.close()
        self.assertGreater(out['parts'], 1)
        parts = self.smsc.submits[-out['parts']:]
        parts.sort(key=lambda p: p['short_message'][5])
        self.assertEqual([p['short_message'][5] for p in parts], list(range(1, out['parts'] + 1)))
        rebuilt = b''.join(p['short_message'][6:] for p in parts).decode('utf-16-be')
        self.assertEqual(rebuilt, text)
        self.assertEqual(len(out['messageIds']), out['parts'])

    def test_smsc_rejection_surfaces_status_text(self):
        s = self._session()
        s.connect()
        try:
            with self.assertRaises(smpp.SmppError) as cm:
                s.submit('SMSSVC', '999000111', 'hi')
        finally:
            s.close()
        self.assertEqual(cm.exception.code, 0x0B)
        self.assertIn('Invalid destination address', str(cm.exception))

    def test_throttled_submit_is_retried_and_succeeds(self):
        smsc = MockSmsc(password='secret', throttle_first=True)
        self.addCleanup(smsc.close)
        s = smpp.SmppSession('127.0.0.1', smsc.port, 'esme1', 'secret',
                             connect_timeout=3, response_timeout=3)
        s.connect()
        try:
            out = s.submit('SMSSVC', '201012345678', 'retry me')
        finally:
            s.close()
        self.assertEqual(smsc.raw_submit_count, 2)
        self.assertEqual(len(out['messageIds']), 1)

    def test_delivery_receipt_is_delivered_to_callback(self):
        got = threading.Event()
        receipts = []

        def on_receipt(r):
            receipts.append(r)
            got.set()

        s = self._session(on_receipt=on_receipt)
        s.connect()
        try:
            out = s.submit('SMSSVC', '201012345678', 'dlr please')
            self.assertTrue(got.wait(3), 'no delivery receipt arrived')
        finally:
            s.close()
        self.assertEqual(receipts[0]['message_id'], out['messageIds'][0])
        self.assertEqual(receipts[0]['stat'], 'DELIVRD')

    def test_concurrent_submits_are_all_answered_correctly(self):
        s = self._session()
        s.connect()
        results, errors = [], []

        def worker(n):
            try:
                results.append(s.submit('SMSSVC', '201012345678', f'msg {n}')['messageIds'][0])
            except Exception as e:  # pragma: no cover - reported below
                errors.append(e)

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(10)
        s.close()
        self.assertEqual(errors, [])
        self.assertEqual(len(results), 20)
        self.assertEqual(len(set(results)), 20)

    def test_enquire_link_keeps_the_link_alive(self):
        s = self._session(enquire_interval=0.2)
        s.connect()
        time.sleep(1.2)
        self.assertTrue(s.is_bound, s.last_error)
        self.assertGreaterEqual(self.smsc.enquire_count, 3)
        s.close()

    def test_reconnects_after_smsc_drops_the_link(self):
        smsc = MockSmsc(password='secret', drop_after_submits=1, dlr=False)
        self.addCleanup(smsc.close)
        s = smpp.SmppSession('127.0.0.1', smsc.port, 'esme1', 'secret',
                             connect_timeout=3, response_timeout=3)
        s.connect()
        s.submit('SMSSVC', '201012345678', 'first')
        time.sleep(0.6)  # give the reader time to notice the drop
        out = s.submit('SMSSVC', '201012345678', 'second')
        s.close()
        self.assertEqual(len(out['messageIds']), 1)
        self.assertEqual(smsc.connections, 2)

    def test_send_test_sms_helper_end_to_end(self):
        result = smpp.send_test_sms('127.0.0.1', self.smsc.port, 'esme1', 'secret',
                                    '201012345678', 'helper test', timeout=3)
        self.assertTrue(result['success'], result)
        self.assertEqual(result['status'], 'submitted')
        self.assertTrue(result['messageId'])

    def test_send_test_sms_reports_bind_failure(self):
        result = smpp.send_test_sms('127.0.0.1', self.smsc.port, 'esme1', 'nope',
                                    '201012345678', 'x', timeout=3)
        self.assertFalse(result['success'])
        self.assertEqual(result['status'], 'failed')

    def test_registry_reuses_session_and_replaces_on_config_change(self):
        kwargs = dict(host='127.0.0.1', port=self.smsc.port, system_id='esme1',
                      password='secret', bind_type='transceiver')
        a = smpp.get_bound_session('test-provider-1', **kwargs)
        b = smpp.get_bound_session('test-provider-1', **kwargs)
        self.assertIs(a, b)
        self.assertTrue(a.is_bound)

        changed = dict(kwargs, password='secret')  # same config again
        self.assertIs(smpp.get_bound_session('test-provider-1', **changed), a)

        other = dict(kwargs, system_id='esme2')
        b2 = smpp.get_bound_session('test-provider-1', **other)
        self.assertIsNot(b2, a)          # changed config -> new session
        self.assertTrue(b2.is_bound)
        self.assertFalse(a.is_bound)     # the stale one was closed
        smpp.drop_bound_session('test-provider-1')


if __name__ == '__main__':
    unittest.main()
