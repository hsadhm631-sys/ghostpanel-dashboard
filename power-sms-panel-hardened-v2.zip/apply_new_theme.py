"""
Run this ONCE on your server to instantly switch the whole panel to the
new "V2 Flash" theme (matches the newest reference screenshots) — no
need to click anything in the Themes settings page.

Usage (from the project root, same place you normally run the app):
    python apply_new_theme.py
"""
from app import create_app, db
from app.models.settings import PanelSettings

app = create_app()

with app.app_context():
    settings = PanelSettings.get()
    settings.theme = 'flashv2'
    db.session.commit()
    print(f"Done. Panel theme is now: {settings.theme}")
    print("Refresh the panel in your browser (hard refresh / Ctrl+Shift+R) to see it.")
