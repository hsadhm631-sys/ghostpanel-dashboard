import os
import secrets
import sys
from datetime import timedelta

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _env_bool(name, default=False):
    raw = os.environ.get(name)
    if raw is None or raw.strip() == '':
        return default
    return raw.strip().lower() in ('1', 'true', 'yes', 'on')


def _env_int(name, default):
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _resolve_secret_key():
    """Session-signing key. The old code fell back to a constant string in
    the source code, which let anyone forge a login cookie for any account
    (including admin). Now: SECRET_KEY from the environment, otherwise a
    random key stored once in the instance folder (owner-only permissions)."""
    env_value = (os.environ.get('SECRET_KEY') or '').strip()
    if env_value:
        return env_value

    base = '/tmp/instance' if os.environ.get('VERCEL') else os.path.join(BASE_DIR, 'instance')
    path = os.path.join(base, '.secret_key')
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            stored = fh.read().strip()
        if stored:
            return stored
    except OSError:
        pass

    key = secrets.token_hex(32)
    try:
        os.makedirs(base, exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            fh.write(key)
        print(f'[security] SECRET_KEY not set - generated one at {path}. '
              'Set SECRET_KEY in your environment to manage it explicitly.',
              file=sys.stderr)
    except OSError:
        print('[security] SECRET_KEY not set and the instance folder is not writable - '
              'using a temporary key; sessions will reset on restart. Set SECRET_KEY.',
              file=sys.stderr)
    return key


class Config:
    SECRET_KEY = _resolve_secret_key()

    db_url = os.environ.get('DATABASE_URL', 'sqlite:///flash_sms.db')
    if db_url.startswith('postgres://'):
        db_url = db_url.replace('postgres://', 'postgresql://', 1)
    SQLALCHEMY_DATABASE_URI = db_url
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    SESSION_COOKIE_SECURE = _env_bool('SESSION_COOKIE_SECURE', False)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

    # Refuse request bodies larger than this (protects against memory abuse).
    # Generous enough for database restore uploads.
    MAX_CONTENT_LENGTH = 64 * 1024 * 1024

    # How many reverse proxies sit in front of the app (nginx, Vercel, ...).
    # 0 = trust no X-Forwarded-For header at all (safe default). Set to 1
    # when behind one proxy, and make sure nothing else can reach the app
    # port directly, otherwise clients could spoof their IP.
    TRUST_PROXY_HOPS = _env_int('TRUST_PROXY_HOPS', 0)

    # Login throttling: failed attempts allowed per window.
    LOGIN_IP_LIMIT = _env_int('LOGIN_IP_LIMIT', 20)
    LOGIN_USER_LIMIT = _env_int('LOGIN_USER_LIMIT', 10)
    LOGIN_WINDOW_SECONDS = 900
    REGISTER_IP_LIMIT = 5
    REGISTER_WINDOW_SECONDS = 3600

    CAPTCHA_ENABLED = True
    ITEMS_PER_PAGE = 25

    # Cloudflare Turnstile (free bot-verification widget).
    TURNSTILE_SITE_KEY = os.environ.get('TURNSTILE_SITE_KEY', '')
    TURNSTILE_SECRET_KEY = os.environ.get('TURNSTILE_SECRET_KEY', '')


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig,
}
